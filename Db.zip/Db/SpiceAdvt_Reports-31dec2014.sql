-- MySQL dump 10.13  Distrib 5.5.13, for Linux (i686)
--
-- Host: 192.168.9.126    Database: SpiceAdvt_Reports
-- ------------------------------------------------------
-- Server version	5.5.34-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_Admin_Add_publisher`
--

DROP TABLE IF EXISTS `tbl_Admin_Add_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_Add_publisher` (
  `Name` varchar(30) DEFAULT NULL,
  `User_Name` varchar(15) DEFAULT NULL,
  `Password` varchar(15) DEFAULT NULL,
  `Description` varchar(15) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Admin_Camp_summary`
--

DROP TABLE IF EXISTS `tbl_Admin_Camp_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_Camp_summary` (
  `camp_id` int(11) DEFAULT NULL,
  `Campaign_Name` varchar(30) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(10) DEFAULT NULL,
  `Total_unique_hits` int(10) DEFAULT NULL,
  `unique_effective_Hits` int(10) DEFAULT NULL,
  `Operator` varchar(10) DEFAULT NULL,
  `circle` varchar(15) DEFAULT NULL,
  `Gender` char(7) DEFAULT NULL,
  `Service` varchar(15) DEFAULT NULL,
  `Language` varchar(15) DEFAULT NULL,
  `ARPU` float DEFAULT NULL,
  `AON` date DEFAULT NULL,
  `Total_budget` int(10) DEFAULT NULL,
  `Left_budget` int(10) DEFAULT NULL,
  `Used_Budget` int(10) DEFAULT NULL,
  `Click_to_action` int(10) DEFAULT NULL,
  `unique_Click_to_action` int(10) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Admin_Campaign_Status_update`
--

DROP TABLE IF EXISTS `tbl_Admin_Campaign_Status_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_Campaign_Status_update` (
  `Camp_name` varchar(30) DEFAULT NULL,
  `Type` varchar(15) DEFAULT NULL,
  `Description` varchar(75) DEFAULT NULL,
  `Advertiser_details` varchar(15) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Admin_Pend_Approval`
--

DROP TABLE IF EXISTS `tbl_Admin_Pend_Approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_Pend_Approval` (
  `Camp_name` varchar(30) DEFAULT NULL,
  `Type` varchar(15) DEFAULT NULL,
  `Description` varchar(75) DEFAULT NULL,
  `Advertiser_details` varchar(15) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Admin_Publisher_summary`
--

DROP TABLE IF EXISTS `tbl_Admin_Publisher_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_Publisher_summary` (
  `App_Name` varchar(30) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `Unique_hits` int(10) DEFAULT NULL,
  `effective_hits` int(15) DEFAULT NULL,
  `unique_effective_Hits` int(10) DEFAULT NULL,
  `Failed_Hits` int(10) DEFAULT NULL,
  `uniq_Failed_Hits` int(10) DEFAULT NULL,
  `Rev` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Admin_pubstatus_update`
--

DROP TABLE IF EXISTS `tbl_Admin_pubstatus_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_pubstatus_update` (
  `User_Name` varchar(15) DEFAULT NULL,
  `Description` varchar(75) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `Start_Date` date DEFAULT NULL,
  `Pause_Date` date DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Camp_daily`
--

DROP TABLE IF EXISTS `tbl_Camp_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Camp_daily` (
  `Date` date DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_effective_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action_hits` int(15) DEFAULT NULL,
  `uniq_CTA` int(15) DEFAULT NULL,
  `failedHits` int(15) DEFAULT NULL,
  `uniqueFailedHits` int(15) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `Advertiser_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103230080 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_AON`
--

DROP TABLE IF EXISTS `tbl_Campaign_AON`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_AON` (
  `Date` datetime DEFAULT NULL,
  `AON` date DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12456 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_ARPU`
--

DROP TABLE IF EXISTS `tbl_Campaign_ARPU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_ARPU` (
  `Date` datetime DEFAULT NULL,
  `ARPU` int(20) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12419 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_Gender`
--

DROP TABLE IF EXISTS `tbl_Campaign_Gender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_Gender` (
  `Date` datetime DEFAULT NULL,
  `Gender` char(10) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `advertiser_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12437 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_Hourly`
--

DROP TABLE IF EXISTS `tbl_Campaign_Hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_Hourly` (
  `Date` date DEFAULT NULL,
  `Hour` int(11) DEFAULT NULL,
  `camp_id` mediumint(9) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_effective_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action_hits` int(15) DEFAULT NULL,
  `unique_CTA` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `Advertiser_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3262657 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_Language`
--

DROP TABLE IF EXISTS `tbl_Campaign_Language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_Language` (
  `Date` datetime DEFAULT NULL,
  `Language` varchar(20) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12611 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_Monthly`
--

DROP TABLE IF EXISTS `tbl_Campaign_Monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_Monthly` (
  `Year` varchar(20) DEFAULT NULL,
  `Month` int(11) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `Advertiser_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`camp_id`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_Operator`
--

DROP TABLE IF EXISTS `tbl_Campaign_Operator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_Operator` (
  `Date` datetime DEFAULT NULL,
  `Operator` int(15) DEFAULT NULL,
  `op_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4491 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_Operator1`
--

DROP TABLE IF EXISTS `tbl_Campaign_Operator1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_Operator1` (
  `Date` datetime DEFAULT NULL,
  `Operator` varchar(15) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT NULL,
  `Left_budget` int(15) DEFAULT NULL,
  `Used_Budget` int(15) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5738 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_circle`
--

DROP TABLE IF EXISTS `tbl_Campaign_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_circle` (
  `Date` datetime DEFAULT NULL,
  `Circle` int(15) DEFAULT NULL,
  `cir_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5995 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_service`
--

DROP TABLE IF EXISTS `tbl_Campaign_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_service` (
  `Date` datetime DEFAULT NULL,
  `Service` int(15) DEFAULT NULL,
  `ser_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Campaign_summary`
--

DROP TABLE IF EXISTS `tbl_Campaign_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Campaign_summary` (
  `date` date DEFAULT '0000-00-00',
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(30) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT '0',
  `effective_Hits` int(10) DEFAULT '0',
  `Total_unique_hits` int(10) DEFAULT '0',
  `unique_effective_Hits` int(10) DEFAULT '0',
  `Total_budget` int(10) DEFAULT '0',
  `left_budget` int(10) DEFAULT '0',
  `today_used_Budget` int(10) DEFAULT '0',
  `Click_to_action` int(10) DEFAULT '0',
  `unique_Click_to_action` int(10) DEFAULT '0',
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Advertiser_id` int(11) DEFAULT NULL,
  `Status` int(10) DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103206855 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_PlatformSummary`
--

DROP TABLE IF EXISTS `tbl_PlatformSummary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_PlatformSummary` (
  `Total_Publishers` int(15) DEFAULT NULL,
  `Total_Campaigns` int(15) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `Total_Rev` int(15) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Platform_Campaign`
--

DROP TABLE IF EXISTS `tbl_Platform_Campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Platform_Campaign` (
  `Advertiser_Name` varchar(20) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` float(4,2) DEFAULT NULL,
  `Left_budget` float(4,2) DEFAULT NULL,
  `Used_Budget` float(4,2) DEFAULT NULL,
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `Status` int(15) DEFAULT NULL,
  `Camp_id` mediumint(9) DEFAULT NULL,
  `Advertiser_id` int(5) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `Camp_id` (`Camp_id`),
  KEY `Advertisement_id` (`Advertiser_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Platform_Publisher`
--

DROP TABLE IF EXISTS `tbl_Platform_Publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Platform_Publisher` (
  `Publisher_Name` varchar(20) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `Effective_Hits` int(15) DEFAULT NULL,
  `Failed_Hits` int(15) DEFAULT NULL,
  `Revenue` int(10) DEFAULT NULL,
  `Status` int(15) DEFAULT NULL,
  `pub_id` int(5) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `pub_id` (`pub_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign_cir_summary`
--

DROP TABLE IF EXISTS `tbl_campaign_cir_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign_cir_summary` (
  `Date` datetime DEFAULT NULL,
  `Circle` int(15) DEFAULT NULL,
  `cir_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign_op_summary`
--

DROP TABLE IF EXISTS `tbl_campaign_op_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign_op_summary` (
  `Date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `op_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2501 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign_ser_summary`
--

DROP TABLE IF EXISTS `tbl_campaign_ser_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign_ser_summary` (
  `Date` datetime DEFAULT NULL,
  `Service` int(11) DEFAULT NULL,
  `ser_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cir_camp_view`
--

DROP TABLE IF EXISTS `tbl_cir_camp_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cir_camp_view` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `Status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cir_camp_view_summary`
--

DROP TABLE IF EXISTS `tbl_cir_camp_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cir_camp_view_summary` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cir_ser_temp`
--

DROP TABLE IF EXISTS `tbl_cir_ser_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cir_ser_temp` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cir_ser_view`
--

DROP TABLE IF EXISTS `tbl_cir_ser_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cir_ser_view` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cir_ser_view_summary`
--

DROP TABLE IF EXISTS `tbl_cir_ser_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cir_ser_view_summary` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_daily`
--

DROP TABLE IF EXISTS `tbl_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_daily` (
  `date` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_hourly_count_log`
--

DROP TABLE IF EXISTS `tbl_hourly_count_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_hourly_count_log` (
  `idea` varchar(300) DEFAULT NULL,
  `airtel` varchar(300) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_hours`
--

DROP TABLE IF EXISTS `tbl_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_hours` (
  `hour` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_logs_track`
--

DROP TABLE IF EXISTS `tbl_logs_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_logs_track` (
  `idea` varchar(300) DEFAULT NULL,
  `airtel` varchar(300) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_months`
--

DROP TABLE IF EXISTS `tbl_months`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_months` (
  `month` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_camp_temp`
--

DROP TABLE IF EXISTS `tbl_op_camp_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_camp_temp` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL,
  `service_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_camp_view`
--

DROP TABLE IF EXISTS `tbl_op_camp_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_camp_view` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL,
  `service_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_camp_view_summary`
--

DROP TABLE IF EXISTS `tbl_op_camp_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_camp_view_summary` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL,
  `service_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_cir_view`
--

DROP TABLE IF EXISTS `tbl_op_cir_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_cir_view` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_cir_view_summary`
--

DROP TABLE IF EXISTS `tbl_op_cir_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_cir_view_summary` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_ser_temp`
--

DROP TABLE IF EXISTS `tbl_op_ser_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_ser_temp` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_ser_view`
--

DROP TABLE IF EXISTS `tbl_op_ser_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_ser_view` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_op_ser_view_summary`
--

DROP TABLE IF EXISTS `tbl_op_ser_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_op_ser_view_summary` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_operator`
--

DROP TABLE IF EXISTS `tbl_operator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_operator` (
  `operator` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_proc_log_track`
--

DROP TABLE IF EXISTS `tbl_proc_log_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_proc_log_track` (
  `proc_name` varchar(100) DEFAULT NULL,
  `Date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_pub`
--

DROP TABLE IF EXISTS `tbl_pub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pub` (
  `name` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_pub_daily`
--

DROP TABLE IF EXISTS `tbl_pub_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pub_daily` (
  `Date` date DEFAULT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `totalHits` int(11) DEFAULT NULL,
  `uniqueHits` int(11) DEFAULT NULL,
  `effectiveHits` int(11) DEFAULT NULL,
  `uniqueEffectiveHits` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL,
  UNIQUE KEY `idx_name` (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=817 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_pub_hourly`
--

DROP TABLE IF EXISTS `tbl_pub_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pub_hourly` (
  `Date` date DEFAULT NULL,
  `Hour` int(11) DEFAULT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `totalHits` int(11) DEFAULT NULL,
  `uniqueHits` int(11) DEFAULT NULL,
  `effectiveHits` int(11) DEFAULT NULL,
  `uniqueEffectiveHits` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=16873 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_pub_monthly`
--

DROP TABLE IF EXISTS `tbl_pub_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pub_monthly` (
  `Year` varchar(20) DEFAULT NULL,
  `Month` int(11) DEFAULT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `totalHits` int(11) DEFAULT NULL,
  `uniqueHits` int(11) DEFAULT NULL,
  `effectiveHits` int(11) DEFAULT NULL,
  `uniqueEffectiveHits` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=704 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_pub_summary`
--

DROP TABLE IF EXISTS `tbl_pub_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pub_summary` (
  `Date` date DEFAULT NULL,
  `Pub_id` int(11) NOT NULL,
  `totalHits` int(11) DEFAULT NULL,
  `effectiveHits` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_status_ad_details`
--

DROP TABLE IF EXISTS `tbl_status_ad_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_status_ad_details` (
  `Status_ad_code` int(11) NOT NULL,
  `status_ad_Name` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Status_ad_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_advance`
--

DROP TABLE IF EXISTS `tbl_temp_advance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_advance` (
  `operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `camp` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_CTA`
--

DROP TABLE IF EXISTS `tbl_temp_camp_CTA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_CTA` (
  `Date` datetime DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `Total_hits` int(11) DEFAULT NULL,
  `Unique_hits` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_cir_summary`
--

DROP TABLE IF EXISTS `tbl_temp_camp_cir_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_cir_summary` (
  `Date` datetime DEFAULT NULL,
  `circle` int(15) DEFAULT NULL,
  `cir_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_eff_hits`
--

DROP TABLE IF EXISTS `tbl_temp_camp_eff_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_eff_hits` (
  `date` date DEFAULT NULL,
  `criteria` smallint(6) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `eff_hits` int(11) DEFAULT NULL,
  `uniq_eff_hits` int(11) DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_op_summary`
--

DROP TABLE IF EXISTS `tbl_temp_camp_op_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_op_summary` (
  `Date` datetime DEFAULT NULL,
  `Operator` int(15) DEFAULT NULL,
  `op_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_ser_summary`
--

DROP TABLE IF EXISTS `tbl_temp_camp_ser_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_ser_summary` (
  `Date` datetime DEFAULT NULL,
  `Service` int(15) DEFAULT NULL,
  `ser_name` varchar(30) DEFAULT NULL,
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `Total_Hits` int(15) DEFAULT NULL,
  `effective_Hits` int(15) DEFAULT NULL,
  `Total_unique_hits` int(15) DEFAULT NULL,
  `unique_eff_Hits` int(15) DEFAULT NULL,
  `Total_budget` int(15) DEFAULT '0',
  `Left_budget` int(15) DEFAULT '0',
  `Used_Budget` int(15) DEFAULT '0',
  `Click_to_action` int(15) DEFAULT NULL,
  `unique_Click_to_action` int(15) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_summary`
--

DROP TABLE IF EXISTS `tbl_temp_camp_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_summary` (
  `date` date DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `camp_name` varchar(30) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `unique_effective_Hits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `Total_Revenue` int(11) DEFAULT NULL,
  `Eff_Revenue` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Advertiser_id` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_camp_tot_hits`
--

DROP TABLE IF EXISTS `tbl_temp_camp_tot_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_camp_tot_hits` (
  `date` date DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `camp_id` int(5) DEFAULT NULL,
  `tot_hits` int(11) DEFAULT NULL,
  `uniq_tot_hits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_cir_camp_view_summary`
--

DROP TABLE IF EXISTS `tbl_temp_cir_camp_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_cir_camp_view_summary` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_cir_ser_view_summary`
--

DROP TABLE IF EXISTS `tbl_temp_cir_ser_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_cir_ser_view_summary` (
  `date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_op_camp_view_summary`
--

DROP TABLE IF EXISTS `tbl_temp_op_camp_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_op_camp_view_summary` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL,
  `service_name` int(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_op_cir_view_summary`
--

DROP TABLE IF EXISTS `tbl_temp_op_cir_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_op_cir_view_summary` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_op_ser_view_summary`
--

DROP TABLE IF EXISTS `tbl_temp_op_ser_view_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_op_ser_view_summary` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varbinary(50) DEFAULT NULL,
  `circle_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_pb_eff_hits`
--

DROP TABLE IF EXISTS `tbl_temp_pb_eff_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_pb_eff_hits` (
  `pub_date` datetime DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `eff_hits` int(11) DEFAULT NULL,
  `unique_eff_hits` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `sAID` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_pb_sm`
--

DROP TABLE IF EXISTS `tbl_temp_pb_sm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_pb_sm` (
  `Date` date DEFAULT NULL,
  `Pub_id` int(11) DEFAULT NULL,
  `totalHits` int(11) DEFAULT NULL,
  `effectiveHits` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_pb_summary`
--

DROP TABLE IF EXISTS `tbl_temp_pb_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_pb_summary` (
  `Date` date DEFAULT NULL,
  `Pub_id` int(11) DEFAULT NULL,
  `totalHits` int(11) DEFAULT NULL,
  `effectiveHits` int(11) DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `eff_revenue` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_pb_total_hits`
--

DROP TABLE IF EXISTS `tbl_temp_pb_total_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_pb_total_hits` (
  `pub_date` datetime DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `total_hits` int(11) DEFAULT NULL,
  `unique_total_hits` int(11) DEFAULT NULL,
  `total_revenue` int(11) DEFAULT NULL,
  `sAID` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_view_CTA`
--

DROP TABLE IF EXISTS `tbl_temp_view_CTA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_view_CTA` (
  `Date` datetime DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `Total_hits` int(11) DEFAULT NULL,
  `Unique_hits` int(11) DEFAULT NULL,
  `criteria_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_view_eff_hits`
--

DROP TABLE IF EXISTS `tbl_temp_view_eff_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_view_eff_hits` (
  `date` date DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `eff_hits` int(11) DEFAULT NULL,
  `uniq_eff_hits` int(11) DEFAULT NULL,
  `eff_revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `criteria_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_temp_view_tot_hits`
--

DROP TABLE IF EXISTS `tbl_temp_view_tot_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_temp_view_tot_hits` (
  `date` date DEFAULT NULL,
  `criteria` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `tot_hits` int(11) DEFAULT NULL,
  `uniq_tot_hits` int(11) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `criteria_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_view`
--

DROP TABLE IF EXISTS `tbl_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_view` (
  `date` datetime DEFAULT NULL,
  `Operator` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `pubID` int(11) DEFAULT NULL,
  `Total_Hits` int(11) DEFAULT NULL,
  `Total_unique_hits` int(11) DEFAULT NULL,
  `effective_Hits` int(11) DEFAULT NULL,
  `unique_eff_Hits` int(11) DEFAULT NULL,
  `Total_Revenue` float DEFAULT NULL,
  `Eff_Revenue` float DEFAULT NULL,
  `failedHits` int(11) DEFAULT NULL,
  `uniqueFailedHits` int(11) DEFAULT NULL,
  `Click_to_action` int(11) DEFAULT NULL,
  `unique_Click_to_action` int(11) DEFAULT NULL,
  `AdStatus` int(11) DEFAULT NULL,
  `operator_name` varchar(50) DEFAULT NULL,
  `camp_name` varchar(50) DEFAULT NULL,
  `circle_name` varchar(50) DEFAULT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'SpiceAdvt_Reports'
--
/*!50003 DROP FUNCTION IF EXISTS `getdata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 FUNCTION `getdata`(in_op int,in_cir int,in_ser int,in_camp int,in_sdate varchar(50),in_tdate varchar(50)) RETURNS int(11)
BEGIN
declare op_flag int;
declare cir_flag int;
declare ser_flag int;
declare camp_flag int;
declare a int;

if(in_op=null)then
	set op_flag=0;
else 
	set op_flag=1;
end if;
if(in_cir=null)then
	set cir_flag=0;
else
	set cir_flag=1;
end if;
if(in_ser=null)then
	set ser_flag=0;
else
	set ser_flag=1;
end if;
if(in_camp=null)then
	set camp_flag=0;
else
	set camp_flag=1;
end if;
insert into tbl_temp_advance values(op_flag,cir_flag,ser_flag,camp_flag);
return a;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `fetch_pub_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `fetch_pub_details`(in pid int)
BEGIN
	
	select tb.Name pubName,date(tb.Start_Date) startDate,date(tb.End_Date) endDate,D.user_name userName,C.status_ad_name pubStatus,
	tb.pub_id,(ifnull(sum(A.totalHits),0)+ifnull(B.totalHits,0)) totalHits,
	(ifnull(sum(A.effectiveHits),0)+ifnull(B.effectiveHits,0)) effectiveHits,(ifnull(sum(A.failedHits),0)+ifnull(B.failedHits,0)) failedHits ,
	(ifnull(sum(A.total_revenue),0)+ifnull(B.total_revenue,0)) total_revenue,(ifnull(sum(A.eff_revenue),0)+ifnull(B.eff_revenue,0)) eff_revenue,
	tb.Status_ad statusCode,E.ad_type pubType
	from  mob_advertisement.tbl_Publisher tb 
	left outer join SpiceAdvt_Reports.tbl_pub_daily A on A.pub_id=tb.pub_id
	left outer join mob_advertisement.tbl_status_ad_details C
	on C.status_ad_Code=tb.Status_ad
	left join  mob_advertisement.tbl_ad_details E on 
	E.ad_type_code=tb.Status_ad	
	left join mob_advertisement.tbl_Login D
	on  D.Uid=tb.AID
	left outer join SpiceAdvt_Reports.tbl_pub_summary B on B.pub_id=tb.pub_id   
	where tb.pub_id=pid
	group by A.pub_id,tb.Status_ad order by tb.Status_ad;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `fetch_pub_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `fetch_pub_reports`(in pid int,in in_startDate varchar(30),in in_endDate varchar(30),in in_type int)
BEGIN
	if(in_type=1)then
		select tb.Name pubName,date(tb.Start_Date) startDate,date(tb.End_Date) endDate,D.user_name userName,C.status_ad_name pubStatus,
		tb.pub_id,(ifnull(sum(A.totalHits),0)+ifnull(B.totalHits,0)) totalHits,
		(ifnull(sum(A.effectiveHits),0)+ifnull(B.effectiveHits,0)) effectiveHits,(ifnull(sum(A.failedHits),0)+ifnull(B.failedHits,0)) failedHits ,
		(ifnull(sum(A.total_revenue),0)+ifnull(B.total_revenue,0)) total_revenue,(ifnull(sum(A.eff_revenue),0)+ifnull(B.eff_revenue,0)) eff_revenue,
		tb.Status_ad statusCode,E.ad_type pubType
		from  mob_advertisement.tbl_Publisher tb 
		left outer join SpiceAdvt_Reports.tbl_pub_daily A on A.pub_id=tb.pub_id
		left outer join mob_advertisement.tbl_status_ad_details C
		on C.status_ad_Code=tb.Status_ad
		left join  mob_advertisement.tbl_ad_details E on 
		E.ad_type_code=tb.Status_ad	
		left join mob_advertisement.tbl_Login D
		on  D.Uid=tb.AID
		left outer join SpiceAdvt_Reports.tbl_pub_summary B on B.pub_id=tb.pub_id   
		where tb.pub_id=pid
		group by A.pub_id,tb.Status_ad,date(A.Date) order by tb.Status_ad,date(A.Date) desc;
	else
		
                
		select tb.Pub_id,tb.Name,tb.User_name,date(A.Date) Start_Date,A.totalHits,A.uniqueHits,A.effectiveHits,A.uniqueEffectiveHits,
		A.failedHits,A.uniqueFailedHits,A.total_revenue,A.eff_revenue
		from mob_advertisement.tbl_Publisher tb  
		left outer join SpiceAdvt_Reports.tbl_pub_daily A on A.pub_id=tb.pub_id
		where A.pub_id=pid and date(A.Date) between date(in_startDate) and  date(date(in_endDate)-1)
		group by date(A.Date) order by date(A.Date) desc;
                 
		
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_admin_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_admin_report`(repType varchar(30))
BEGIN
declare totalBudget int;
declare dailyBudget int;
if(repType='admin')then		
select a.Name campName,date(a.Start_Date) startdate,date(a.End_Date) enddate,a.Total_budget totalBudget,a.Daily_budget dailyBudget,a.camp_id campID,d.user_name userName,b.ad_type adType,c.status_ad_name adStatus,a.status_ad statusCode
,ifnull(B.Total_Hits,0) totalHits
from mob_advertisement.tbl_ad_details b,mob_advertisement.tbl_status_ad_details c,mob_advertisement.tbl_Login d 
,mob_advertisement.tbl_campaign a
left outer join  
tbl_Campaign_summary B
on a.advertiser_id=B.Advertiser_id 
where b.ad_type_code=a.type and
d.Uid=a.advertiser_id and c.status_ad_Code=a.status_ad and a.Camp_id=B.camp_id and c.status_ad_Code!=mob_advertisement.func_getAdName(0) 
and B.date=curdate() 
order by a.status_ad,Start_Date desc;
elseif(repType='publish')then
select P.pub_id pub_id,P.Name pubName,date(Start_Date) startDate,date(End_Date) endDate,user_name userName,status_ad_name pubStatus,totalHits,effectiveHits, failedHits,
total_revenue,eff_revenue,Status_ad statusCode,
E.ad_type pubType from mob_advertisement.tbl_Publisher P
left join tbl_pub_summary S on P.pub_id=S.pub_id
left join mob_advertisement.tbl_status_ad_details on status_ad_Code=Status_ad
left join  mob_advertisement.tbl_ad_details E on 
E.ad_type_code=P.Type where S.date=curdate()  order by Start_Date,totalHits desc;	
elseif(repType='pendingCamp')then
select Camp_id,C.Name,date(Start_Date) Start_Date,date(End_Date) End_Date,ad_type Type,Status_ad,status_ad_Name sDtl,advertiser_id,User_name AdvtName 
from mob_advertisement.tbl_campaign C
left join mob_advertisement.tbl_status_ad_details on Status_ad_code=Status_ad
left join mob_advertisement.tbl_Advertiser_Details on Aid=advertiser_id
left join mob_advertisement.tbl_ad_details on ad_type_code=Type
where Status_ad!=1 order by Start_Date desc;
elseif(repType='Advertiser')then
select a.Aid,a.User_name,email,LDate,c.Status,country
 from mob_advertisement.tbl_Advertiser_Details a
join  mob_advertisement.tbl_Login b on b.Uid=a.Aid
join mob_advertisement.tbl_advert_Verifystatus c on c.Code=a.Verify_Status;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_campaign`(in stdate varchar(20))
BEGIN
declare dcnt int;
declare cnt int;
declare hrcnt int;
declare mmcnt int;
declare varFailedHits int;
declare uniFailedHits int;
		
			delete from	tbl_temp_camp_tot_hits;
			delete from tbl_temp_camp_eff_hits;
			delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select Date(date),0,camp_id,count(*),count(distinct Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits 
			where date(Date)=date(stdate)
			group by Date,camp_id;
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(date),0,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
			from mob_advertisement.tbl_Effective_Hits A left join 
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id) 
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id)
			where date(A.Date)=date(stdate)
			group by (A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
			select Date(date),0,camp_id,count(*),count(distinct Ani)
			from  mob_advertisement.tbl_CTA 
			where date(Date)=date(stdate)
			group by Date,camp_id;
			select count(1) into dcnt from tbl_Camp_daily where  date(Date)=date(stdate);
			if(dcnt>0)then
			delete from tbl_Camp_daily where  date(Date)=date(stdate);
			end if;
			insert into tbl_Camp_daily (Date,camp_id,Total_Hits,effective_hits,Total_unique_hits,unique_effective_Hits,Click_to_action_hits,uniq_CTA,failedHits,uniqueFailedHits,total_revenue,eff_revenue,Advertiser_id)
			
			select Date(stdate), A.Camp_id ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.Advertiser_id
			from mob_advertisement.tbl_campaign A
			left outer join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left outer join tbl_temp_camp_eff_hits D on D.camp_id=A.Camp_id
			left outer join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id;
	
			delete from	tbl_temp_camp_tot_hits;
			delete from  tbl_temp_camp_eff_hits;
			delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani),sum(totalRevenue)
			from mob_advertisement.tbl_Total_Hits 
			where date(Date)=date(stdate)
			group by hour(Date),camp_id;
			
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
			select Date(stdate),hour(A.Date),A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
			from mob_advertisement.tbl_Effective_Hits A left join
			(select count(ani) Fld,count(distinct ani) uFld,hour(Date), date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by hour(Date),camp_id) 
			as FAiled on (hour(A.Date)=hour(FAiled.date) AND A.camp_id=FAiled.camp_id) 
			where date(A.Date)=date(stdate)
			group by hour(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
			select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani)
			from  mob_advertisement.tbl_CTA 
			where date(Date)=date(stdate) 
			group by hour(Date),camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_Hourly where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_Hourly where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_Hourly (Date, Hour,camp_id,Total_Hits,effective_Hits,unique_effective_hits,Click_to_action_hits,unique_CTA,failedHits,uniqueFailedHits,
			total_revenue,eff_revenue,Advertiser_id)
			select Date(stdate),Hr, C_ID ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid
			from
			(select A.hour Hr, tb2.camp_id C_ID,tb2.advertiser_id advid  from SpiceAdvt_Reports.tbl_hours A,(select distinct camp_id,advertiser_id from mob_advertisement.tbl_campaign)as tb2)as A1
			left outer join tbl_temp_camp_tot_hits C  on A1.Hr=C.criteria and A1.C_ID =C.camp_id
			left outer join tbl_temp_camp_eff_hits D on A1.Hr=D.criteria and A1.C_ID =D.camp_id
			left outer join tbl_temp_camp_CTA  E on A1.Hr=E.criteria and A1.C_ID =E.camp_id
			order by A1.Hr,A1.C_ID ;
			
		
			delete from	tbl_temp_camp_tot_hits;
			delete from  tbl_temp_camp_eff_hits;
			delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits, total_revenue)
			select Year(stdate),month(Date),camp_id,count(*),count(distinct Ani),sum(totalRevenue)
			from mob_advertisement.tbl_Total_Hits 
			where year(Date)=year(stdate)
			group by month(Date),camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue, failedHits, uniqueFailedHits)
			select Year(stdate),month(Date),A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
			from mob_advertisement.tbl_Effective_Hits  A left join 
			(select count(ani) Fld,count(distinct ani) uFld,month(Date) MM, camp_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by Month(Date),camp_id) 
			as FAiled on
			(month(A.Date)=MM AND A.camp_id=FAiled.camp_id)
			where  year(Date)=year(stdate)
			group by month(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
			select Year(stdate),month(Date),camp_id,count(*),count(distinct Ani)
			from mob_advertisement.tbl_CTA
			where  year(Date)=year(stdate)
			group by month(Date),camp_id;
			select count(stdate) into mmcnt from tbl_Campaign_Monthly where Year=year(stdate) and month= month(stdate);
			select 'old',mmcnt;
			if(mmcnt>0)then
			delete from tbl_Campaign_Monthly where  Year=year(stdate) and month= month(stdate);
			
			end if;
			insert into tbl_Campaign_Monthly (Year,Month,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,Advertiser_id)
			select year(concat(stdate,'-00-00')),MM, C_ID ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_eff_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid
			from
			(select A.month MM, tb2.camp_id C_ID ,tb2.advertiser_id advid from SpiceAdvt_Reports.tbl_months A,(select distinct camp_id,advertiser_id from mob_advertisement.tbl_campaign) as tb2 ) as A1
			left outer join tbl_temp_camp_tot_hits C  on A1.MM=C.criteria and A1.C_ID =C.camp_id
			left outer join tbl_temp_camp_eff_hits D on A1.MM=D.criteria and A1.C_ID =D.camp_id
			left outer join tbl_temp_camp_CTA  E on A1.MM=E.criteria and A1.C_ID =E.camp_id
			where MM=month(stdate)
			order by A1.MM,A1.C_ID ;
			
			select count(1) into cnt from tbl_Campaign_summary where  date(date)=date(stdate);
			if(cnt>0)then
			delete from tbl_Campaign_summary where  date(date)=date(stdate);
			end if;
			
			delete from tbl_temp_camp_summary;
			insert into tbl_temp_camp_summary(date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Click_to_action,unique_Click_to_action,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Advertiser_id,Status)
			select date(stdate),tb.Camp_id,tb.Name,
			ifnull(sum(A.Total_Hits),0)+ifnull(B.Total_Hits,0),
			ifnull(sum(A.effective_hits),0)+ifnull(B.effective_Hits,0),
			ifnull(sum(A.Total_unique_hits),0)+ifnull(B.Total_unique_hits,0),
			ifnull(sum(A.unique_effective_Hits),0)+ifnull(B.unique_effective_Hits,0),
			ifnull(sum(A.Click_to_action_hits),0)+ifnull(B.Click_to_action,0) ,
			ifnull(sum(A.uniq_CTA),0)+ifnull(B.unique_Click_to_action,0),
			ifnull(sum(A.total_revenue),0)+ifnull(B.total_revenue,0),
			ifnull(sum(A.eff_revenue),0)+ifnull(B.eff_revenue,0) ,
			ifnull(sum(A.failedHits),0)+ifnull(B.failedHits,0),
			ifnull(sum(A.uniqueFailedHits),0)+ifnull(B.uniqueFailedHits,0),tb.Advertiser_id,
			tb.Status_ad 
			from tbl_Camp_daily A 
			left outer join mob_advertisement.tbl_campaign tb on tb.Camp_id=A.camp_id
			left outer join tbl_Campaign_summary B on B.camp_id=tb.Camp_id   
			where A.Date=date(stdate)
			group by A.camp_id,tb.Status_ad;
			delete from tbl_Campaign_summary;
			insert into tbl_Campaign_summary(date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Click_to_action,unique_Click_to_action,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Advertiser_id,Status)
			select date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Click_to_action,unique_Click_to_action,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Advertiser_id,Status
			from tbl_temp_camp_summary;
			
			
			truncate table	tbl_temp_camp_tot_hits;
			truncate table  tbl_temp_camp_eff_hits;
			truncate table	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select operator from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.operator, camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(date),tb.operator,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select operator from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.operator, camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_Operator where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_Operator where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_Operator(Date,Operator,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			select Date(stdate),  A.Camp_id,Operator  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			group by   A.Operator,A.Camp_id;
			
			delete from	tbl_temp_camp_tot_hits;
			delete from  tbl_temp_camp_eff_hits;
			delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.Circle,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select Circle from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate)  group by tb.Circle, camp_id;
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(date),tb.Circle,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select Date(A.Date),tb.Circle,camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select Circle from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Circle, camp_id;
			
			
			select count(stdate) into hrcnt from tbl_Campaign_circle where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_circle where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_circle(Date,circle,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			select Date(stdate),Circle , A.Camp_id  ,
			ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
			ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			group by   A.Circle,A.Camp_id;
			
			
			delete from	tbl_temp_camp_tot_hits;
			delete from  tbl_temp_camp_eff_hits;
			delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.Service,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select Service from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Service, camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(date),tb.Service,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select Date(A.Date),tb.Service,camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select Service from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Service, camp_id;
			
			
			select count(stdate) into hrcnt from tbl_Campaign_Service where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_Service where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_Service(date,Service,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			
			select Date(stdate),  A.Camp_id,Operator  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			group by   A.Service,A.Camp_id;
			
			
		delete from	tbl_temp_camp_tot_hits;
		delete from  tbl_temp_camp_eff_hits;
		delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.N_Language,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select N_Language from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.N_Language, camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(A.Date),tb.N_Language,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select date(A.Date),tb.N_Language,A.camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select N_Language from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.N_Language, camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_Language where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_Language where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_Language(Date,Language,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			select Date(stdate),  A.Camp_id,N_Language  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
			ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			group by   A.N_Language,A.Camp_id;
			
			delete from	tbl_temp_camp_tot_hits;
			delete from  tbl_temp_camp_eff_hits;
		delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.Arpu,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select Arpu from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Arpu, camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(A.Date),tb.Arpu,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select date(A.Date),tb.Arpu,A.camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select Arpu from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Arpu, camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_ARPU where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_ARPU where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_ARPU(Date,ARPU,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			select Date(stdate),  A.Camp_id,Arpu  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
			ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			
			group by   A.Arpu,A.Camp_id;
			
			delete from	tbl_temp_camp_tot_hits;
			delete from  tbl_temp_camp_eff_hits;
			delete from	tbl_temp_camp_CTA;
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.Gender,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select Gender from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Gender, camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(A.Date),tb.Gender,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select date(A.Date),tb.Gender,A.camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select Gender from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.Gender, camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_Gender where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_Gender where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_Gender(Date,Gender,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			select Date(stdate),  A.Camp_id,N_Language  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
			ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			group by   A.Gender,A.Camp_id;
			
			insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select date(A.Date),tb.AON,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
			from mob_advertisement.tbl_Total_Hits A ,
			(select AON from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.AON, camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
			select date(A.Date),tb.AON,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
			from mob_advertisement.tbl_Effective_Hits A
			left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
			left join
			(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
			as FAiled on
			(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
			group by date(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
			select date(A.Date),tb.AON,A.camp_id,count(*),count(distinct A.Ani)
			from mob_advertisement.tbl_CTA A ,
			(select AON from mob_advertisement.tbl_campaign) as tb
			where date(A.Date)=date(stdate) group by tb.AON, camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_AON where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_AON where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_AON(Date,AON,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
			select Date(stdate),  A.Camp_id,AON  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
			ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
			from mob_advertisement.tbl_campaign A
			left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
			left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
			left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
			
			group by   A.AON,A.Camp_id;
			
			
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_common` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_common`(in stdate varchar(20))
BEGIN
call proc_camp(stdate);
call proc_camp_daily(stdate);
call proc_month_camp(stdate);
call proc_summary(stdate);
call proc_pub(stdate);
update mob_advertisement.tbl_campaign set Status_ad=mob_advertisement.func_getAdName(4) where End_Date<curdate() and Status_ad=mob_advertisement.func_getAdName(1);
call proc_view_proc(stdate);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_ser_ret_camp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_ser_ret_camp`(IN in_cir int,IN in_ser int)
BEGIN
select camp_id,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,camp_name 
from SpiceAdvt_Reports.tbl_cir_ser_view_summary where circle=in_cir and service=in_ser group by circle,service;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_dailybasis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_dailybasis`(in sdate date,in tdate date)
BEGIN
select date date, ani ani,bni bni,sum(duration) duration,sum(play) play,sum(downloaded) downloaded from tbl_call_datewise where (date between date(sdate) and date(date(tdate))) group by date;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_hourly` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_hourly`(in stdate varchar(20))
BEGIN
call proc_camp_daily(stdate);
call proc_summary(stdate);
call proc_pub_daily(stdate);
call proc_pub_summery(stdate); 
call proc_view(stdate);
call proc_op_cir_view(stdate);
call proc_op_camp_view(stdate);
call proc_op_ser_view(stdate);
call proc_cir_ser_view(stdate);
call proc_cir_camp_view(stdate);
call proc_insert_tbl_op_camp_temp(stdate);
  CALL  proc_insert_tbltemp_ser(stdate);
call proc_insert_temp_cir_ser(stdate);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_admin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_admin`(cid int,pid int,manage_type varchar(20),manage_comment varchar(100),out out_manage_comment varchar(100),out out_Status_ad int,out out_Name varchar(50),out out_email varchar(50))
BEGIN
Declare m_comment varchar(100);  
Declare comm_date date; 
declare cnt int;
set out_Name='NA';
set  out_email='NA';	
                
			select count(*) into cnt from mob_advertisement.tbl_campaign  where Status_ad=1 and Camp_id=cid;
			set m_comment=manage_comment;
			if(manage_type='approve_camp')then
			if(cnt=0) then	
				update mob_advertisement.tbl_campaign set Status_ad=mob_advertisement.func_getAdName(1) where Camp_id=cid;
				set  comm_date=date(now());
			
				insert into mob_advertisement.tbl_Admin_comment_Data (Date,camp_id,text_comment)values(comm_date,cid,m_comment) ;
				set out_manage_comment=m_comment; 
				set out_Status_ad=61;
				select tb.User_name,tb.email into out_Name,out_email from mob_advertisement.tbl_Advertiser_Details tb 
				left outer join mob_advertisement.tbl_campaign c on  tb.Aid=c.advertiser_id where c.Camp_id=cid;
                       
			elseif(cnt=1)then
				set out_Status_ad=-70;
				set out_manage_comment='campaign allready Running'; 
			end if;
			elseif(manage_type='reject_camp')then
				update mob_advertisement.tbl_campaign set Status_ad=mob_advertisement.func_getAdName(3) where Camp_id=cid;
				set  comm_date=date(now());
				insert into mob_advertisement.tbl_Admin_comment_Data (Date,camp_id,text_comment)values(comm_date,cid,m_comment) ;
				select tb.User_name,tb.email into out_Name,out_email from mob_advertisement.tbl_Advertiser_Details tb 
				left outer join mob_advertisement.tbl_campaign c on  tb.Aid=c.advertiser_id where c.Camp_id=cid;
				set out_manage_comment=m_comment; 
				set out_Status_ad=-61;
			elseif(manage_type='pause_camp')then
				if(cnt=1)then
					update mob_advertisement.tbl_campaign set Status_ad=mob_advertisement.func_getAdName(2) where Camp_id=cid;					
					set out_manage_comment=m_comment; 
					set out_Status_ad=60;
	
				elseif(cnt=0)then
					set out_Status_ad=-70;
					set out_manage_comment='campaign not running'; 
				end if;			
			elseif(manage_type='resume_camp')then
				if(cnt=0)then
					update mob_advertisement.tbl_campaign set Status_ad=mob_advertisement.func_getAdName(1) where Camp_id=cid and Status_ad=2;
					set out_manage_comment=m_comment;
					set out_Status_ad=69;	
					set out_manage_comment='campaign is resumed';
	
				elseif(cnt=1)then
					set out_Status_ad=-70;
					set out_manage_comment='campaign already running';
				end if;		
			elseif(manage_type='resume_pub')then
                        set  comm_date=date(now());
			update mob_advertisement.tbl_Publisher set Status_ad=1,start_date=comm_date where pub_id=pid;
			insert into mob_advertisement.tbl_Admin_comment_Data (Date,Pub_id,text_comment)values(comm_date,pid,m_comment) ;
			
			set out_manage_comment=m_comment;
			set out_Status_ad=61;
			
			elseif(manage_type='pause_pub')then
                       set  comm_date=date(now());
			update mob_advertisement.tbl_Publisher set Status_ad=2,End_Date=comm_date where pub_id=pid ;
			insert into mob_advertisement.tbl_Admin_comment_Data (Date,Pub_id,text_comment)values(comm_date,pid,m_comment) ;
			set out_manage_comment=m_comment; 
			set out_Status_ad=60;
			
                      else 
                       set out_Status_ad=-69;
                       set out_manage_comment='NA'; 
		end if;
			
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
                truncate table	tbl_temp_camp_tot_hits;
		truncate table  tbl_temp_camp_eff_hits;
                truncate table	tbl_temp_camp_CTA;
	insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani),sum(totalRevenue)
			from mob_advertisement.tbl_Total_Hits 
			where date(Date)=date(stdate)
			group by hour(Date),camp_id;
			
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
			select Date(stdate),hour(A.Date),A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
			from mob_advertisement.tbl_Effective_Hits A left join
			(select count(ani) Fld,count(distinct ani) uFld,hour(Date), date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by hour(Date),camp_id) 
			as FAiled on (hour(A.Date)=hour(FAiled.date) AND A.camp_id=FAiled.camp_id) 
			where date(A.Date)=date(stdate)
			group by hour(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
			select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani)
			from  mob_advertisement.tbl_CTA 
			where date(Date)=date(stdate) 
			group by hour(Date),camp_id;
			select count(stdate) into hrcnt from tbl_Campaign_Hourly where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from tbl_Campaign_Hourly where  date(Date)=date(stdate);
			end if;
			insert into tbl_Campaign_Hourly (Date, Hour,camp_id,Total_Hits,effective_Hits,unique_effective_hits,Click_to_action_hits,unique_CTA,failedHits,uniqueFailedHits,
			total_revenue,eff_revenue,Advertiser_id)
			select Date(stdate),Hr, C_ID ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid
			from
			(select A.hour Hr, tb2.camp_id C_ID,tb2.advertiser_id advid  from SpiceAdvt_Reports.tbl_hours A,(select distinct camp_id,advertiser_id from mob_advertisement.tbl_campaign)as tb2)as A1
			left outer join tbl_temp_camp_tot_hits C  on A1.Hr=C.criteria and A1.C_ID =C.camp_id
			left outer join tbl_temp_camp_eff_hits D on A1.Hr=D.criteria and A1.C_ID =D.camp_id
			left outer join tbl_temp_camp_CTA  E on A1.Hr=E.criteria and A1.C_ID =E.camp_id
			order by A1.Hr,A1.C_ID ;
			
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_operator` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_operator`(IN in_op int,IN sdate varchar(50),IN tdate varchar(50))
BEGIN
select camp_id,circle,service,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,camp_name,circle_name,service_name 
from SpiceAdvt_Reports.tbl_view where Operator=in_op ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_pub_specific` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_pub_specific`(IN in_pid int)
BEGIN
select date,Operator,camp_id,circle,service,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from tbl_view where pubID=in_pid;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_view_proc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_view_proc`(in stdate varchar(20))
BEGIN
call proc_view(stdate);
call proc_op_cir_view(stdate);
call proc_op_cir_summary_view(stdate);
call proc_op_camp_view(stdate);
call proc_op_camp_summary(stdate);
call proc_op_ser_view(stdate);
call proc_op_ser_view_summary(stdate);
call proc_cir_ser_view(stdate);
call proc_cir_ser_view_summary(stdate);
call proc_cir_camp_view(stdate);
call proc_cir_camp_view_summary(stdate);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_advance_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_advance_data`(in in_op int,in in_cir int,in in_ser int,in in_camp int,in sdate varchar(50),in tdate varchar(50))
BEGIN
declare op_flag int;
declare cir_flag int;
declare ser_flag int;
declare camp_flag int;
if(in_op=null or in_op=-1)then
	set op_flag=-1;
else 
	set op_flag=-2;
end if;
if(in_cir=null or in_cir=-1)then
	set cir_flag=-1;
else
	set cir_flag=-2;
end if;
if(in_ser=null or in_ser=-1)then
	set ser_flag=-1;
else
	set ser_flag=-2;
end if;
if(in_camp=null or in_camp=-1)then
	set camp_flag=-1;
else
	set camp_flag=-2;
end if;
select op_flag,cir_flag,ser_flag,camp_flag;
if(op_flag=-2 && ser_flag=-1 && cir_flag=-1 && camp_flag=-1) then
	select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where operator=in_op and (date between date(sdate) and date(date(tdate)));
	elseif(op_flag=-2 && ser_flag=-2 && cir_flag=-1 && camp_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where operator=in_op  and service=in_ser and (date between date(sdate) and date(date(tdate)));
	elseif(op_flag=-2 && cir_flag=-2 && ser_flag=-1 && camp_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where operator=in_op  and circle=in_cir and (date between date(sdate) and date(date(tdate)));
	elseif(op_flag=-2 && camp_flag=-2 && ser_flag=-1 && cir_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where operator=in_op  and camp_id=in_camp and (date between date(sdate) and date(date(tdate)));
	elseif(cir_flag=-2 && op_flag=-1 && ser_flag=-1 && camp_flag=-1 ) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where circle=in_cir and (date between date(sdate) and date(date(tdate)));
	elseif(cir_flag=-2 && ser_flag=-2 && op_flag=-1 && camp_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where circle=in_cir and service=in_ser  and (date between date(sdate) and date(date(tdate)));
	elseif(cir_flag=-2 && camp_flag=-2 && ser_flag=-1 && op_flag=-1 ) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where circle=in_cir and camp_id=in_camp and (date between date(sdate) and date(date(tdate)));
	elseif(ser_flag=-2 && cir_flag=-1 && camp_flag=-1 && op_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where service=in_ser and (date between date(sdate) and date(date(tdate)));
	elseif(ser_flag=-2 && camp_flag=-2 && cir_flag=-1 && op_flag=-1 ) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where service=in_ser and camp_id=in_camp  and (date between date(sdate) and date(date(tdate)));
	elseif(camp_flag=-2 && cir_flag=-1 && op_flag=-1 && ser_flag=-1 ) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where camp_id=in_camp and (date between date(sdate) and date(date(tdate)));
	elseif(op_flag=-2 && cir_flag=-2 && ser_flag=-2 && camp_flag=-1 ) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where operator=in_op and circle=in_cir and service=in_ser and (date between date(sdate) and date(date(tdate)));
	elseif(cir_flag=-2 && ser_flag=-2 && camp_flag=-2 && op_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where circle=in_cir and service=in_ser and camp_id=in_camp and (date between date(sdate) and date(date(tdate)));
	elseif(ser_flag=-2 && camp_flag=-2 && op_flag=-2 && cir_flag=-1) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where  service=in_ser and camp_id=in_camp and operator=in_op and (date between date(sdate) and date(date(tdate)));
	elseif(camp_flag=-2 && op_flag=-2 && cir_flag=-2 && ser_flag=-1 ) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where  camp_id=in_camp and operator=in_op and circle=in_cir and (date between date(sdate) and date(date(tdate)));
	elseif(op_flag=-2 && ser_flag=-2 && cir_flag=-2 && camp_flag=-2) then
		select aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus from SpiceAdvt_Reports.tbl_view where operator=in_op  and service=in_ser and circle=in_cir and camp_id=in_camp and (date between date(sdate) and date(date(tdate)));
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_AOS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_AOS`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	truncate table	tbl_temp_camp_tot_hits;
	truncate table  tbl_temp_camp_eff_hits;
	truncate table	tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.AON,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select AON from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.AON, camp_id;
              
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(A.Date),tb.AON,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
select date(A.Date),tb.AON,A.camp_id,count(*),count(distinct A.Ani)
from mob_advertisement.tbl_CTA A ,
(select AON from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.AON, camp_id;
select count(stdate) into hrcnt from tbl_Campaign_AON where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_AON where  date(Date)=date(stdate);
			end if;
insert into tbl_Campaign_AON(Date,AON,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  select Date(stdate),  A.Camp_id,AON  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id

group by   A.AON,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_arpu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_arpu`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	truncate table	tbl_temp_camp_tot_hits;
	truncate table  tbl_temp_camp_eff_hits;
	truncate table	tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.Arpu,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select Arpu from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.Arpu, camp_id;
              
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(A.Date),tb.Arpu,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
select date(A.Date),tb.Arpu,A.camp_id,count(*),count(distinct A.Ani)
from mob_advertisement.tbl_CTA A ,
(select Arpu from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.Arpu, camp_id;
select count(stdate) into hrcnt from tbl_Campaign_ARPU where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_ARPU where  date(Date)=date(stdate);
			end if;
insert into tbl_Campaign_ARPU(Date,ARPU,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  select Date(stdate),  A.Camp_id,Arpu  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id

group by   A.Arpu,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_circle` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_circle`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	truncate table	tbl_temp_camp_tot_hits;
	truncate table  tbl_temp_camp_eff_hits;
	truncate table	tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.Circle,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select Circle from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate)  group by tb.Circle, camp_id;
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(date),tb.Circle,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
	    select Date(A.Date),tb.Circle,camp_id,count(*),count(distinct A.Ani)
            from mob_advertisement.tbl_CTA A ,
            (select Circle from mob_advertisement.tbl_campaign) as tb
            where date(A.Date)=date(stdate) group by tb.Circle, camp_id;
            
           
select count(stdate) into hrcnt from tbl_Campaign_circle where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_circle where  date(Date)=date(stdate);
			end if;
insert into tbl_Campaign_circle(Date,circle,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  select Date(stdate),Circle , A.Camp_id  ,
ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   
  left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
group by   A.Circle,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_cir_date_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_cir_date_view`(IN stdate varchar(50),IN tDate varchar(50),IN in_ser int,IN in_cir int, IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,circle_name,status_name
from SpiceAdvt_Reports.tbl_cir_ser_view
where date >(CURDATE() - INTERVAL 7 DAY) and service=in_ser and circle=in_cir and camp_id=in_camp order by Date desc;
else
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,circle_name,status_name
from SpiceAdvt_Reports.tbl_cir_ser_view
where (date between date(stdate) and date(date(tDate))) and service=in_ser and circle=in_cir and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_daily`(in stdate varchar(20))
BEGIN
	declare dcnt int;
	declare varFailedHits int;
	declare uniFailedHits int;
		
	delete from tbl_temp_camp_tot_hits;
	delete from tbl_temp_camp_eff_hits;
	delete from tbl_temp_camp_CTA;
	insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
	select Date(date),0,camp_id,count(*),count(distinct Ani),sum(totalRevenue) 
	from mob_advertisement.tbl_Total_Hits 
	where date(Date)=date(stdate)
	group by camp_id;
	insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
	select date(date),0,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join 
	(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id) 
	as FAiled on
	(date(A.Date)=dt AND A.camp_id=FAiled.camp_id)
	where date(A.Date)=date(stdate)
	group by A.camp_id;
	insert into tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
	select Date(date),0,camp_id,count(*),count(distinct Ani)
	from  mob_advertisement.tbl_CTA 
	where date(Date)=date(stdate)
	group by camp_id;
	select count(1) into dcnt from tbl_Camp_daily where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_Camp_daily where  date(Date)=date(stdate);
	end if;
	insert into tbl_Camp_daily (Date,camp_id,Total_Hits,effective_hits,Total_unique_hits,unique_effective_Hits,
	Click_to_action_hits,uniq_CTA,failedHits,uniqueFailedHits,total_revenue,eff_revenue,Advertiser_id)
	select Date(stdate), A.Camp_id ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),
	ifnull(uniq_eff_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
	ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.Advertiser_id
	from mob_advertisement.tbl_campaign A
	left outer join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
	left outer join tbl_temp_camp_eff_hits D on D.camp_id=A.Camp_id
	left outer join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_Gender` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_Gender`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	truncate table	tbl_temp_camp_tot_hits;
	truncate table  tbl_temp_camp_eff_hits;
	truncate table	tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.Gender,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select Gender from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.Gender, camp_id;
              
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(A.Date),tb.Gender,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
select date(A.Date),tb.Gender,A.camp_id,count(*),count(distinct A.Ani)
from mob_advertisement.tbl_CTA A ,
(select Gender from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.Gender, camp_id;
select count(stdate) into hrcnt from tbl_Campaign_Gender where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_Gender where  date(Date)=date(stdate);
			end if;
insert into tbl_Campaign_Gender(Date,Gender,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  select Date(stdate),  A.Camp_id,N_Language  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
group by   A.Gender,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_hourly` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_hourly`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
                truncate table	SpiceAdvt_Reports.tbl_temp_camp_tot_hits;
		truncate table  SpiceAdvt_Reports.tbl_temp_camp_eff_hits;
                truncate table	SpiceAdvt_Reports.tbl_temp_camp_CTA;
	insert into SpiceAdvt_Reports.tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
			select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani),sum(totalRevenue)
			from mob_advertisement.tbl_Total_Hits 
			where date(Date)=date(stdate)
			group by hour(Date),camp_id;
			
			
			insert into SpiceAdvt_Reports.tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
			select Date(stdate),hour(A.Date),A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
			from mob_advertisement.tbl_Effective_Hits A left join
			(select count(ani) Fld,count(distinct ani) uFld,hour(Date), date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by hour(Date),camp_id) 
			as FAiled on (hour(A.Date)=hour(FAiled.date) AND A.camp_id=FAiled.camp_id) 
			where date(A.Date)=date(stdate)
			group by hour(A.Date),A.camp_id;
			insert into SpiceAdvt_Reports.tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
			select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani)
			from  mob_advertisement.tbl_CTA 
			where date(Date)=date(stdate) 
			group by hour(Date),camp_id;
			select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_Campaign_Hourly where  date(Date)=date(stdate);
			if(hrcnt>0)then
			delete from SpiceAdvt_Reports.tbl_Campaign_Hourly where  date(Date)=date(stdate);
			end if;
			insert into SpiceAdvt_Reports.tbl_Campaign_Hourly (Date, Hour,camp_id,Total_Hits,effective_Hits,unique_effective_hits,Click_to_action_hits,unique_CTA,failedHits,uniqueFailedHits,
			total_revenue,eff_revenue,Advertiser_id)
			select Date(stdate),Hr, C_ID ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(effRevenue,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid
			from
			(select A.hour Hr, tb2.camp_id C_ID,tb2.advertiser_id advid  from SpiceAdvt_Reports.tbl_hours A,(select distinct camp_id,advertiser_id from mob_advertisement.tbl_campaign)as tb2)as A1
			left outer join SpiceAdvt_Reports.tbl_temp_camp_tot_hits C  on A1.Hr=C.criteria and A1.C_ID =C.camp_id
			left outer join SpiceAdvt_Reports.tbl_temp_camp_eff_hits D on A1.Hr=D.criteria and A1.C_ID =D.camp_id
			left outer join SpiceAdvt_Reports.tbl_temp_camp_CTA  E on A1.Hr=E.criteria and A1.C_ID =E.camp_id
			order by A1.Hr,A1.C_ID ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_Language` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_Language`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	truncate table	tbl_temp_camp_tot_hits;
	truncate table  tbl_temp_camp_eff_hits;
	truncate table	tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.N_Language,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select N_Language from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.N_Language, camp_id;
              
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(A.Date),tb.N_Language,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
select date(A.Date),tb.N_Language,A.camp_id,count(*),count(distinct A.Ani)
from mob_advertisement.tbl_CTA A ,
(select N_Language from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.N_Language, camp_id;
select count(stdate) into hrcnt from tbl_Campaign_Language where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_Language where  date(Date)=date(stdate);
			end if;
insert into tbl_Campaign_Language(Date,Language,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  select Date(stdate),  A.Camp_id,N_Language  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
group by   A.N_Language,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_operator` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_operator`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	delete from tbl_temp_camp_tot_hits;
	delete from tbl_temp_camp_eff_hits;
	delete from tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select operator from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.operator, camp_id;
              
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(date),tb.operator,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani)
from mob_advertisement.tbl_CTA A ,
(select operator from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.operator, camp_id;
select count(stdate) into hrcnt from tbl_Campaign_Operator where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_Operator where  date(Date)=date(stdate);
			end if;
insert into tbl_campaign_opsummary(Date,Operator,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  select Date(stdate),Operator,A.Camp_id,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
group by   A.Operator,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_Service` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_Service`(in stdate varchar(20))
BEGIN
declare hrcnt int;
	truncate table	tbl_temp_camp_tot_hits;
	truncate table  tbl_temp_camp_eff_hits;
	truncate table	tbl_temp_camp_CTA;
insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
select date(A.Date),tb.Service,A.camp_id,count(*),count(distinct A.Ani),sum(totalRevenue) 
from mob_advertisement.tbl_Total_Hits A ,
(select Service from mob_advertisement.tbl_campaign) as tb
where date(A.Date)=date(stdate) group by tb.Service, camp_id;
              
insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue,failedHits,uniqueFailedHits)
select date(date),tb.Service,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld
from mob_advertisement.tbl_Effective_Hits A
left outer join mob_advertisement.tbl_campaign tb on A.Camp_id=tb.camp_id
left join
(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),camp_id)
as FAiled on
(date(A.Date)=dt AND A.camp_id=FAiled.camp_id) where date(A.Date)=date(stdate)
group by date(A.Date),A.camp_id;
insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
	    select Date(A.Date),tb.Service,camp_id,count(*),count(distinct A.Ani)
            from mob_advertisement.tbl_CTA A ,
            (select Service from mob_advertisement.tbl_campaign) as tb
            where date(A.Date)=date(stdate) group by tb.Service, camp_id;
            
           
select count(stdate) into hrcnt from tbl_Campaign_Service where  date(Date)=date(stdate);
			if(hrcnt>0)then
				delete from tbl_Campaign_Service where  date(Date)=date(stdate);
			end if;
insert into tbl_Campaign_Service(date,Service,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id)
  
select Date(stdate),  A.Camp_id,Operator  ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),A.advertiser_id
  from mob_advertisement.tbl_campaign A
   left join tbl_temp_camp_tot_hits C on C.camp_id =A.Camp_id
  left  join tbl_temp_camp_eff_hits D on D.camp_id =A.Camp_id
  left join tbl_temp_camp_CTA  E  on E.camp_id =A.Camp_id
group by   A.Service,A.Camp_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_circle_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_circle_daily`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_tot_hits;
	truncate table  SpiceAdvt_Reports.tbl_temp_camp_eff_hits;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_CTA;
	insert into SpiceAdvt_Reports.tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
	select Date(stdate),circle,camp_id,count(*),count(distinct Ani),sum(totalRevenue)
	from mob_advertisement.tbl_Total_Hits 
	where date(Date)=date(stdate)
	group by circle,camp_id;
	
	insert into SpiceAdvt_Reports.tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
	
	
	select Date(stdate),A.circle,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join
	(select count(ani) Fld,count(distinct ani) uFld,circle, date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by operator,camp_id) 
	as FAiled on (A.circle=FAiled.circle  AND A.camp_id=FAiled.camp_id) 
	where date(A.Date)=date(stdate)
	group by A.circle,A.camp_id;
	
	insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
	select date(A.Date),tb.Circle,A.camp_id,count(*),count(distinct A.Ani)
	from mob_advertisement.tbl_CTA A ,
	(select Circle from mob_advertisement.tbl_campaign) as tb
	where date(A.Date)=date(stdate) group by tb.Circle, camp_id;
	select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_Campaign_circle where  date(Date)=date(stdate);
	if(hrcnt>0)then
	delete from SpiceAdvt_Reports.tbl_Campaign_circle where  date(Date)=date(stdate);
	end if;
	
	insert into SpiceAdvt_Reports.tbl_Campaign_circle(date,Circle,cir_name,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,
	Click_to_action,unique_Click_to_action,
	failedHits,uniqueFailedHits,Total_Revenue,Eff_Revenue,Advertiser_id,Status,unique_eff_Hits)
	select Date(stdate),cir,ocirName,C_ID,campName,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
	ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid,StatusAd,ifnull(uniq_eff_hits,0)
	from
	(select A.Circle_Code cir,A.Circle_Name cirName, tb2.camp_id C_ID,tb2.Name campName,tb2.Status_ad  StatusAd,tb2.advertiser_id advid from mob_advertisement.tbl_Circle_Details A left join  mob_advertisement.tbl_campaign tb2 on tb2.Circle=pow(2,Circle_Code-1))as A1
	left outer join SpiceAdvt_Reports.tbl_temp_camp_tot_hits C  on A1.cir=C.criteria and A1.C_ID =C.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_eff_hits D on A1.cir=D.criteria and A1.C_ID =D.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_CTA  E on A1.cir=E.criteria and A1.C_ID =E.camp_id
	order by A1.cir,A1.C_ID ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_circle_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_circle_summary`(in stdate varchar(25))
BEGIN
declare cnt int;
	
		select count(1) into cnt from tbl_campaign_cir_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_campaign_cir_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_camp_cir_summary;
		insert into tbl_temp_camp_cir_summary(Date,circle,cir_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status)
		
		select date(stdate),A.Circle,cir_name,tb.camp_id,tb.Name,
		ifnull(sum(A.Total_Hits),0),
		ifnull(sum(A.effective_Hits),0),
		ifnull(sum(A.Total_unique_hits),0),
		ifnull(sum(A.unique_eff_Hits),0),
		ifnull(sum(A.Total_budget),0),
		ifnull(sum(A.Left_budget),0),
		ifnull(sum(A.Used_Budget),0),
		ifnull(sum(A.Click_to_action),0),
		ifnull(sum(A.unique_Click_to_action),0),
		ifnull(sum(A.failedHits),0),
		ifnull(sum(A.uniqueFailedHits),0),
		ifnull(sum(A.total_revenue),0),
		ifnull(sum(A.eff_revenue),0),
		tb.Advertiser_id,
		tb.Status_ad 
		from  tbl_Campaign_circle A 
		left outer join mob_advertisement.tbl_campaign tb  on 
		tb.Circle=pow(2,A.Circle-1)
		group by A.Circle,tb.camp_id;	
		
		
		insert into tbl_campaign_cir_summary(Date,circle,cir_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status)
		
		select Date,circle,cir_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status
		from tbl_temp_camp_cir_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_camp_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_camp_criteria`(IN stdate varchar(50),IN tDate varchar(50),IN in_cir int,IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,camp_id cid,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,camp_name,circle_name,Status_name
from SpiceAdvt_Reports.tbl_cir_camp_view
where date >(CURDATE() - INTERVAL 7 DAY) and circle=in_cir and camp_id=in_camp order by Date desc;
else
select date(date) stdate,camp_id cid,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,camp_name,circle_name,Status_name
from SpiceAdvt_Reports.tbl_cir_camp_view
where (date between date(stdate) and date(date(tDate))) and circle=in_cir and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_camp_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_camp_view`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_cir_camp_view where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_cir_camp_view where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_cir_camp_view(date,camp_id,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,Status_name)
select date(stdate),camp_id,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,status_name from SpiceAdvt_Reports.tbl_view where date(date)=date(stdate);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_camp_view_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_camp_view_summary`(in stdate varchar(20))
BEGIN
declare cnt int;
declare varFailedHits int;
declare uniFailedHits int;

		select count(1) into cnt from tbl_cir_camp_view_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_cir_camp_view_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_cir_camp_view_summary;
insert into tbl_temp_cir_camp_view_summary
(date,camp_id,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,status_name)
select date(stdate),camp_id,circle,aid,pubID,ifnull(sum(Total_Hits),0),
ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),ifnull(sum(unique_eff_Hits),0),
ifnull(sum(Total_Revenue),0),ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),ifnull(sum(unique_Click_to_action),0),AdStatus,camp_name,circle_name,status_name	from tbl_cir_camp_view				

group by circle,camp_id;	
insert into tbl_cir_camp_view_summary(date,camp_id,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,status_name)
select date,camp_id,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,status_name
from tbl_temp_cir_camp_view_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_ser_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_ser_criteria`(IN stdate varchar(50),IN tDate varchar(50),IN in_cir int,IN rtype int,IN in_ser int)
BEGIN
if(rtype=0)then
select date(date) stdate,camp_id cid,circle circle,service service,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,camp_name,circle_name,service_name,status_name
from SpiceAdvt_Reports.tbl_cir_ser_temp
where date >(CURDATE() - INTERVAL 7 DAY) and circle=in_cir and service=in_ser order by Date desc;
else
select date(date) stdate,camp_id cid,circle circle,service service,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,camp_name,circle_name,service_name,status_name
from SpiceAdvt_Reports.tbl_cir_ser_temp
where (date between date(stdate) and date(date(tDate))) and circle=in_cir and service=in_ser order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_ser_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_ser_view`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_cir_ser_view where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_cir_ser_view where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_cir_ser_view(date,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,service_name,status_name)
select date(stdate),camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,service_name,status_name from SpiceAdvt_Reports.tbl_view;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_ser_view_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_ser_view_summary`(in stdate varchar(20))
BEGIN
declare cnt int;
declare varFailedHits int;
declare uniFailedHits int;
			insert into SpiceAdvt_Reports.tbl_proc_log_track(proc_name,Date) values('proc_cir_ser_view_summary',stdate);
		select count(1) into cnt from tbl_cir_ser_view_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_cir_ser_view_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_cir_ser_view_summary;
insert into tbl_temp_cir_ser_view_summary
(date,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,service_name,status_name)
select date(stdate),camp_id,circle,service,aid,pubID,ifnull(sum(Total_Hits),0),
ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),ifnull(sum(unique_eff_Hits),0),
ifnull(sum(Total_Revenue),0),ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),ifnull(sum(unique_Click_to_action),0),AdStatus,camp_name,circle_name,service_name,status_name	from tbl_cir_ser_view				

group by circle,service;	
insert into tbl_cir_ser_view_summary(date,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,camp_name,circle_name,service_name,status_name)
select date,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus ,camp_name,circle_name,service_name,status_name
from tbl_temp_cir_ser_view_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_summary`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_tot_hits;
	truncate table  SpiceAdvt_Reports.tbl_temp_camp_eff_hits;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_CTA;
	insert into SpiceAdvt_Reports.tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
	select Date(stdate),circle,camp_id,count(*),count(distinct Ani),sum(totalRevenue)
	from mob_advertisement.tbl_Total_Hits 
	where date(Date)=date(stdate)
	group by circle,camp_id;
	
	insert into SpiceAdvt_Reports.tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
	select Date(stdate),A.circle,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join
	(select count(ani) Fld,count(distinct ani) uFld,circle, date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by circle,camp_id) 
	as FAiled on (A.circle=FAiled.circle  AND A.camp_id=FAiled.camp_id) 
	where date(A.Date)=date(stdate)
	group by A.circle,A.camp_id;
	
	insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
	select date(A.Date),tb.Circle,A.camp_id,count(*),count(distinct A.Ani)
	from mob_advertisement.tbl_CTA A ,
	(select Circle from mob_advertisement.tbl_campaign) as tb
	where date(A.Date)=date(stdate) group by tb.Circle, camp_id;
	select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_Campaign_circle where  date(Date)=date(stdate);
	if(hrcnt>0)then
	delete from SpiceAdvt_Reports.tbl_Campaign_circle where  date(Date)=date(stdate);
	end if;
	
	insert into SpiceAdvt_Reports.tbl_Campaign_circle(date,circle,cir_name,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,
	Click_to_action,unique_Click_to_action,
	failedHits,uniqueFailedHits,Total_Revenue,Eff_Revenue,Advertiser_id,Status,unique_eff_Hits)
	select Date(stdate),cir,cirName,C_ID,campName,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
	ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid,StatusAd,ifnull(uniq_eff_hits,0)
	from
	(select A.Circle_Code cir,A.Circle_Name cirName, tb2.camp_id C_ID,tb2.Name campName,tb2.Status_ad  StatusAd,tb2.advertiser_id advid from mob_advertisement.tbl_Circle_Details A left join  mob_advertisement.tbl_campaign tb2 on tb2.Circle=pow(2,Circle_Code-1))as A1
	left outer join SpiceAdvt_Reports.tbl_temp_camp_tot_hits C  on A1.cir=C.criteria and A1.C_ID =C.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_eff_hits D on A1.cir=D.criteria and A1.C_ID =D.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_CTA  E on A1.cir=E.criteria and A1.C_ID =E.camp_id
	order by A1.cir,A1.C_ID ;
	
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_view`(IN in_cir int,IN in_type varchar(50))
BEGIN
if(in_type='camp')then
select date,camp_id,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,CAST(unique_eff_Hits AS UNSIGNED)unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,camp_name from tbl_cir_camp_view_summary where circle=in_cir group by camp_id;
elseif(in_type='service')then
select date,service,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,CAST(unique_eff_Hits AS UNSIGNED)unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,service_name from tbl_cir_ser_view_summary where circle=in_cir group by service;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_fetch_camp_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_fetch_camp_summary`(in type int,in RoleType int,in Uid int)
BEGIN
if(RoleType=2)then
if(type=0)  then
select A.Camp_id,A.Name name,A.advertiser_id advt_id, cta_flag,date(start_date) start_date,date(end_date) end_date,ifnull(eff_revenue,0) eff_revenue,
ifnull(effective_Hits,0) effective_Hits,ifnull(left_budget,0) left_budget,ifnull(status_ad_Name,0) Status,ifnull(today_used_Budget,0) today_used_Budget, 
ifnull(A.Total_budget,0) Total_budget, ifnull(Total_Hits,0) Total_Hits,ifnull(B.eff_revenue,0) totalUsedBudget
,ifnull(Total_unique_hits,0) Total_unique_hits, ifnull(unique_Click_to_action,0) unique_Click_to_action, 
ifnull(unique_effective_Hits,0) unique_effective_Hits
from mob_advertisement.tbl_campaign A left outer join
SpiceAdvt_Reports.tbl_Campaign_summary B on B.camp_id=A.Camp_id and B.date=date(now())
left join mob_advertisement.tbl_status_ad_details on Status_ad_code=Status_ad 
where  A.advertiser_id=Uid
order by Status_ad_code,Total_Hits desc;
end if;	
elseif(RoleType=3)then
if(type=0)  then
select A.Name name, ifnull(Total_Hits,0) Total_Hits,ifnull(B.Used_Budget,0) Budget 
from mob_advertisement.tbl_campaign A left outer join
tbl_Camp_daily B on B.camp_id=A.Camp_id 
where B.Date=CURDATE() and A.advertiser_id=Uid group by A.Name order by B.Used_Budget,B.Total_Hits desc limit 5 ;
elseif(type=1)then
select A.Name name, ifnull(Total_Hits,0) Total_Hits,ifnull(B.Total_budget,0) Budget 
from mob_advertisement.tbl_campaign A left outer join
tbl_Campaign_summary B on B.camp_id=A.Camp_id 
where  A.advertiser_id=Uid and Total_Hits>0 group by A.Name order by B.Total_budget,B.Total_Hits  limit 5 ;
end if;		
end if;	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_fetch_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_fetch_dashboard`(in type int,in RoleType int,in Uid int)
BEGIN
	if(RoleType=1 || RoleType=4)then
		if(type=0)  then
			
			
			
			select TotalCampaigns, TotalAdvertiser, TotalPublishers, TotalHits, TotalBudgets,TotalSpending,newcampaign from
			(select count(1) TotalCampaigns,sum(Total_Budget) TotalBudgets from mob_advertisement.tbl_campaign) as A ,
			(select count(1) TotalPublishers from mob_advertisement.tbl_Publisher) as B,
			(select count(1) TotalAdvertiser from mob_advertisement.tbl_Advertiser_Details) as C,
			(select sum(total_revenue) TotalSpending,sum(Total_Hits) TotalHits from SpiceAdvt_Reports.tbl_Campaign_summary where date(date)=curdate())  as D,
			(select count(*) newcampaign from mob_advertisement.tbl_campaign where Status_ad in (mob_advertisement.func_getAdName(0),mob_advertisement.func_getAdName(5)))as E;
		end if;	
	
	elseif(RoleType=2)then
		if(type=0)  then
			select A.Name name, ifnull(Total_Hits,0) Total_Hits,ifnull(B.eff_revenue,0) Budget 
			from mob_advertisement.tbl_campaign A left outer join
			SpiceAdvt_Reports.tbl_Camp_daily B on B.camp_id=A.Camp_id 
			where B.Date=CURDATE() and A.advertiser_id=Uid and A.Status_ad=mob_advertisement.func_getAdName(1) group by A.Name 
			order by B.Used_Budget,B.Total_Hits desc limit 5 ;
			
			
		elseif(type=1)then
				
			
			select A.Name name, ifnull(Total_Hits,0) Total_Hits,ifnull(B.eff_revenue,0) Budget 
			from mob_advertisement.tbl_campaign A left outer join
			SpiceAdvt_Reports.tbl_Campaign_summary B on B.camp_id=A.Camp_id 
			where  A.advertiser_id=Uid and B.date=date(now()) order by Total_Hits desc limit 5;
		end if;	
	
	elseif(RoleType=3)then
		if(type=0)  then
			select A.Name name, ifnull(Total_Hits,0) Total_Hits,ifnull(B.eff_revenue,0) Budget 
			from mob_advertisement.tbl_campaign A left outer join
			SpiceAdvt_Reports.tbl_Camp_daily B on B.camp_id=A.Camp_id 
			where B.Date=CURDATE() and A.advertiser_id=Uid group by A.Name order by B.Used_Budget,B.Total_Hits desc limit 5 ;
			
			
		elseif(type=1)then
				
			
			select A.Name name, ifnull(Total_Hits,0) Total_Hits,ifnull(B.eff_revenue,0) Budget 
			from mob_advertisement.tbl_campaign A left outer join
			SpiceAdvt_Reports.tbl_Campaign_summary B on B.camp_id=A.Camp_id 
			where  A.advertiser_id=Uid and Total_Hits>0 group by A.Name order by B.Total_budget,B.Total_Hits desc limit 5 ;
		end if;	
	
	
	end if;	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_insert_tbltemp_ser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_insert_tbltemp_ser`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_op_ser_temp where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_op_ser_temp where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_op_ser_temp(date,Operator,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,service_name,status_name)
select date(stdate),Operator,service,aid,pubID,
ifnull(sum(Total_Hits),0), ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),
ifnull(sum(unique_eff_Hits),0),ifnull(sum(Total_Revenue),0),
ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),
ifnull(sum(unique_Click_to_action),0),
AdStatus,operator_name,status_name,service_name
from SpiceAdvt_Reports.tbl_view 
where date(date)=date(stdate)  group by operator;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_insert_tbl_op_camp_temp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_insert_tbl_op_camp_temp`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_op_camp_temp where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_op_camp_temp where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_op_camp_temp(date,Operator,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,status_name,circle_name,service_name)
select date(stdate),Operator,circle,service,aid,pubID,
ifnull(sum(Total_Hits),0), ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),
ifnull(sum(unique_eff_Hits),0),ifnull(sum(Total_Revenue),0),
ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),
ifnull(sum(unique_Click_to_action),0),
AdStatus,operator_name,status_name,circle_name,service_name
from SpiceAdvt_Reports.tbl_view 
where date(date)=date(stdate)  group by operator,circle,service;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_insert_temp_cir_ser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_insert_temp_cir_ser`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_cir_ser_temp where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_cir_ser_temp where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_cir_ser_temp(date,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,circle_name,service_name,status_name)
select date(date) stdate,circle circle,service service,aid,pubID,
ifnull(sum(Total_Hits),0) Total_Hits,ifnull(sum(Total_unique_hits),0) Total_unique_hits,ifnull(sum(effective_Hits),0) effective_Hits,
ifnull(sum(unique_eff_Hits),0) unique_eff_Hits,ifnull(sum(Total_Revenue),0) Total_Revenue,ifnull(sum(Eff_Revenue),0) Eff_Revenue,
ifnull(sum(failedHits),0) failedHits,ifnull(sum(uniqueFailedHits),0) uniqueFailedHits,
ifnull(sum(Click_to_action),0) Click_to_action,ifnull(sum(unique_Click_to_action),0) unique_Click_to_action,
AdStatus AdStatus,circle_name,service_name,status_name
from SpiceAdvt_Reports.tbl_cir_ser_view
where  date(date)=date(stdate) group by circle  ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_month_camp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_month_camp`(in stdate varchar(20))
BEGIN
declare mmcnt int;
declare varFailedHits int;
declare uniFailedHits int;
                truncate table	tbl_temp_camp_tot_hits;
		truncate table  tbl_temp_camp_eff_hits;
                truncate table	tbl_temp_camp_CTA;
		insert into tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits, total_revenue)
			select Year(stdate),month(Date),camp_id,count(*),count(distinct Ani),sum(totalRevenue)
			from mob_advertisement.tbl_Total_Hits 
			where year(Date)=year(stdate)
			group by month(Date),camp_id;
			
			insert into tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits,eff_revenue, failedHits, uniqueFailedHits)
			select Year(stdate),month(Date),A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
			from mob_advertisement.tbl_Effective_Hits  A left join 
			(select count(ani) Fld,count(distinct ani) uFld,month(Date) MM, camp_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by Month(Date),camp_id) 
			as FAiled on
			(month(A.Date)=MM AND A.camp_id=FAiled.camp_id)
			where  year(Date)=year(stdate)
			group by month(A.Date),A.camp_id;
			insert into tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
			select Year(stdate),month(Date),camp_id,count(*),count(distinct Ani)
			from mob_advertisement.tbl_CTA
			where  year(Date)=year(stdate)
			group by month(Date),camp_id;
			select count(stdate) into mmcnt from tbl_Campaign_Monthly where Year=year(stdate) and month= month(stdate);
			select 'old',mmcnt;
			if(mmcnt>0)then
			delete from tbl_Campaign_Monthly where  Year=year(stdate) and month= month(stdate);
			
			end if;
			insert into tbl_Campaign_Monthly (Year,Month,camp_id,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,Advertiser_id)
			select year(concat(stdate,'-00-00')),MM, C_ID ,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(uniq_eff_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid
			from
			(select A.month MM, tb2.camp_id C_ID ,tb2.advertiser_id advid from SpiceAdvt_Reports.tbl_months A,(select distinct camp_id,advertiser_id from mob_advertisement.tbl_campaign) as tb2 ) as A1
			left outer join tbl_temp_camp_tot_hits C  on A1.MM=C.criteria and A1.C_ID =C.camp_id
			left outer join tbl_temp_camp_eff_hits D on A1.MM=D.criteria and A1.C_ID =D.camp_id
			left outer join tbl_temp_camp_CTA  E on A1.MM=E.criteria and A1.C_ID =E.camp_id
			where MM=month(stdate)
			order by A1.MM,A1.C_ID ;
				END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_operator_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_operator_daily`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_tot_hits;
	truncate table  SpiceAdvt_Reports.tbl_temp_camp_eff_hits;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_CTA;
	insert into SpiceAdvt_Reports.tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
	select Date(stdate),operator,camp_id,count(*),count(distinct Ani),sum(totalRevenue)
	from mob_advertisement.tbl_Total_Hits 
	where date(Date)=date(stdate)
	group by operator,camp_id;
	
	insert into SpiceAdvt_Reports.tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
	
	
	select Date(stdate),A.operator,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join
	(select count(ani) Fld,count(distinct ani) uFld,operator, date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by operator,camp_id) 
	as FAiled on (A.operator=FAiled.operator  AND A.camp_id=FAiled.camp_id) 
	where date(A.Date)=date(stdate)
	group by A.operator,A.camp_id;
	
	insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
	select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani)
	from mob_advertisement.tbl_CTA A ,
	(select operator from mob_advertisement.tbl_campaign) as tb
	where date(A.Date)=date(stdate) group by tb.operator, camp_id;
	select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_Campaign_Operator where  date(Date)=date(stdate);
	if(hrcnt>0)then
	delete from SpiceAdvt_Reports.tbl_Campaign_Operator where  date(Date)=date(stdate);
	end if;
	
	insert into SpiceAdvt_Reports.tbl_Campaign_Operator(date,Operator,op_name,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,
	Click_to_action,unique_Click_to_action,
	failedHits,uniqueFailedHits,Total_Revenue,Eff_Revenue,Advertiser_id,Status,unique_eff_Hits)
	select Date(stdate),Op,opName,C_ID,campName,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
	ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid,StatusAd,ifnull(uniq_eff_hits,0)
	from
	(select A.Operator_Code Op,A.Operator_Name opName, tb2.camp_id C_ID,tb2.Name campName,tb2.Status_ad  StatusAd,tb2.advertiser_id advid from mob_advertisement.tbl_Operator_Details A left join  mob_advertisement.tbl_campaign tb2 on tb2.Operator=pow(2,Operator_Code-1))as A1
	left outer join SpiceAdvt_Reports.tbl_temp_camp_tot_hits C  on A1.Op=C.criteria and A1.C_ID =C.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_eff_hits D on A1.Op=D.criteria and A1.C_ID =D.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_CTA  E on A1.Op=E.criteria and A1.C_ID =E.camp_id
	order by A1.Op,A1.C_ID ;
	
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_operator_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_operator_summary`( in stdate varchar(25))
BEGIN
declare cnt int;
	
		select count(1) into cnt from tbl_campaign_op_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_campaign_op_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_camp_op_summary;
		insert into tbl_temp_camp_op_summary(Date,Operator,op_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status)
		
		select date(stdate),A.Operator,op_name,tb.camp_id,tb.Name,
		ifnull(sum(A.Total_Hits),0),
		ifnull(sum(A.effective_Hits),0),
		ifnull(sum(A.Total_unique_hits),0),
		ifnull(sum(A.unique_eff_Hits),0),
		ifnull(sum(A.Total_budget),0),
		ifnull(sum(A.Left_budget),0),
		ifnull(sum(A.Used_Budget),0),
		ifnull(sum(A.Click_to_action),0),
		ifnull(sum(A.unique_Click_to_action),0),
		ifnull(sum(A.failedHits),0),
		ifnull(sum(A.uniqueFailedHits),0),
		ifnull(sum(A.total_revenue),0),
		ifnull(sum(A.eff_revenue),0),
		tb.Advertiser_id,
		tb.Status_ad 
		from  tbl_Campaign_Operator A 
		left outer join mob_advertisement.tbl_campaign tb  on 
		tb.Operator=pow(2,A.Operator-1)
		group by A.Operator,tb.camp_id;	
		
		
		insert into tbl_campaign_op_summary(Date,Operator,op_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status)
		
		select Date,Operator,op_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status
		from tbl_temp_camp_op_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_operator_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_operator_view`(IN type varchar(20))
BEGIN
if(type='circle')then
select date,circle,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status from tbl_Campaign_circle;
elseif(type='operator')then
select Date,Operator,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status from tbl_campaign_op_summary;
elseif(type='service')then
select date,Service,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status from tbl_Campaign_Service;
elseif(type='campaign')then
select date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Total_budget,left_budget,today_used_Budget,Click_to_action,unique_Click_to_action,total_revenue,eff_revenue,failedHits,uniqueFailedHits,Advertiser_id,Status from tbl_Campaign_summary;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_oper_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_oper_view`(IN in_op int,IN in_type varchar(50))
BEGIN
if(in_type='circle')then
select date(date),circle,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,CAST(unique_eff_Hits AS UNSIGNED)unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,circle_name from tbl_op_cir_view_summary where Operator=in_op group by circle;
elseif(in_type='camp')then
select date(date),camp_id,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,CAST(unique_eff_Hits AS UNSIGNED)unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,camp_name from tbl_op_camp_view_summary where Operator=in_op group by camp_id;
elseif(in_type='service')then
select date(date),service,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,CAST(unique_eff_Hits AS UNSIGNED)unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,service_name from tbl_op_ser_view_summary where Operator=in_op group by service ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_camp_cir_date_ciew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_camp_cir_date_ciew`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_cir int, IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and circle=in_cir and camp_id=in_camp order by Date desc;
else
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and circle=in_cir and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_camp_cir_date_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_camp_cir_date_view`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_cir int, IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and circle=in_cir and camp_id=in_camp order by Date desc;
else
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and circle=in_cir and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_camp_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_camp_criteria`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN rtype int,IN in_camp int)
BEGIN
if(rtype=0)then
select date(date) stdate,camp_id cid,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and camp_id=in_camp order by Date desc;
else
select date(date) stdate,camp_id cid,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_camp_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_camp_summary`(IN stdate varchar(50))
BEGIN
declare cnt int;
declare varFailedHits int;
declare uniFailedHits int;
	insert into SpiceAdvt_Reports.tbl_proc_log_track(proc_name,Date) values('proc_op_camp_summary',stdate);
		select count(1) into cnt from tbl_op_camp_view_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_op_camp_view_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_op_camp_view_summary;
insert into tbl_temp_op_camp_view_summary(date,Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,status_name,circle_name,service_name)	
select date(stdate),Operator,camp_id,circle,service,aid,pubID,ifnull(sum(Total_Hits),0),ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),ifnull(sum(unique_eff_Hits),0),ifnull(sum(Total_Revenue),0),ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),ifnull(sum(unique_Click_to_action),0),AdStatus,operator_name,camp_name,status_name,circle_name,service_name from tbl_op_camp_view

group by operator,camp_id;
insert into tbl_op_camp_view_summary(date,Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,status_name,circle_name,service_name)
select date(stdate),Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,status_name,circle_name,service_name from tbl_temp_op_camp_view_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_camp_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_camp_view`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_op_camp_view where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_op_camp_view where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_op_camp_view(date,Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,status_name,circle_name,service_name)

select date(stdate),Operator,camp_id,circle,service,aid,pubID,ifnull(Total_Hits,0),
ifnull(Total_unique_hits,0),ifnull(effective_Hits,0),
ifnull(unique_eff_Hits,0),ifnull(Total_Revenue,0),
ifnull(Eff_Revenue,0),ifnull(failedHits,0),
ifnull(uniqueFailedHits,0),ifnull(Click_to_action,0),
ifnull(unique_Click_to_action,0),
AdStatus,operator_name,camp_name,status_name,circle_name,service_name from SpiceAdvt_Reports.tbl_view 
where date(date)=date(stdate) group by camp_id;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cam_circ` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cam_circ`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_cir int,IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,camp_id cid,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and circle=in_cir and camp_id=in_camp order by Date desc;
else
select date(date) stdate,camp_id cid,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and circle=in_cir and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cir` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cir`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_cir int,IN in_ser int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,1 cid,"Abc" camp_name,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name,camp_name
from SpiceAdvt_Reports.tbl_op_camp_temp
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and circle=in_cir and service=in_ser order by Date desc;
else
select date(date) stdate,circle circle,1 cid,"Abc" camp_name,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_temp
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and circle=in_cir and service=in_ser order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cir_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cir_criteria`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_cir int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and circle=in_cir order by Date desc;
else
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and circle=in_cir order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cir_retser_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cir_retser_view`(IN in_op int,In in_code int,IN rtype varchar(50))
BEGIN
if(rtype='service')then
select service,service_name,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,CAST(unique_eff_Hits AS UNSIGNED)unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue ,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action from tbl_op_cir_view_summary where Operator=in_op and circle=in_code group by Operator,circle;
elseif(rtype='circle')then
select circle,circle_name,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action from tbl_op_camp_view_summary where Operator=in_op and camp_id=in_code group by circle;
elseif(rtype='camp')then
select camp_id,camp_name,CAST(Total_Hits AS UNSIGNED)Total_Hits,CAST(Total_unique_hits AS UNSIGNED)Total_unique_hits,CAST(effective_Hits AS UNSIGNED)effective_Hits,unique_eff_Hits,CAST(Total_Revenue AS UNSIGNED)Total_Revenue,CAST(Eff_Revenue AS UNSIGNED)Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action from tbl_op_camp_view_summary where Operator=in_op and service=in_code group by camp_id;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cir_ser_date_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cir_ser_date_view`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_cir int, IN in_ser int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and circle=in_cir and service=in_ser order by Date desc;
else
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and circle=in_cir and service=in_ser order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cir_summary_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cir_summary_view`(in stdate varchar(20))
BEGIN
declare cnt int;
declare varFailedHits int;
declare uniFailedHits int;
insert into SpiceAdvt_Reports.tbl_proc_log_track(proc_name,Date) values('proc_op_cir_summary_view',stdate);
		select count(1) into cnt from tbl_op_cir_view_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_op_cir_view_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_op_cir_view_summary;
insert into tbl_temp_op_cir_view_summary
(date,Operator,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,circle_name,status_name,service,service_name)
select date(stdate),Operator,circle,aid,pubID,ifnull(sum(Total_Hits),0),
ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),ifnull(sum(unique_eff_Hits),0),
ifnull(sum(Total_Revenue),0),ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),ifnull(sum(unique_Click_to_action),0),AdStatus,operator_name,circle_name,status_name,service,service_name from tbl_op_cir_view				

group by circle,operator;	
insert into tbl_op_cir_view_summary(date,Operator,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,circle_name,status_name,service,service_name)
select date(stdate),Operator,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,circle_name,status_name,service,service_name 
from tbl_temp_op_cir_view_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_cir_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_cir_view`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_op_cir_view where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_op_cir_view where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_op_cir_view(date,Operator,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,circle_name,status_name,service,service_name)
select date(stdate),Operator,circle,aid,pubID,ifnull(sum(Total_Hits),0),
ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),
ifnull(sum(unique_eff_Hits),0),ifnull(sum(Total_Revenue),0),
ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),
ifnull(sum(unique_Click_to_action),0),
AdStatus,operator_name,circle_name,status_name,service,service_name from SpiceAdvt_Reports.tbl_view 
where date(date)=date(stdate) group by circle,operator;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_ser_camp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_ser_camp`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_ser int,IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,camp_id cid,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and service=in_ser and camp_id=in_camp order by Date desc;
else
select date(date) stdate,camp_id cid,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_camp_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and service=in_ser and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_ser_camp_dates_vies` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_ser_camp_dates_vies`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_ser int, IN in_camp int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and service=in_ser and camp_id=in_camp order by Date desc;
else
select date(date) stdate,circle circle,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,circle_name,status_name
from SpiceAdvt_Reports.tbl_op_cir_view
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and service=in_ser and camp_id=in_camp order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_ser_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_ser_criteria`(IN stdate varchar(50),IN tDate varchar(50),IN in_op int,IN in_ser int,IN rtype int)
BEGIN
if(rtype=0)then
select date(date) stdate,camp_id cid,service service,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,camp_name,service_name,status_name
from SpiceAdvt_Reports.tbl_op_ser_temp
where date >(CURDATE() - INTERVAL 7 DAY) and operator=in_op and service=in_ser order by Date desc;
else
select date(date) stdate,1 cid,service service,Total_Hits Total_Hits,Total_unique_hits Total_unique_hits,effective_Hits effective_Hits,unique_eff_Hits unique_eff_Hits,
Total_Revenue Total_Revenue,Eff_Revenue Eff_Revenue,failedHits failedHits,uniqueFailedHits uniqueFailedHits,Click_to_action Click_to_action,
unique_Click_to_action unique_Click_to_action,AdStatus AdStatus,operator_name,"Abc" camp_name,service_name,status_name
from SpiceAdvt_Reports.tbl_op_ser_temp
where (date between date(stdate) and date(date(tDate))) and Operator=in_op and service=in_ser order by date(date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_ser_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_ser_view`(IN stdate varchar(50))
BEGIN
declare dcnt int;
select count(1) into dcnt from tbl_op_ser_view where  date(Date)=date(stdate);
	if(dcnt>0)then
		delete from tbl_op_ser_view where  date(Date)=date(stdate);
	end if;
insert into SpiceAdvt_Reports.tbl_op_ser_view(date,Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,circle_name,service_name,status_name)
select date(stdate),Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,circle_name,service_name,status_name from SpiceAdvt_Reports.tbl_view where date(date)=date(stdate);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_op_ser_view_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_op_ser_view_summary`(IN stdate varchar(50))
BEGIN
declare cnt int;
declare varFailedHits int;
declare uniFailedHits int;
		insert into SpiceAdvt_Reports.tbl_proc_log_track(proc_name,Date) values('proc_op_ser_view_summary',stdate);
		select count(1) into cnt from tbl_op_ser_view_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_op_ser_view_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_op_ser_view_summary;
insert into tbl_temp_op_ser_view_summary
(date,Operator,camp_id,circle,service,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,circle_name,service_name,status_name)
	
select date(stdate),Operator,camp_id,circle,service,aid,pubID,ifnull(sum(Total_Hits),0),
ifnull(sum(Total_unique_hits),0),ifnull(sum(effective_Hits),0),ifnull(sum(unique_eff_Hits),0),
ifnull(sum(Total_Revenue),0),ifnull(sum(Eff_Revenue),0),ifnull(sum(failedHits),0),
ifnull(sum(uniqueFailedHits),0),ifnull(sum(Click_to_action),0),ifnull(sum(unique_Click_to_action),0),AdStatus,operator_name,camp_name,circle_name,service_name,status_name from tbl_op_ser_view				

group by operator,service;
insert into tbl_op_ser_view_summary(date,Operator,camp_id,service,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,service_name,status_name,circle_name)
select date,Operator,camp_id,service,circle,aid,pubID,Total_Hits,Total_unique_hits,effective_Hits,unique_eff_Hits,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,service_name,status_name ,circle_name
from tbl_temp_op_ser_view_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_platform_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_platform_criteria`(IN sdate date,IN tdate date)
BEGIN
	SELECT * FROM (
	select 'OBD PLATFORM' as obd ,date(date) date,total_calls total_calls,connected connected,avg_dur avg_dur ,total_count total_count from tbl_obd_platform as one where (date between date(sdate) and date(date(tDate)))
	UNION ALL
	select 'INTERACTIVE PLATFORM' as obd ,date(date) date,total_calls total_calls,connected connected,avg_dur avg_dur ,total_count total_count from tbl_obd_inter_platform as two where (date between date(sdate) and date(date(tDate)))
	UNION ALL
	select 'NON INTERACTIVE PLATFORM' as obd ,date(date) date,total_calls total_calls,connected connected,avg_dur avg_dur ,total_count total_count from tbl_obd_non_inter_platform as three where (date between date(sdate) and date(date(tDate)))
	) as u ;
	
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_pub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_pub`(in stdate varchar(20))
BEGIN
declare scnt int;
declare cnt int;
declare hrcnt int;
declare mcnt int;
declare varFailedHits int;
declare uniFailedHits int;
		
		
		
		
		delete from tbl_temp_pb_total_hits;
		delete from tbl_temp_pb_eff_hits;
		
		insert into tbl_temp_pb_total_hits(pub_date,criteria,pub_id,
		total_hits,unique_total_hits,total_revenue,sAID)
		select Date(date),0,pub_id,count(*),count(distinct Ani),sum(totalRevenue),Advertisement_id 
		from mob_advertisement.tbl_Total_Hits  where date(Date)=date(stdate) group by pub_id;
		
		
		insert into tbl_temp_pb_eff_hits(pub_date,criteria,pub_id,
		eff_hits ,unique_eff_hits ,eff_revenue,failedHits,uniqueFailedHits,sAID)
		select date(date),0,A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld,uFld,A.Advertisement_id  
		from mob_advertisement.tbl_Effective_Hits A left join 
		(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),pub_id) 
		as FAiled on
		(date(A.Date)=dt AND A.pub_id=FAiled.pub_id) where date(A.Date)=date(stdate) group by A.pub_id ;
		
		
		select count(1) into cnt from tbl_pub_daily where  date(Date)=date(stdate);
		if(cnt>0)then
			delete from tbl_pub_daily where  date(Date)=date(stdate);
		end if;
		insert into tbl_pub_daily(Date,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,total_revenue,eff_revenue,AID)		
		
		select Date(stdate),A.pub_id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),B.sAID from mob_advertisement.tbl_Publisher A
		left  join tbl_temp_pb_total_hits B on B.pub_id=A.pub_id 
		left join tbl_temp_pb_eff_hits C on C.pub_id=A.pub_id;
		
		
		
		select count(1) into scnt from tbl_pub_summary where  date(date)=date(stdate);
		if(scnt>0)then
		delete from tbl_pub_summary where   date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_pb_summary;
		insert into tbl_temp_pb_summary(Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID)
		
		select date(stdate),tb.pub_id,ifnull(sum(A.totalHits),0),
		ifnull(sum(A.effectiveHits),0),ifnull(sum(A.failedHits),0),
		ifnull(sum(A.total_revenue),0),ifnull(sum(A.eff_revenue),0) ,
		tb.Status_ad,A.AID 
		from mob_advertisement.tbl_Publisher tb 
		left outer join tbl_pub_daily A on tb.pub_id=A.pub_id
		group by A.pub_id;
		
		insert into tbl_pub_summary(Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID)
		select Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID
		from tbl_temp_pb_summary;
		
		
		
		
		truncate table	tbl_temp_pb_total_hits;
		truncate table tbl_temp_pb_eff_hits;
		
		insert into tbl_temp_pb_total_hits(pub_date,criteria, pub_id, total_hits, unique_total_hits, total_revenue,sAID)
		select Date(stdate),hour(Date),pub_id,count(*),count(distinct Ani),sum(totalRevenue),Advertisement_id   
		from mob_advertisement.tbl_Total_Hits where date(Date)=date(stdate) group by hour(Date),pub_id;
		
		
		insert into tbl_temp_pb_eff_hits(pub_date,criteria, pub_id, eff_hits, unique_eff_hits, eff_revenue, failedHits, uniqueFailedHits,sAID) 
		select Date(stdate),hour(A.Date),A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld,A.Advertisement_id   
		from mob_advertisement.tbl_Effective_Hits A left join 
		(select count(ani) Fld,count(distinct ani) uFld,hour(Date), date,pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by hour(Date),pub_id) 
		as FAiled on
		(hour(A.Date)=hour(FAiled.date) AND A.pub_id=FAiled.pub_id) where date(A.Date)=date(stdate) group by hour(A.Date),A.pub_id ;
		
		
		select count(1) into hrcnt from tbl_pub_hourly where  date(Date)=date(stdate);
		if(hrcnt>0)then
			delete from tbl_pub_hourly where  date(Date)=date(stdate);
		end if;
		
		insert into tbl_pub_hourly(Date,Hour,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,
		total_revenue,eff_revenue,AID)
		select stdate,hr,P_Id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),
		ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),C.sAID from
		(select A.hour hr, tb2.pub_id P_Id,tb2.AID aid from tbl_hours A,(select distinct pub_id,AID from mob_advertisement.tbl_Publisher) as tb2 ) as A1
		left outer join tbl_temp_pb_total_hits C on A1.hr=C.criteria and A1.P_Id=C.pub_id
		left outer join tbl_temp_pb_eff_hits D on A1.hr=D.criteria and A1.P_Id=D.pub_id
		order by A1.P_Id,A1.hr; 
		
		
		truncate table	tbl_temp_pb_total_hits;
		truncate table tbl_temp_pb_eff_hits;
		
		insert into tbl_temp_pb_total_hits(pub_date,criteria, pub_id, total_hits, unique_total_hits, total_revenue,sAID)
		select year(Date),month(Date),pub_id,count(*),count(distinct Ani),sum(totalRevenue),Advertisement_id 
		from mob_advertisement.tbl_Total_Hits where year(Date)=year(stdate) group by month(Date), pub_id;	
		
		insert into tbl_temp_pb_eff_hits(pub_date,criteria, pub_id, eff_hits, unique_eff_hits, eff_revenue, failedHits, uniqueFailedHits,sAID)  
		select year(Date),month(Date),A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld,A.Advertisement_id 
		from mob_advertisement.tbl_Effective_Hits A left join 
		(select count(ani) Fld,count(distinct ani) uFld,month(Date) Mnth, pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by Month(Date),pub_id) 
		as FAiled on
		(month(A.Date)=Mnth AND A.pub_id=FAiled.pub_id) where month(A.Date)=month(stdate) group by month(A.Date),A.pub_id ;
		
		select count(1) into mcnt from tbl_pub_monthly where  Year=year(stdate) and month= month(stdate);
		select 'old',mcnt;
		if(mcnt>0)then
			delete from tbl_pub_monthly where  Year=year(stdate) and month= month(stdate);
		end if;
		
		insert into tbl_pub_monthly(Year,Month,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,total_revenue,eff_revenue,AID)
		select year(concat(stdate,'-00-00')),Mnt,P_Id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),
		ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),C.sAID from
		(select A.month Mnt, tb2.pub_id P_Id,tb2.AID aid from tbl_months A,(select distinct pub_id,AID from mob_advertisement.tbl_Publisher) as tb2 ) as A1
		left outer join tbl_temp_pb_total_hits C on A1.Mnt=C.criteria and A1.P_Id=C.pub_id
		left outer join tbl_temp_pb_eff_hits D on A1.Mnt=D.criteria and A1.P_Id=D.pub_id
		where Mnt=month(stdate)
		order by A1.P_Id,A1.Mnt; 		
		
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_pub_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_pub_daily`(in stdate varchar(20))
BEGIN
declare varFailedHits int;
declare uniFailedHits int;
declare scnt int;
declare cnt int;
	
	truncate  tbl_temp_pb_total_hits;
	truncate  tbl_temp_pb_eff_hits;
	insert into tbl_temp_pb_total_hits(pub_date,criteria,pub_id,total_hits,unique_total_hits,total_revenue)
	select Date(date),0,pub_id,count(*),count(distinct Ani),sum(totalRevenue) 
	from mob_advertisement.tbl_Total_Hits  where date(Date)=date(stdate) group by pub_id;
	
	
	insert into tbl_temp_pb_eff_hits(pub_date,criteria,pub_id,eff_hits ,unique_eff_hits ,eff_revenue,failedHits,uniqueFailedHits)
	select date(date),0,A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join 
	(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),pub_id) 
	as FAiled on
	(date(A.Date)=dt AND A.pub_id=FAiled.pub_id) where date(A.Date)=date(stdate) group by A.pub_id ;
	
	select count(1) into cnt from tbl_pub_daily where  date(Date)=date(stdate);
	if(cnt>0)then
		delete from tbl_pub_daily where  date(Date)=date(stdate);
	end if;
	insert into tbl_pub_daily(Date,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,total_revenue,eff_revenue,AID)		
	select Date(stdate),A.pub_id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),AID from mob_advertisement.tbl_Publisher A
	left  join tbl_temp_pb_total_hits B on B.pub_id=A.pub_id
	left join tbl_temp_pb_eff_hits C on C.pub_id=A.pub_id;
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_pub_summery` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_pub_summery`(in stdate varchar(20))
BEGIN
declare varFailedHits int;
declare uniFailedHits int;
declare scnt int;
declare cnt int;
	select count(1) into scnt from tbl_pub_summary where  date(date)=date(stdate);
	if(scnt>0)then
	delete from tbl_pub_summary where   date(date)=date(stdate);
	end if;
	
	truncate table tbl_temp_pb_summary;
	insert into tbl_temp_pb_summary(Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID)
	
	select date(stdate),tb.pub_id,ifnull(sum(A.totalHits),0),
	ifnull(sum(A.effectiveHits),0),ifnull(sum(A.failedHits),0),
	ifnull(sum(A.total_revenue),0),ifnull(sum(A.eff_revenue),0) ,
	tb.Status_ad,tb.AID 
	from mob_advertisement.tbl_Publisher tb 
	left outer join tbl_pub_daily A on tb.pub_id=A.pub_id
	group by A.pub_id;
	
	insert into tbl_pub_summary(Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID)
	select Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID
	from tbl_temp_pb_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_service_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_service_daily`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_tot_hits;
	truncate table  SpiceAdvt_Reports.tbl_temp_camp_eff_hits;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_CTA;
	insert into SpiceAdvt_Reports.tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
	select Date(stdate),operator,camp_id,count(*),count(distinct Ani),sum(totalRevenue)
	from mob_advertisement.tbl_Total_Hits 
	where date(Date)=date(stdate)
	group by operator,camp_id;
	
	insert into SpiceAdvt_Reports.tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
	
	
	select Date(stdate),A.operator,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join
	(select count(ani) Fld,count(distinct ani) uFld,operator, date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by operator,camp_id) 
	as FAiled on (A.operator=FAiled.operator  AND A.camp_id=FAiled.camp_id) 
	where date(A.Date)=date(stdate)
	group by A.operator,A.camp_id;
	
	insert into tbl_temp_camp_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
	select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani)
	from mob_advertisement.tbl_CTA A ,
	(select operator from mob_advertisement.tbl_campaign) as tb
	where date(A.Date)=date(stdate) group by tb.operator, camp_id;
	select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_Campaign_Operator where  date(Date)=date(stdate);
	if(hrcnt>0)then
	delete from SpiceAdvt_Reports.tbl_Campaign_Operator where  date(Date)=date(stdate);
	end if;
	
	insert into SpiceAdvt_Reports.tbl_Campaign_Operator(date,Operator,op_name,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,
	Click_to_action,unique_Click_to_action,
	failedHits,uniqueFailedHits,Total_Revenue,Eff_Revenue,Advertiser_id,Status,unique_eff_Hits)
	select Date(stdate),Op,opName,C_ID,campName,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
	ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid,StatusAd,ifnull(uniq_eff_hits,0)
	from
	(select A.Operator_Code Op,A.Operator_Name opName, tb2.camp_id C_ID,tb2.Name campName,tb2.Status_ad  StatusAd,tb2.advertiser_id advid from mob_advertisement.tbl_Operator_Details A left join  mob_advertisement.tbl_campaign tb2 on tb2.Operator=pow(2,Operator_Code-1))as A1
	left outer join SpiceAdvt_Reports.tbl_temp_camp_tot_hits C  on A1.Op=C.criteria and A1.C_ID =C.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_eff_hits D on A1.Op=D.criteria and A1.C_ID =D.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_CTA  E on A1.Op=E.criteria and A1.C_ID =E.camp_id
	order by A1.Op,A1.C_ID ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_service_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_service_summary`(in stdate varchar(25))
BEGIN
declare cnt int;
	
		select count(1) into cnt from tbl_campaign_op_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_campaign_op_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_camp_op_summary;
		insert into tbl_temp_camp_op_summary(Date,Operator,op_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status)
		
		select date(stdate),A.Operator,op_name,tb.camp_id,tb.Name,
		ifnull(sum(A.Total_Hits),0),
		ifnull(sum(A.effective_Hits),0),
		ifnull(sum(A.Total_unique_hits),0),
		ifnull(sum(A.unique_eff_Hits),0),
		ifnull(sum(A.Total_budget),0),
		ifnull(sum(A.Left_budget),0),
		ifnull(sum(A.Used_Budget),0),
		ifnull(sum(A.Click_to_action),0),
		ifnull(sum(A.unique_Click_to_action),0),
		ifnull(sum(A.failedHits),0),
		ifnull(sum(A.uniqueFailedHits),0),
		ifnull(sum(A.total_revenue),0),
		ifnull(sum(A.eff_revenue),0),
		tb.Advertiser_id,
		tb.Status_ad 
		from  tbl_Campaign_Operator A 
		left outer join mob_advertisement.tbl_campaign tb  on 
		tb.Operator=pow(2,A.Operator-1)
		group by A.Operator,tb.camp_id;	
		
		
		insert into tbl_campaign_op_summary(Date,Operator,op_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status)
		
		select Date,Operator,op_name,camp_id,camp_name,
		Total_Hits,effective_Hits,Total_unique_hits,
		unique_eff_Hits,Total_budget,Left_budget,Used_Budget,Click_to_action,unique_Click_to_action,failedHits,
		uniqueFailedHits,total_revenue,eff_revenue,advertiser_id,Status
		from tbl_temp_camp_op_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_summary`(in stdate varchar(20))
BEGIN
declare cnt int;
declare varFailedHits int;
declare uniFailedHits int;
	
		select count(1) into cnt from tbl_Campaign_summary where    date(date)=date(stdate);
		if(cnt>0)then
			delete from tbl_Campaign_summary where  date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_camp_summary;
insert into tbl_temp_camp_summary
(date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Click_to_action,unique_Click_to_action,
Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Advertiser_id,Status)
select date(stdate),tb.Camp_id,tb.Name,
			ifnull(sum(A.Total_Hits),0),
			ifnull(sum(A.effective_hits),0),
			ifnull(sum(A.Total_unique_hits),0),
			ifnull(sum(A.unique_effective_Hits),0),
			ifnull(sum(A.Click_to_action_hits),0),
			ifnull(sum(A.uniq_CTA),0),
			ifnull(sum(A.total_revenue),0),
			ifnull(sum(A.eff_revenue),0),
			ifnull(sum(A.failedHits),0),
			ifnull(sum(A.uniqueFailedHits),0),tb.Advertiser_id,
			tb.Status_ad 
			from mob_advertisement.tbl_campaign tb
			left outer join  tbl_Camp_daily A  on tb.Camp_id=A.camp_id			
			group by tb.camp_id;	
insert into tbl_Campaign_summary(date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Click_to_action,unique_Click_to_action,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Advertiser_id,Status)
select date,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_effective_Hits,Click_to_action,unique_Click_to_action,Total_Revenue,Eff_Revenue,failedHits,uniqueFailedHits,Advertiser_id,Status
from tbl_temp_camp_summary;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_user_approval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_user_approval`(IN in_aid mediumint(9),IN utype varchar(50),out out_Status int,out out_msg varchar(100))
BEGIN
                       	set out_Status=-100;
                        set out_msg="Advertisement id doesnot exist ";
			if(utype='approve_user'||utype='resume_user')then
			update mob_advertisement.tbl_Advertiser_Details set Verify_Status=2 where Aid=in_aid ;
                     	set out_Status=90;
                        set out_msg="User is Approved ";
			elseif(utype='reject_user')then
			update mob_advertisement.tbl_Advertiser_Details set Verify_Status=-2 where Aid=in_aid;
                        set out_Status=-90;
                        set out_msg="User is Rejected ";
                      
                        
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_test_pub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_test_pub`(in stdate varchar(20))
BEGIN
declare scnt int;
declare cnt int;
declare hrcnt int;
declare mcnt int;
declare varFailedHits int;
declare uniFailedHits int;
		
		
		delete from tbl_temp_pb_total_hits;
		delete from tbl_temp_pb_eff_hits;
		
		insert into tbl_temp_pb_total_hits(pub_date,criteria,pub_id,
		total_hits,unique_total_hits,total_revenue,sAID)
		select Date(date),0,pub_id,count(*),count(distinct Ani),sum(totalRevenue),Advertisement_id 
		from mob_advertisement.tbl_Total_Hits  where date(Date)=date(stdate) group by pub_id;
		
		
		insert into tbl_temp_pb_eff_hits(pub_date,criteria,pub_id,
		eff_hits ,unique_eff_hits ,eff_revenue,failedHits,uniqueFailedHits,sAID)
		select date(date),0,A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld,uFld,A.Advertisement_id  
		from mob_advertisement.tbl_Effective_Hits A left join 
		(select count(ani) Fld,count(distinct ani) uFld,date(Date) dt, pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by date(Date),pub_id) 
		as FAiled on
		(date(A.Date)=dt AND A.pub_id=FAiled.pub_id) where date(A.Date)=date(stdate) group by A.pub_id ;
		
		
		select count(1) into cnt from tbl_pub_daily where  date(Date)=date(stdate);
		if(cnt>0)then
			delete from tbl_pub_daily where  date(Date)=date(stdate);
		end if;
		insert into tbl_pub_daily(Date,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,total_revenue,eff_revenue,AID)		
		
		select Date(stdate),A.pub_id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),B.sAID from mob_advertisement.tbl_Publisher A
		left  join tbl_temp_pb_total_hits B on B.pub_id=A.pub_id 
		left join tbl_temp_pb_eff_hits C on C.pub_id=A.pub_id;
		
		
		
		select count(1) into scnt from tbl_pub_summary where  date(date)=date(stdate);
		if(scnt>0)then
		delete from tbl_pub_summary where   date(date)=date(stdate);
		end if;
		
		truncate table tbl_temp_pb_summary;
		insert into tbl_temp_pb_summary(Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID)
		
		select date(stdate),tb.pub_id,ifnull(sum(A.totalHits),0),
		ifnull(sum(A.effectiveHits),0),ifnull(sum(A.failedHits),0),
		ifnull(sum(A.total_revenue),0),ifnull(sum(A.eff_revenue),0) ,
		tb.Status_ad,A.AID 
		from mob_advertisement.tbl_Publisher tb 
		left outer join tbl_pub_daily A on tb.pub_id=A.pub_id
		group by A.pub_id;
		
		insert into tbl_pub_summary(Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID)
		select Date,Pub_id,totalHits,effectiveHits,failedHits,total_revenue,eff_revenue,Status,AID
		from tbl_temp_pb_summary;
		
		
		
		
		truncate table	tbl_temp_pb_total_hits;
		truncate table tbl_temp_pb_eff_hits;
		
		insert into tbl_temp_pb_total_hits(pub_date,criteria, pub_id, total_hits, unique_total_hits, total_revenue,sAID)
		select Date(stdate),hour(Date),pub_id,count(*),count(distinct Ani),sum(totalRevenue),Advertisement_id   
		from mob_advertisement.tbl_Total_Hits where date(Date)=date(stdate) group by hour(Date),pub_id;
		
		
		insert into tbl_temp_pb_eff_hits(pub_date,criteria, pub_id, eff_hits, unique_eff_hits, eff_revenue, failedHits, uniqueFailedHits,sAID) 
		select Date(stdate),hour(A.Date),A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld,A.Advertisement_id   
		from mob_advertisement.tbl_Effective_Hits A left join 
		(select count(ani) Fld,count(distinct ani) uFld,hour(Date), date,pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by hour(Date),pub_id) 
		as FAiled on
		(hour(A.Date)=hour(FAiled.date) AND A.pub_id=FAiled.pub_id) where date(A.Date)=date(stdate) group by hour(A.Date),A.pub_id ;
		
		
		select count(1) into hrcnt from tbl_pub_hourly where  date(Date)=date(stdate);
		if(hrcnt>0)then
			delete from tbl_pub_hourly where  date(Date)=date(stdate);
		end if;
		
		insert into tbl_pub_hourly(Date,Hour,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,
		total_revenue,eff_revenue,AID)
		select stdate,hr,P_Id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),
		ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),C.sAID from
		(select A.hour hr, tb2.pub_id P_Id,tb2.AID aid from tbl_hours A,(select distinct pub_id,AID from mob_advertisement.tbl_Publisher) as tb2 ) as A1
		left outer join tbl_temp_pb_total_hits C on A1.hr=C.criteria and A1.P_Id=C.pub_id
		left outer join tbl_temp_pb_eff_hits D on A1.hr=D.criteria and A1.P_Id=D.pub_id
		order by A1.P_Id,A1.hr; 
		
		
		truncate table	tbl_temp_pb_total_hits;
		truncate table tbl_temp_pb_eff_hits;
		
		insert into tbl_temp_pb_total_hits(pub_date,criteria, pub_id, total_hits, unique_total_hits, total_revenue,sAID)
		select year(Date),month(Date),pub_id,count(*),count(distinct Ani),sum(totalRevenue),Advertisement_id 
		from mob_advertisement.tbl_Total_Hits where year(Date)=year(stdate) group by month(Date), pub_id;	
		
		insert into tbl_temp_pb_eff_hits(pub_date,criteria, pub_id, eff_hits, unique_eff_hits, eff_revenue, failedHits, uniqueFailedHits,sAID)  
		select year(Date),month(Date),A.pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld,A.Advertisement_id 
		from mob_advertisement.tbl_Effective_Hits A left join 
		(select count(ani) Fld,count(distinct ani) uFld,month(Date) Mnth, pub_id  from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status<0 group by Month(Date),pub_id) 
		as FAiled on
		(month(A.Date)=Mnth AND A.pub_id=FAiled.pub_id) where month(A.Date)=month(stdate) group by month(A.Date),A.pub_id ;
		
		select count(1) into mcnt from tbl_pub_monthly where  Year=year(stdate) and month= month(stdate);
		select 'old',mcnt;
		if(mcnt>0)then
			delete from tbl_pub_monthly where  Year=year(stdate) and month= month(stdate);
		end if;
		
		insert into tbl_pub_monthly(Year,Month,pub_id,totalHits,uniqueHits,effectiveHits,uniqueEffectiveHits,failedHits,uniqueFailedHits,total_revenue,eff_revenue,AID)
		select year(concat(stdate,'-00-00')),Mnt,P_Id,ifnull(total_hits,0),ifnull(unique_total_hits,0),ifnull(eff_hits,0),
		ifnull(unique_eff_hits,0),ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),C.sAID from
		(select A.month Mnt, tb2.pub_id P_Id,tb2.AID aid from tbl_months A,(select distinct pub_id,AID from mob_advertisement.tbl_Publisher) as tb2 ) as A1
		left outer join tbl_temp_pb_total_hits C on A1.Mnt=C.criteria and A1.P_Id=C.pub_id
		left outer join tbl_temp_pb_eff_hits D on A1.Mnt=D.criteria and A1.P_Id=D.pub_id
		where Mnt=month(stdate)
		order by A1.P_Id,A1.Mnt; 		
		
		
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_view`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
	truncate table	SpiceAdvt_Reports.tbl_temp_view_tot_hits;
	truncate table  SpiceAdvt_Reports.tbl_temp_view_eff_hits;
	truncate table	SpiceAdvt_Reports.tbl_temp_view_CTA;
	
	insert into SpiceAdvt_Reports.tbl_temp_view_tot_hits(date,criteria,camp_id,circle,service,aid,pubID,tot_hits,uniq_tot_hits,total_revenue,criteria_name,camp_name,circle_name,service_name)
	select Date(stdate),t.operator,t.camp_id,t.circle,t.service,Advertisement_id,Pub_id,count(*),count(distinct Ani),sum(totalRevenue),o.Operator_Name,c.Name,cir.Circle_Name,s.Service_Type
	from mob_advertisement.tbl_Total_Hits t
	left join mob_advertisement.tbl_Operator_Details o  on o.Operator_Code =t.operator
        left join mob_advertisement.tbl_campaign c  on c.Camp_id =t.camp_id
	left join mob_advertisement.tbl_Circle_Details cir  on cir.Circle_Code =t.circle
        left join mob_advertisement.tbl_Services_Details s  on s.Service_Code =t.service
	where date(Date)=date(stdate)
	group by t.operator,t.circle,t.service,t.camp_id,Advertisement_id,Pub_id;
	
	
	insert into SpiceAdvt_Reports.tbl_temp_view_eff_hits(date,criteria,camp_id,circle,service,aid,pubID,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits,criteria_name,camp_name,circle_name,service_name)
select Date(stdate),A.operator,A.camp_id,A.circle,A.service,A.Advertisement_id,A.Pub_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld,o.Operator_Name,c.Name,cir.Circle_Name,s.Service_Type 
	from mob_advertisement.tbl_Effective_Hits A left join
	(select count(ani) Fld,count(distinct ani) uFld,operator, date,camp_id from mob_advertisement.tbl_Effective_Hits
	where date(Date)=date(stdate) and status=-1 group by operator,camp_id) 
	as FAiled on (A.operator=FAiled.operator  AND A.camp_id=FAiled.camp_id) 
        left join mob_advertisement.tbl_Operator_Details o  on o.Operator_Code =A.operator
        left join mob_advertisement.tbl_campaign c  on c.Camp_id =A.camp_id
	left join mob_advertisement.tbl_Circle_Details cir  on cir.Circle_Code =A.circle
        left join mob_advertisement.tbl_Services_Details s  on s.Service_Code =A.service
	where date(A.Date)=date(stdate)
	group by A.operator,A.camp_id,A.circle,A.service,A.Advertisement_id,A.Pub_id;	
	
	
	insert into tbl_temp_view_CTA(date,criteria,camp_id,Total_hits,Unique_hits)
        
	select date(A.Date),tb.operator,A.camp_id,count(*),count(distinct A.Ani)
	from mob_advertisement.tbl_CTA A ,
	(select operator from mob_advertisement.tbl_campaign) as tb
	where date(A.Date)=date(stdate) group by tb.operator, camp_id;
	
	
	select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_view where  date(Date)=date(stdate);
	if(hrcnt>0)then
		select 'abc';
		delete from SpiceAdvt_Reports.tbl_view where  date(Date)=date(stdate);
	end if;
	
	
	insert into SpiceAdvt_Reports.tbl_view(date,Operator,camp_id,circle,service,aid,pubID,
	Total_Hits,Total_unique_hits,Total_Revenue,
	effective_Hits,unique_eff_Hits,Eff_Revenue,failedHits,uniqueFailedHits
	,Click_to_action,unique_Click_to_action,AdStatus,operator_name,camp_name,circle_name,service_name,status_name)
	
	select C.date,C.criteria,C.camp_id,C.circle,C.service,C.aid,C.pubID,
	ifnull(C.tot_hits,0),ifnull(C.uniq_tot_hits,0),ifnull(C.total_revenue,0),
	ifnull(B.eff_hits,0),ifnull(B.uniq_eff_hits,0),ifnull(B.eff_revenue,0),ifnull(B.failedHits,0),ifnull(B.uniqueFailedHits,0), 
	ifnull(D.Total_hits,0) Click_to_action,ifnull(D.Unique_hits,0) unique_Click_to_action,A1.Status_ad,B.criteria_name,B.camp_name,B.circle_name,B.service_name,stat.status_ad_Name
	from SpiceAdvt_Reports.tbl_temp_view_eff_hits B
	left join 
	SpiceAdvt_Reports.tbl_temp_view_tot_hits C on C.criteria=B.criteria
	and C.camp_id=B.camp_id and C.circle=B.circle and C.service=B.service
	left  join SpiceAdvt_Reports.tbl_temp_view_CTA  D on  D.criteria=B.criteria and D.camp_id=B.camp_id
	left join 
	mob_advertisement.tbl_campaign A1 on A1.camp_id=B.camp_id
	left join mob_advertisement.tbl_status_ad_details stat on stat.Status_ad_code=A1.Status_ad 
	where date(C.date)=date(stdate) group by camp_id ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-31 15:45:17
