-- MySQL dump 10.13  Distrib 5.5.13, for Linux (i686)
--
-- Host: 192.168.9.126    Database: mob_advertisement
-- ------------------------------------------------------
-- Server version	5.5.34-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `r1data`
--

DROP TABLE IF EXISTS `r1data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `r1data` (
  `msisdn` bigint(15) NOT NULL,
  `operator` varchar(50) DEFAULT NULL,
  `Service` varchar(50) DEFAULT NULL,
  `Circle` varchar(50) DEFAULT NULL,
  `AON` date DEFAULT NULL,
  `Sub_Date` date DEFAULT NULL,
  `net_revenue` float DEFAULT NULL,
  `avg_revenue` float DEFAULT NULL,
  `Mou` int(11) DEFAULT NULL,
  `Native_Language` varchar(50) DEFAULT NULL,
  `Type_of_service` int(20) DEFAULT NULL,
  `Ani_Status` varchar(50) DEFAULT NULL,
  `id` int(11) NOT NULL DEFAULT '0',
  `gender` int(11) DEFAULT NULL,
  UNIQUE KEY `msisdn_2` (`msisdn`),
  UNIQUE KEY `msisdn` (`msisdn`,`operator`,`Service`,`Circle`,`AON`,`Sub_Date`,`net_revenue`,`avg_revenue`,`Mou`,`Native_Language`,`Type_of_service`,`Ani_Status`,`id`,`gender`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rdata`
--

DROP TABLE IF EXISTS `rdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rdata` (
  `msisdn` bigint(15) NOT NULL,
  `operator` varchar(50) DEFAULT NULL,
  `Service` varchar(50) DEFAULT NULL,
  `Circle` varchar(50) DEFAULT NULL,
  `AON` date DEFAULT NULL,
  `Sub_Date` date DEFAULT NULL,
  `net_revenue` float DEFAULT NULL,
  `avg_revenue` float DEFAULT NULL,
  `Mou` int(11) DEFAULT NULL,
  `Native_Language` varchar(50) DEFAULT NULL,
  `Type_of_service` int(20) DEFAULT NULL,
  `Ani_Status` varchar(50) DEFAULT NULL,
  `id` int(11) NOT NULL DEFAULT '0',
  `gender` int(11) DEFAULT NULL,
  UNIQUE KEY `msisdn` (`msisdn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Admin_comment_Data`
--

DROP TABLE IF EXISTS `tbl_Admin_comment_Data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Admin_comment_Data` (
  `Date` date DEFAULT NULL,
  `camp_id` int(11) DEFAULT '0',
  `Pub_id` int(11) DEFAULT '0',
  `text_comment` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Advertiser_Details`
--

DROP TABLE IF EXISTS `tbl_Advertiser_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Advertiser_Details` (
  `Aid` mediumint(9) NOT NULL,
  `User_name` varchar(100) DEFAULT NULL,
  `Password` varchar(40) NOT NULL,
  `DateofBirth` date NOT NULL,
  `Mbphone` bigint(20) NOT NULL,
  `Gender` char(6) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `Company_name` varchar(50) DEFAULT NULL,
  `Company_Desc` varchar(200) DEFAULT NULL,
  `Company_Address` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Verify_Status` int(11) NOT NULL,
  `Verify_code` varchar(100) NOT NULL,
  `Verify_expiry_date` date DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `Super_Aid` int(11) DEFAULT '0',
  PRIMARY KEY (`Aid`),
  KEY `User_name` (`User_name`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Advertiser_Details_log`
--

DROP TABLE IF EXISTS `tbl_Advertiser_Details_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Advertiser_Details_log` (
  `Aid` mediumint(9) NOT NULL,
  `User_name` varchar(30) DEFAULT NULL,
  `Password` varchar(10) NOT NULL,
  `DateofBirth` date NOT NULL,
  `Mbphone` bigint(12) NOT NULL,
  `Gender` char(6) NOT NULL,
  `city` varchar(10) DEFAULT NULL,
  `Company_name` varchar(10) DEFAULT NULL,
  `Company_Desc` varchar(20) DEFAULT NULL,
  `Company_Address` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Verify_Status` int(5) NOT NULL DEFAULT '0',
  `Verify_code` varchar(10) NOT NULL,
  `Verify_expiry_date` date DEFAULT NULL,
  `country` varchar(10) DEFAULT NULL,
  `Super_Aid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Ani_status_Details`
--

DROP TABLE IF EXISTS `tbl_Ani_status_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Ani_status_Details` (
  `Ani_code` int(11) NOT NULL,
  `Ani_Status` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ani_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_CTA`
--

DROP TABLE IF EXISTS `tbl_CTA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_CTA` (
  `Ani` bigint(20) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `camp_hits` int(11) DEFAULT NULL,
  `camp_status` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_CTA_Details`
--

DROP TABLE IF EXISTS `tbl_CTA_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_CTA_Details` (
  `CTA_Flag` int(2) NOT NULL,
  `CTA_Desc` varchar(50) DEFAULT NULL,
  `camp_id` mediumint(9) DEFAULT NULL,
  `Advertisement_id` int(5) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `CTA_Value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`CTA_Flag`),
  KEY `Camp_id` (`camp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Circle_Details`
--

DROP TABLE IF EXISTS `tbl_Circle_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Circle_Details` (
  `Circle_Code` int(3) NOT NULL,
  `Circle_Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Circle_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Effective_Hits`
--

DROP TABLE IF EXISTS `tbl_Effective_Hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Effective_Hits` (
  `Ani` bigint(12) NOT NULL,
  `Status` int(5) DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Advertisement_id` int(5) DEFAULT NULL,
  `Pub_id` int(5) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `effRevenue` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT '0',
  `eventType` int(11) DEFAULT NULL,
  KEY `P_id` (`Pub_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Effective_Hits_log`
--

DROP TABLE IF EXISTS `tbl_Effective_Hits_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Effective_Hits_log` (
  `Ani` bigint(12) NOT NULL,
  `Status` int(5) DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Advertisement_id` int(5) DEFAULT NULL,
  `Pub_id` int(5) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `effRevenue` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `eventType` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Language_Details`
--

DROP TABLE IF EXISTS `tbl_Language_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Language_Details` (
  `Language_Code` int(3) NOT NULL,
  `Language_Name` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Language_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Login`
--

DROP TABLE IF EXISTS `tbl_Login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Login` (
  `Uid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `User_name` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `LDate` date NOT NULL DEFAULT '0000-00-00',
  `Status` int(5) NOT NULL,
  `RoleType` int(11) DEFAULT '0',
  PRIMARY KEY (`Uid`),
  UNIQUE KEY `User_name` (`User_name`),
  UNIQUE KEY `User_name_2` (`User_name`),
  UNIQUE KEY `User_name_3` (`User_name`)
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Login_log`
--

DROP TABLE IF EXISTS `tbl_Login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Login_log` (
  `Uid` mediumint(9) NOT NULL DEFAULT '0',
  `User_name` varchar(30) NOT NULL DEFAULT '',
  `Password` varchar(10) NOT NULL,
  `LDate` date NOT NULL DEFAULT '0000-00-00',
  `Status` int(5) NOT NULL,
  `RoleType` int(11) DEFAULT NULL,
  PRIMARY KEY (`Uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Operator_Details`
--

DROP TABLE IF EXISTS `tbl_Operator_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Operator_Details` (
  `Operator_Code` int(3) NOT NULL,
  `Operator_Name` varchar(15) NOT NULL,
  PRIMARY KEY (`Operator_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Publisher`
--

DROP TABLE IF EXISTS `tbl_Publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Publisher` (
  `pub_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Type` int(11) NOT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Start_Date` datetime DEFAULT NULL,
  `End_Date` datetime DEFAULT NULL,
  `Msisdn` bigint(20) DEFAULT NULL,
  `Operator` int(11) NOT NULL,
  `Service` int(11) NOT NULL,
  `Circle` int(11) NOT NULL,
  `CategoryOfService` int(11) DEFAULT NULL,
  `Status_ad` int(11) DEFAULT NULL,
  `CTA_Flag` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL,
  `User_name` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`pub_id`),
  UNIQUE KEY `User_name` (`User_name`),
  KEY `Operator` (`Operator`),
  KEY `Service` (`Service`),
  KEY `Circle` (`Circle`),
  KEY `CTA_Flag` (`CTA_Flag`)
) ENGINE=MyISAM AUTO_INCREMENT=1070 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Publisher_log`
--

DROP TABLE IF EXISTS `tbl_Publisher_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Publisher_log` (
  `pub_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Type` varchar(50) NOT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Start_Date` datetime DEFAULT NULL,
  `End_Date` datetime DEFAULT NULL,
  `Msisdn` bigint(20) DEFAULT NULL,
  `Operator` int(11) NOT NULL,
  `Service` int(11) NOT NULL,
  `Circle` int(11) NOT NULL,
  `CategoryOfService` int(11) DEFAULT NULL,
  `Status_ad` int(11) DEFAULT NULL,
  `CTA_Flag` int(11) DEFAULT NULL,
  `AID` int(11) DEFAULT NULL,
  `log_date` datetime DEFAULT NULL,
  PRIMARY KEY (`pub_id`),
  KEY `Operator` (`Operator`),
  KEY `Service` (`Service`),
  KEY `Circle` (`Circle`),
  KEY `CTA_Flag` (`CTA_Flag`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Services_Details`
--

DROP TABLE IF EXISTS `tbl_Services_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Services_Details` (
  `Service_Code` int(3) NOT NULL,
  `Service_Type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Service_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Services_categoryDetails`
--

DROP TABLE IF EXISTS `tbl_Services_categoryDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Services_categoryDetails` (
  `Service_name` varchar(50) DEFAULT NULL,
  `Service_code` int(11) NOT NULL,
  `Service_Category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Service_code`),
  KEY `Service_Category` (`Service_Category`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Slots`
--

DROP TABLE IF EXISTS `tbl_Slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Slots` (
  `Aid` mediumint(9) NOT NULL,
  `Slotid` smallint(4) NOT NULL,
  `Start_Time` int(4) DEFAULT NULL,
  `End_Time` int(4) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Aid` (`Aid`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Status_Details`
--

DROP TABLE IF EXISTS `tbl_Status_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Status_Details` (
  `Status_code` mediumint(5) NOT NULL DEFAULT '0',
  `Status_Msg` varchar(100) DEFAULT NULL,
  `Procedure_name` varchar(50) DEFAULT NULL,
  `Database_name` varchar(50) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Total_Hits`
--

DROP TABLE IF EXISTS `tbl_Total_Hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Total_Hits` (
  `Ani` bigint(12) NOT NULL,
  `Status` int(5) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Advertisement_id` int(5) DEFAULT NULL,
  `Pub_id` int(5) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `totalRevenue` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT '0',
  `eventType` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Total_Hits_log`
--

DROP TABLE IF EXISTS `tbl_Total_Hits_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_Total_Hits_log` (
  `Ani` bigint(12) NOT NULL,
  `Status` int(5) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Advertisement_id` int(5) DEFAULT NULL,
  `Pub_id` int(5) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `totalRevenue` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `eventType` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_User_ActualData`
--

DROP TABLE IF EXISTS `tbl_User_ActualData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_User_ActualData` (
  `msisdn` bigint(12) NOT NULL,
  `Operator` int(11) DEFAULT NULL,
  `Service` int(11) DEFAULT NULL,
  `Circle` int(11) DEFAULT NULL,
  `AON` date DEFAULT NULL,
  `Sub_Date` date DEFAULT NULL,
  `net_rev` int(11) DEFAULT NULL,
  `avg_rev` int(11) DEFAULT NULL,
  `MOU` int(11) DEFAULT NULL,
  `N_language` int(11) DEFAULT NULL,
  `Type_of_Service` int(11) DEFAULT NULL,
  `Ani_Status` int(11) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  PRIMARY KEY (`msisdn`),
  UNIQUE KEY `msisdn` (`msisdn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_User_RawData`
--

DROP TABLE IF EXISTS `tbl_User_RawData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_User_RawData` (
  `msisdn` bigint(15) NOT NULL,
  `operator` varchar(50) DEFAULT NULL,
  `Service` varchar(50) DEFAULT NULL,
  `Circle` varchar(50) DEFAULT NULL,
  `AON` date DEFAULT NULL,
  `Sub_Date` date DEFAULT NULL,
  `net_revenue` float DEFAULT NULL,
  `avg_revenue` float DEFAULT NULL,
  `Mou` int(11) DEFAULT NULL,
  `Native_Language` varchar(50) DEFAULT NULL,
  `Type_of_service` int(20) DEFAULT NULL,
  `Ani_Status` varchar(50) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gender` int(11) DEFAULT NULL,
  PRIMARY KEY (`msisdn`,`id`),
  UNIQUE KEY `msisdn` (`msisdn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_ad_details`
--

DROP TABLE IF EXISTS `tbl_ad_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ad_details` (
  `ad_type_code` int(11) NOT NULL,
  `ad_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ad_type_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_view`
--

DROP TABLE IF EXISTS `tbl_admin_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_view` (
  `Admin_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Msisdn` bigint(20) DEFAULT NULL,
  `Status_ad` int(11) DEFAULT NULL,
  `Start_date` date DEFAULT NULL,
  `End_date` date DEFAULT NULL,
  `User_name` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`Admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_admin_view_log`
--

DROP TABLE IF EXISTS `tbl_admin_view_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_view_log` (
  `Admin_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Msisdn` bigint(20) DEFAULT NULL,
  `Status_ad` int(11) DEFAULT NULL,
  `Start_date` date DEFAULT NULL,
  `End_date` date DEFAULT NULL,
  `User_name` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`Admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_advert_Verifystatus`
--

DROP TABLE IF EXISTS `tbl_advert_Verifystatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_advert_Verifystatus` (
  `Code` int(11) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign`
--

DROP TABLE IF EXISTS `tbl_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign` (
  `Camp_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Type` int(10) NOT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `Start_Date` datetime DEFAULT NULL,
  `End_Date` datetime DEFAULT NULL,
  `Total_Budget` float NOT NULL,
  `Daily_Budget` float NOT NULL,
  `Bidding` float DEFAULT NULL,
  `Age` int(11) NOT NULL,
  `Gender` smallint(1) NOT NULL,
  `Msisdn` bigint(20) DEFAULT NULL,
  `Operator` int(11) NOT NULL,
  `Service` int(11) NOT NULL,
  `Circle` int(11) NOT NULL,
  `AON` int(11) DEFAULT NULL,
  `Slot` int(11) NOT NULL,
  `limitUser` int(11) NOT NULL,
  `N_Language` int(11) NOT NULL,
  `CategoryOfService` int(11) DEFAULT NULL,
  `Arpu` float DEFAULT NULL,
  `Status_ad` int(11) NOT NULL,
  `CTA_Flag` int(11) DEFAULT NULL,
  `advertiser_id` int(11) NOT NULL,
  `MOU` int(11) DEFAULT NULL,
  `Used_Budget` int(11) DEFAULT '0',
  `CTA_Value` varchar(200) DEFAULT NULL,
  `Type_value` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Camp_id`),
  KEY `Operator` (`Operator`),
  KEY `Service` (`Service`),
  KEY `Circle` (`Circle`),
  KEY `N_Language` (`N_Language`),
  KEY `CTA_Flag` (`CTA_Flag`)
) ENGINE=MyISAM AUTO_INCREMENT=307 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign1`
--

DROP TABLE IF EXISTS `tbl_campaign1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign1` (
  `Camp_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Type` int(10) NOT NULL,
  `Type_value` varchar(500) DEFAULT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Start_Date` datetime DEFAULT NULL,
  `End_Date` datetime DEFAULT NULL,
  `Total_Budget` float NOT NULL,
  `Daily_Budget` float NOT NULL,
  `Bidding` float DEFAULT NULL,
  `Age` int(11) NOT NULL,
  `Gender` smallint(1) NOT NULL,
  `Msisdn` bigint(20) DEFAULT NULL,
  `Operator` int(11) NOT NULL,
  `Service` int(11) NOT NULL,
  `Circle` int(11) NOT NULL,
  `AON` int(11) DEFAULT NULL,
  `Slot` int(11) NOT NULL,
  `limitUser` int(11) NOT NULL,
  `N_Language` int(11) NOT NULL,
  `CategoryOfService` int(11) DEFAULT NULL,
  `Arpu` float DEFAULT NULL,
  `Status_ad` int(11) NOT NULL,
  `CTA_Flag` int(11) DEFAULT NULL,
  `advertiser_id` int(11) NOT NULL,
  `MOU` int(11) DEFAULT NULL,
  `Used_Budget` int(11) DEFAULT '0',
  `CTA_Value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Camp_id`),
  KEY `Operator` (`Operator`),
  KEY `Service` (`Service`),
  KEY `Circle` (`Circle`),
  KEY `N_Language` (`N_Language`),
  KEY `CTA_Flag` (`CTA_Flag`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign_log`
--

DROP TABLE IF EXISTS `tbl_campaign_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign_log` (
  `Camp_id` mediumint(9) NOT NULL DEFAULT '0',
  `Name` varchar(15) DEFAULT NULL,
  `Type` varchar(10) NOT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Start_Date` date DEFAULT NULL,
  `End_Date` date DEFAULT NULL,
  `Total_Budget` float NOT NULL,
  `Daily_Budget` float NOT NULL,
  `Bidding` float(5,2) DEFAULT NULL,
  `Age` int(6) NOT NULL,
  `Gender` char(6) NOT NULL,
  `Msisdn` bigint(12) DEFAULT NULL,
  `Operator` int(3) NOT NULL,
  `Service` int(3) NOT NULL,
  `Circle` int(7) NOT NULL,
  `AON` int(11) DEFAULT NULL,
  `Slot` int(10) NOT NULL,
  `limitUser` int(5) NOT NULL,
  `N_Language` int(3) NOT NULL,
  `CategoryOfService` int(3) DEFAULT NULL,
  `Arpu` int(3) NOT NULL,
  `Status_ad` int(5) DEFAULT NULL,
  `CTA_Flag` int(2) DEFAULT NULL,
  `advertiser_id` int(5) NOT NULL,
  `Used_Budget` float(4,2) DEFAULT NULL,
  `MOU` int(11) DEFAULT NULL,
  `log_date` datetime DEFAULT NULL,
  `CTA_Value` varchar(200) DEFAULT NULL,
  `Type_value` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_campaign_log1`
--

DROP TABLE IF EXISTS `tbl_campaign_log1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_campaign_log1` (
  `Camp_id` mediumint(9) NOT NULL DEFAULT '0',
  `Name` varchar(15) DEFAULT NULL,
  `Type` varchar(10) NOT NULL,
  `Type_value` varchar(500) DEFAULT NULL,
  `Description` varchar(80) DEFAULT NULL,
  `Start_Date` date DEFAULT NULL,
  `End_Date` date DEFAULT NULL,
  `Total_Budget` float(4,2) NOT NULL,
  `Daily_Budget` float(4,2) NOT NULL,
  `Bidding` float(5,2) DEFAULT NULL,
  `Age` int(6) NOT NULL,
  `Gender` char(6) NOT NULL,
  `Msisdn` bigint(12) DEFAULT NULL,
  `Operator` int(3) NOT NULL,
  `Service` int(3) NOT NULL,
  `Circle` int(7) NOT NULL,
  `AON` int(11) DEFAULT NULL,
  `Slot` int(10) NOT NULL,
  `limitUser` int(5) NOT NULL,
  `N_Language` int(3) NOT NULL,
  `CategoryOfService` int(3) DEFAULT NULL,
  `Arpu` int(3) NOT NULL,
  `Status_ad` int(5) DEFAULT NULL,
  `CTA_Flag` int(2) DEFAULT NULL,
  `advertiser_id` int(5) NOT NULL,
  `Used_Budget` float(4,2) DEFAULT NULL,
  `MOU` int(11) DEFAULT NULL,
  `log_date` datetime DEFAULT NULL,
  `CTA_Value` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_error_hits`
--

DROP TABLE IF EXISTS `tbl_error_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_error_hits` (
  `start_date` datetime DEFAULT NULL,
  `ani` varchar(20) DEFAULT NULL,
  `pubName` varchar(40) DEFAULT NULL,
  `pubPWD` varchar(40) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `campName` varchar(30) DEFAULT NULL,
  `opName` varchar(30) DEFAULT NULL,
  `cirName` varchar(30) DEFAULT NULL,
  `eventType` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_login_view`
--

DROP TABLE IF EXISTS `tbl_login_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_login_view` (
  `Uid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `User_name` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `LDate` date NOT NULL DEFAULT '0000-00-00',
  `Status` int(5) NOT NULL,
  `RoleType` int(11) DEFAULT '0',
  `Sub_Role` int(11) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  PRIMARY KEY (`Uid`),
  UNIQUE KEY `User_name` (`User_name`),
  UNIQUE KEY `User_name_2` (`User_name`),
  UNIQUE KEY `User_name_3` (`User_name`)
) ENGINE=MyISAM AUTO_INCREMENT=517 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_memcache_camp_data`
--

DROP TABLE IF EXISTS `tbl_memcache_camp_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_memcache_camp_data` (
  `mem_startDate` datetime DEFAULT NULL,
  `mem_uploadDate` datetime DEFAULT NULL,
  `mem_status` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status_ad` int(11) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `total_budget` float DEFAULT NULL,
  `daily_budget` float DEFAULT NULL,
  `bidding` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `msisdn` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aon` int(11) DEFAULT NULL,
  `slot` int(11) DEFAULT NULL,
  `limituser` int(11) DEFAULT NULL,
  `n_language` int(11) DEFAULT NULL,
  `categoryofservice` int(11) DEFAULT NULL,
  `arpu` float DEFAULT NULL,
  `cta_flag` int(11) DEFAULT NULL,
  `advertiser_id` int(11) DEFAULT NULL,
  `mou` int(11) DEFAULT NULL,
  `used_budget` int(11) DEFAULT NULL,
  `cta_value` varchar(200) DEFAULT NULL,
  `type_value` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_memcache_camp_data1`
--

DROP TABLE IF EXISTS `tbl_memcache_camp_data1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_memcache_camp_data1` (
  `start_date` datetime DEFAULT NULL,
  `upload_date` datetime DEFAULT NULL,
  `ctype` int(11) DEFAULT NULL,
  `cstatus` int(11) DEFAULT NULL,
  `mem_status` int(11) DEFAULT NULL,
  `sumOfdlBudget` int(11) DEFAULT NULL,
  `liveCamp` int(11) DEFAULT NULL,
  `cdata` varchar(600) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_memcache_camp_data_log`
--

DROP TABLE IF EXISTS `tbl_memcache_camp_data_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_memcache_camp_data_log` (
  `mem_startDate` datetime DEFAULT NULL,
  `mem_uploadDate` datetime DEFAULT NULL,
  `mem_status` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status_ad` int(11) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `total_budget` float DEFAULT NULL,
  `daily_budget` float DEFAULT NULL,
  `bidding` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `msisdn` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  `circle` int(11) DEFAULT NULL,
  `aon` int(11) DEFAULT NULL,
  `slot` int(11) DEFAULT NULL,
  `limituser` int(11) DEFAULT NULL,
  `n_language` int(11) DEFAULT NULL,
  `categoryofservice` int(11) DEFAULT NULL,
  `arpu` float DEFAULT NULL,
  `cta_flag` int(11) DEFAULT NULL,
  `advertiser_id` int(11) DEFAULT NULL,
  `mou` int(11) DEFAULT NULL,
  `used_budget` int(11) DEFAULT NULL,
  `cta_value` varchar(200) DEFAULT NULL,
  `type_value` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_memcache_camp_data_log1`
--

DROP TABLE IF EXISTS `tbl_memcache_camp_data_log1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_memcache_camp_data_log1` (
  `start_date` datetime DEFAULT NULL,
  `upload_date` datetime DEFAULT NULL,
  `ctype` int(11) DEFAULT NULL,
  `cstatus` int(11) DEFAULT NULL,
  `mem_status` int(11) DEFAULT NULL,
  `sumOfdlBudget` int(11) DEFAULT NULL,
  `liveCamp` int(11) DEFAULT NULL,
  `cdata` varchar(600) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_role_description`
--

DROP TABLE IF EXISTS `tbl_role_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_role_description` (
  `RoleType` int(11) DEFAULT NULL,
  `RoleDescription` varchar(100) DEFAULT NULL,
  `Status_ad` int(11) DEFAULT NULL,
  `Status_description` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_status_ad_details`
--

DROP TABLE IF EXISTS `tbl_status_ad_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_status_ad_details` (
  `Status_ad_code` int(11) NOT NULL,
  `status_ad_Name` varchar(50) DEFAULT NULL,
  `old_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`Status_ad_code`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_url_event`
--

DROP TABLE IF EXISTS `tbl_url_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_url_event` (
  `operator` varchar(30) DEFAULT NULL,
  `circle` varchar(30) DEFAULT NULL,
  `eventType` varchar(30) DEFAULT NULL,
  `eventCode` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_url_operator_circle`
--

DROP TABLE IF EXISTS `tbl_url_operator_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_url_operator_circle` (
  `operator` varchar(20) DEFAULT NULL,
  `circle` varchar(20) DEFAULT NULL,
  `circle_synonym` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'mob_advertisement'
--
/*!50003 DROP FUNCTION IF EXISTS `func_getAdName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 FUNCTION `func_getAdName`(in_ad_code int) RETURNS int(11)
BEGIN
declare adcode int;
	
        
	select Status_ad_code into adcode from tbl_status_ad_details where old_status=in_ad_code;
RETURN adcode;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getCirName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 FUNCTION `getCirName`(in_cir_code int) RETURNS varchar(100) CHARSET latin1
BEGIN
	declare adcode VARCHAR(100);
	select Circle_Name into adcode from tbl_Circle_Details where  Circle_Code=CONV(CONV(in_cir_code,10,2),2,10);
	return adcode;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 FUNCTION `getName`(in_op_code int) RETURNS varchar(100) CHARSET latin1
BEGIN
declare adcode VARCHAR(100);
	select Operator_Name into adcode from tbl_Operator_Details where  Operator_Code=CONV(CONV(in_op_code,10,2),2,10);
	return adcode;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getOpName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 FUNCTION `getOpName`(in_op_code int) RETURNS varchar(100) CHARSET latin1
BEGIN
declare adcode VARCHAR(100);
	select Operator_Name into adcode from tbl_Operator_Details where  Operator_Code=CONV(CONV(in_op_code,10,2),2,10);
	return adcode;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getSerName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 FUNCTION `getSerName`(in_ser_code int) RETURNS varchar(100) CHARSET latin1
BEGIN
	declare adcode VARCHAR(100);
	select Service_Type into adcode from tbl_Services_Details where  Service_Code=CONV(CONV(in_ser_code,10,2),2,10);
	return adcode;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_checklogout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_checklogout`(IN_User_Name varchar(30),
	out OUT_STATUS int,out OUT_MSG varchar(50))
BEGIN
declare check_existing int;
	
	select count(User_name) into check_existing from mob_advertisement.tbl_Login where  User_Name=IN_User_Name and status=1;
	
	if(check_existing =0)
	then
		set OUT_STATUS=-10;
		set OUT_MSG='Not Logged Out';
		
	else
		set OUT_STATUS=10;
		update mob_advertisement.tbl_Login set Status=0 where User_Name=IN_User_Name;
                set OUT_MSG="Logout successfully";
	end if; 
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_checkUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_checkUser`(IN  IN_User_Name varchar(100),out out_status int)
BEGIN
Declare cnt integer(5);
Set out_status=-1;

	select count(*) into cnt from mob_advertisement.tbl_Login where User_name=IN_User_Name;
if(cnt = 0) Then
		Set out_status=-100;
		
else
		Set out_status=100;
		
end if;
		
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_email`(IN in_campid int,out out_email varchar(100))
BEGIN
Declare  out_aid varchar(50);
select advertiser_id into out_aid from tbl_campaign where  Camp_id=in_campid;
select email into out_email from tbl_Advertiser_Details where Aid=out_aid;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_pub_camp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_pub_camp`(IN in_pid int)
BEGIN
select p.Name Camp_Name,p.Camp_id Camp_id from mob_advertisement.tbl_campaign  p
left join mob_advertisement.tbl_Publisher c  on p.advertiser_id=c.AID
where c.pub_id=in_pid;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_total_sub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_total_sub`(IN in_aid int,IN in_type varchar(50))
BEGIN
if(in_type='Advertiser')then
select Aid Advertiser_id,User_name Name,DateofBirth Dateofbirth,Mbphone mobilenumber,Gender gender,city city,Company_name company_name,Company_Desc Company_Desc,Company_Address Company_Address,email E_mail,country Country from tbl_Advertiser_Details where Super_Aid=in_aid;
elseif(in_type='Admin')then 
select Admin_id Sub_Admin_id,Name Name,Description Description,Msisdn Msisdn,Status_ad Status_ad,Start_date Start_date,End_date End_date,User_name User_name from tbl_admin_view;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_admin_add_pub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_admin_add_pub`(
        IN Login_name varchar(100),
	IN in_Password varchar(50),
	IN Name varchar(50),
	IN in_Type int,
	IN in_Description varchar(200),
	IN in_Msisdn bigint(20),
	IN in_Operator int, 
	IN in_Service int,
	IN in_Circle int,
	out out_status int,
	out OUT_MSG varchar(50),
	out out_pubid mediumint(9)
)
BEGIN
       
	declare cnt integer(5); 
declare oAID int;
  
	set out_status=-9;
SET OUT_MSG="ERROR";
if( Login_name is null or Login_name='')
then
	set out_status=-2;
	SET OUT_MSG="Invalid Data";
	
else
	 select count(*) into cnt from mob_advertisement.tbl_Login where  User_name=Login_name ;
	
		if(cnt=0)then	
			
                        insert into tbl_Login (User_name,Password,LDate,Status,RoleType)values (Login_name,in_Password,date(now()),1,3);
select Uid into oAID from tbl_Login where  User_name=Login_name;		
insert into mob_advertisement.tbl_Publisher(Name,Type,Description,Start_Date,End_Date,Msisdn,Operator
			,Service,Circle,CategoryOfService,Status_ad,CTA_Flag,AID,User_name)
			values(Name,in_Type,in_Description,date(now()),
			'2050-01-01',in_Msisdn,in_Operator,in_Service,in_Circle,-1,1,1,oAID,Login_name);
			set out_status=62;               
			SET OUT_MSG='Successfully inserted';
		else
			set out_status=-63;
			SET OUT_MSG='Publisher name already exist';
		end if;
		select pub_id into out_pubid from mob_advertisement.tbl_Publisher where User_name=Login_name ;
	end if;
	Commit;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_admin_adminview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_admin_adminview`( 
	IN Login_name varchar(100),
	IN in_Password varchar(50),
	IN in_name varchar(50),
	IN in_Description varchar(80),
	IN in_Msisdn bigint(20),
	out out_status int,
	out OUT_MSG varchar(50),
	out out_adminid mediumint(9))
BEGIN
       
	declare cnt integer(5); 
  	set out_status=-9;
SET OUT_MSG="ERROR";
if( Login_name is null or Login_name='')
then
	set out_status=-2;
	SET OUT_MSG="Invalid Data";
	
else
	 select count(*) into cnt from mob_advertisement.tbl_Login where  User_name=Login_name ;
	
		if(cnt=0)then	
			insert into mob_advertisement.tbl_admin_view(Name,Description,Msisdn,Status_ad,Start_Date,End_Date,User_name)
			values(in_name,in_Description,in_Msisdn,1,date(now()),'2050-01-01',Login_name);
                        insert into tbl_Login (User_name,Password,LDate,Status,RoleType)values (Login_name,in_Password,date(now()),1,4);
			
			set out_status=62;               
			SET OUT_MSG='Successfully inserted';
		else
			set out_status=-63;
			SET OUT_MSG='Admin name already exist';
		end if;
		select Admin_id into out_adminid from mob_advertisement.tbl_admin_view where User_name=Login_name ;
	end if;
	Commit;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_admin_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_admin_report`(repType varchar(30))
BEGIN
declare totalBudget int;
declare dailyBudget int;
if(repType='admin')then		
select a.Name campName,date(a.Start_Date) startdate,date(a.End_Date) enddate,a.Total_budget totalBudget,a.Daily_budget dailyBudget,a.camp_id campID,d.user_name userName,b.ad_type adType,c.status_ad_name adStatus,a.status_ad statusCode
,ifnull(B.Total_Hits,0) totalHits
from mob_advertisement.tbl_ad_details b,mob_advertisement.tbl_status_ad_details c,mob_advertisement.tbl_Login d 
,mob_advertisement.tbl_campaign a
left outer join  
tbl_Campaign_summary B
on a.advertiser_id=B.Advertiser_id 
where b.ad_type_code=a.type and
d.Uid=a.advertiser_id and c.status_ad_Code=a.status_ad and a.Camp_id=B.camp_id and c.status_ad_Code!=mob_advertisement.func_getAdName(0) 
and B.date=curdate() 
order by a.status_ad,Start_Date desc;
elseif(repType='publish')then
select P.pub_id pub_id,P.Name pubName,date(Start_Date) startDate,date(End_Date) endDate,user_name userName,status_ad_name pubStatus,totalHits,effectiveHits, failedHits,
total_revenue,eff_revenue,Status_ad statusCode,
E.ad_type pubType from mob_advertisement.tbl_Publisher P
left join tbl_pub_summary S on P.pub_id=S.pub_id
left join mob_advertisement.tbl_status_ad_details on status_ad_Code=Status_ad
left join  mob_advertisement.tbl_ad_details E on 
E.ad_type_code=P.Type where S.date=curdate()  order by Start_Date,totalHits desc;	
elseif(repType='pendingCamp')then
select Camp_id,C.Name,date(Start_Date) Start_Date,date(End_Date) End_Date,ad_type Type,Status_ad,status_ad_Name sDtl,advertiser_id,User_name AdvtName 
from mob_advertisement.tbl_campaign C
left join mob_advertisement.tbl_status_ad_details on Status_ad_code=Status_ad
left join mob_advertisement.tbl_Advertiser_Details on Aid=advertiser_id
left join mob_advertisement.tbl_ad_details on ad_type_code=Type
where Status_ad!=1 order by Start_Date desc;
elseif(repType='pendingCamp')then
select User_name,Mbphone,Company_name,email,Verify_Status,country from mob_advertisement.tbl_Advertiser_Details;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_admin_update_pub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_admin_update_pub`(
        IN Login_name varchar(100),
	IN in_status int,
	out out_status int,
	out OUT_MSG varchar(50)
)
BEGIN
	declare cnt integer(5); 
	set out_status=-9;
SET OUT_MSG="ERROR";
if( Login_name is null or Login_name='' or in_status not in (1,3))
then
	set out_status=-2;
	SET OUT_MSG="Invalid Data";
	
else
	 select Status into cnt from mob_advertisement.tbl_Login where  User_name=Login_name and roleType =3;
		if(cnt is not null) then			
			set out_status=62;               
			SET OUT_MSG='Successfully Updated';
			if (in_status != cnt) then
				
				update mob_advertisement.tbl_Login set Status=in_status where User_name=Login_name;
				update mob_advertisement.tbl_Publisher set Status_ad=in_status where User_name=Login_name;
			end if;
		else
			set out_status=-63;
			SET OUT_MSG='Publisher name not present';
		end if;
	end if;
	Commit;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_block_advertiser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_block_advertiser`(IN manage_type varchar(20),IN in_email varchar(100),out out_Status int,out out_msg varchar(100))
BEGIN
declare cnt int;
declare cnt1 int;
 set out_status=-69;
                       set out_msg='NA'; 
select count(*) into cnt from  mob_advertisement.tbl_Advertiser_Details where email=In_email and Verify_Status=2;
if(manage_type='block_advertiser')then
	select cnt;
	if(cnt>0)then
		
		
		update mob_advertisement.tbl_Advertiser_Details set Verify_Status=3 where email=In_email and Verify_Status=2;
		set out_status=99;
		set out_msg="Advertiser  blocked";
        elseif(cnt=0)then
		set out_status=-99;
		set out_msg="Advertiser not exist therefore not  blocked";
	
	end if;
	elseif(manage_type='unblock_Advertiser')then
       select count(*) into cnt1 from  mob_advertisement.tbl_Advertiser_Details where email=In_email and Verify_Status=3;
		
		select cnt1;
		if(cnt1>0)then
			update mob_advertisement.tbl_Advertiser_Details set Verify_Status=2 where email=In_email and Verify_Status=3;
			set out_status=69;	
			set out_msg="Advertiser is unblocked";
		elseif(cnt1=0)then
			set out_status=-70;
			set out_msg="Advertiser is  already unblocked";
		end if;	
 
                      
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_camp_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_camp_criteria`(in in_cid int,in in_Op int,in in_Fdate varchar(20), in in_Tdate varchar(20),in in_Rev int,in in_gen int,in in_catOfSer int,in in_aos int )
BEGIN
declare cnt int;
declare out_status int;
declare total_fail  int;
declare unique_fail int;
declare out_message varchar(40);
	

	
	
	set out_message='match success!';
	set out_status=1;
	
	select date(date) stdate,camp_id cid,Total_Hits total_hits,Total_unique_hits unique_hits,total_revenue total_revenue,effective_Hits totalEffective_hits,
	unique_effective_Hits uniqueEffective_hits,eff_revenue eff_revenue,failedHits total_fail,uniqueFailedHits unique_fail
	,out_message,out_status from SpiceAdvt_Reports.tbl_Camp_daily
	where (date between date(in_Fdate) and date(date(in_Tdate))) and camp_id=in_cid order by date(date) desc  ;
	
 
 
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_checklogin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_checklogin`(
IN IN_User_Name varchar(50),
IN IN_password varchar(50),
OUT OUT_STATUS varchar(10),
OUT OUT_Msg varchar(100),
out out_User_name varchar(50),
out out_DateofBirth date,
out out_Mbphone bigint(15),
out out_Gender char(6),
out out_city varchar(50),
out out_Company_name varchar(100),
out out_Company_Desc varchar(100),
out out_Company_Address varchar(100),
out out_email varchar(50),
out out_Name varchar(50),
out out_Verify_Status int(11),
out out_Verify_code varchar(100),
out out_country varchar(50),
out out_RoleType int,
out out_Aid mediumint
)
BEGIN
Declare cnt integer(5);
declare vcnt integer(5);
declare vstatus varchar(10);
declare vExpiry date;
declare  roltype int;
Set OUT_STATUS=-19;
	set OUT_STATUS =-11;
	set OUT_Msg="Logined not successful";
	set out_User_name='NA';
	set out_DateofBirth='NULL';
	set out_Mbphone='NA';
	set out_Gender='NA';
	set out_city='NA';
	set out_Company_name='NA';
	set out_Company_Desc='NA';
	set out_Company_Address='NA';
	set out_email='NA';
	set out_Name='NA';
	set out_Verify_Status=0;
	set out_Verify_code='NA';
	set out_country='NA';
        set out_RoleType=0;
        set out_Aid=0;
select count(*) into cnt from mob_advertisement.tbl_Login where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
if(cnt = 0) Then
	select count(*) into vcnt from mob_advertisement.tbl_Login where binary User_Name=trim(IN_User_Name);
	if(vcnt=0)then
		set OUT_STATUS =-13;
		set OUT_Msg="username is incorrect";
	else
		
		
			set OUT_STATUS =-15;
			set OUT_Msg="password is incorrect";
		
	end if;
else
	select RoleType into roltype from mob_advertisement.tbl_Login where User_name=IN_User_Name;
	set out_RoleType=roltype;
	
	if(roltype=2) then
		select Verify_Status,Verify_expiry_date into vstatus,vExpiry from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
	
		if(vstatus=1) then
			set OUT_STATUS =-14;
			set OUT_Msg="Pending for Admin Approval";
		elseif(vstatus=2) then
			set OUT_STATUS =11;
			set OUT_Msg="verification done and Logined  successful";
			update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
			select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
			into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
			out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
		else 
			if(vExpiry<date(now()))
			then
				set OUT_STATUS =-16;
				set OUT_Msg="Verification Expired";
			else
				set OUT_STATUS =-12;
				select Verify_code into out_Verify_code from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
				set OUT_Msg="not verified and not Logined  successful";
			end if;	
		end if;
elseif(roltype=1)then
		select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
		into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
		out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
                set OUT_STATUS =11;
	set OUT_Msg="Admin Logined successful";
	elseif(roltype=3)then
		select A.Status ,A.RoleType,Name,Type,Description,date(Start_Date),
		date(End_Date),Msisdn,Operator,Service,
		Circle,Status_ad,CTA_Flag from mob_advertisement.tbl_Publisher tb
		left outer join 
		mob_advertisement.tbl_Login A on A.User_name=tb.User_name
		where A.User_name=IN_User_Name and tb.User_name=IN_User_Name;
		update mob_advertisement.tbl_Login set Status=2 where User_name=IN_User_Name;
                select pub_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_Publisher where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
               elseif(roltype=4)then   	
		select Admin_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_admin_view where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
	else
		set OUT_STATUS =11;
		set OUT_Msg="verification done and Logined  successful";
		update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
	end if;
      
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cir_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_cir_summary`(in stdate varchar(20))
BEGIN
declare hrcnt int;
declare varFailedHits int;
declare uniFailedHits int;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_tot_hits;
	truncate table  SpiceAdvt_Reports.tbl_temp_camp_eff_hits;
	truncate table	SpiceAdvt_Reports.tbl_temp_camp_CTA;
	insert into SpiceAdvt_Reports.tbl_temp_camp_tot_hits(date,criteria,camp_id,tot_hits,uniq_tot_hits,total_revenue)
	select Date(stdate),circle,camp_id,count(*),count(distinct Ani),sum(totalRevenue)
	from mob_advertisement.tbl_Total_Hits 
	where date(Date)=date(stdate)
	group by circle,camp_id;
	
	insert into SpiceAdvt_Reports.tbl_temp_camp_eff_hits(date,criteria,camp_id,eff_hits,uniq_eff_hits, eff_revenue, failedHits, uniqueFailedHits)
	select Date(stdate),A.circle,A.camp_id,count(*),count(distinct Ani),sum(effRevenue),Fld, uFld 
	from mob_advertisement.tbl_Effective_Hits A left join
	(select count(ani) Fld,count(distinct ani) uFld,circle, date,camp_id from mob_advertisement.tbl_Effective_Hits where date(Date)=date(stdate) and status=-1 group by circle,camp_id) 
	as FAiled on (A.circle=FAiled.circle  AND A.camp_id=FAiled.camp_id) 
	where date(A.Date)=date(stdate)
	group by A.circle,A.camp_id;
	
	insert into SpiceAdvt_Reports.tbl_temp_camp_CTA(Date,criteria,camp_id,Total_hits,Unique_hits)
	select Date(stdate),hour(Date),camp_id,count(*),count(distinct Ani)
	from  mob_advertisement.tbl_CTA 
	where date(Date)=date(stdate) 
	group by camp_id;
	select count(stdate) into hrcnt from SpiceAdvt_Reports.tbl_campaign_op_summary where  date(Date)=date(stdate);
	if(hrcnt>0)then
	delete from SpiceAdvt_Reports.tbl_campaign_op_summary where  date(Date)=date(stdate);
	end if;
	
	insert into SpiceAdvt_Reports.tbl_campaign_op_summary(date,Operator,op_name,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,
	Click_to_action,unique_Click_to_action,
	failedHits,uniqueFailedHits,Total_Revenue,Eff_Revenue,Advertiser_id,Status,unique_eff_Hits)
	select Date(stdate),Op,opName,C_ID,campName,ifnull(tot_hits,0),ifnull(eff_hits,0),ifnull(uniq_tot_hits,0),ifnull(Total_hits,0),ifnull(Unique_hits,0),
	ifnull(failedHits,0),ifnull(uniqueFailedHits,0),ifnull(total_revenue,0),ifnull(eff_revenue,0),advid,StatusAd,ifnull(uniq_eff_hits,0)
	from
	(select A.Operator_Code Op,A.Operator_Name opName, tb2.camp_id C_ID,tb2.Name campName,tb2.Status_ad  StatusAd,tb2.advertiser_id advid from mob_advertisement.tbl_Operator_Details A left join  mob_advertisement.tbl_campaign tb2 on tb2.Operator=pow(2,Operator_Code-1))as A1
	left outer join SpiceAdvt_Reports.tbl_temp_camp_tot_hits C  on A1.Op=C.criteria and A1.C_ID =C.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_eff_hits D on A1.Op=D.criteria and A1.C_ID =D.camp_id
	left outer join SpiceAdvt_Reports.tbl_temp_camp_CTA  E on A1.Op=E.criteria and A1.C_ID =E.camp_id
	order by A1.Op,A1.C_ID ;
	
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_check_new` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_check_new`(
IN IN_User_Name varchar(50),
IN IN_password varchar(50),
OUT OUT_STATUS varchar(10),
OUT OUT_Msg varchar(100),
out out_User_name varchar(50),
out out_DateofBirth date,
out out_Mbphone bigint(15),
out out_Gender char(6),
out out_city varchar(50),
out out_Company_name varchar(100),
out out_Company_Desc varchar(100),
out out_Company_Address varchar(100),
out out_email varchar(50),
out out_Name varchar(50),
out out_Verify_Status int(11),
out out_Verify_code varchar(100),
out out_country varchar(50),
out out_RoleType int,
out out_Aid mediumint
)
BEGIN
Declare cnt integer(5);
Declare cntView integer(5);
Declare cnt2 integer(5);
Declare cnt3 int;
declare vcnt integer(5);
declare vstatus varchar(10);
declare vExpiry date;
declare  roltype int;
Declare cnt1 integer(5);
declare subrole int;
Set OUT_STATUS=-19;
	set OUT_STATUS =-11;
	set OUT_Msg="Logined not successful";
	set out_User_name='NA';
	set out_DateofBirth='NULL';
	set out_Mbphone='NA';
	set out_Gender='NA';
	set out_city='NA';
	set out_Company_name='NA';
	set out_Company_Desc='NA';
	set out_Company_Address='NA';
	set out_email='NA';
	set out_Name='NA';
	set out_Verify_Status=0;
	set out_Verify_code='NA';
	set out_country='NA';
        set out_RoleType=0;
        set out_Aid=0;
select count(*) into cnt from mob_advertisement.tbl_Login where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
if(cnt = 0) Then
select count(*) into cntView from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
	if(cntView=0)then
		select count(*) into vcnt from mob_advertisement.tbl_Login where binary User_Name=trim(IN_User_Name);
		if(vcnt=0)then
			set OUT_STATUS =-13;
			set OUT_Msg="username is incorrect";
		else
			
			
				set OUT_STATUS =-15;
				set OUT_Msg="password is incorrect";
			
		end if;
	
	else if(cntView=1)then
		select cntView;
		select RoleType into roltype from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
   if(roltype=6) then
	select count(*) into cnt2 from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
select cnt2;	
if(cnt2 = 1)then
		select Sub_Role into subrole from mob_advertisement.tbl_login_view where binary User_Name=IN_User_Name and binary Password=IN_password;
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
	else
		set OUT_STATUS =-12;
		set OUT_Msg="not verified and not Logined  successful";
	end if;	
		elseif(roltype=7)then
		select count(*) into cnt3 from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
		select cnt3;	
		if(cnt3 = 1)then
			select Sub_Role into subrole from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
				set OUT_STATUS=11;
			set OUT_Msg="Logined  successful";
		else
			set OUT_STATUS =-12;
			set OUT_Msg="not verified and not Logined  successful";
		end if;
end if;
	end if;
	end if;
else
	select RoleType into roltype from mob_advertisement.tbl_Login where User_name=IN_User_Name;
	set out_RoleType=roltype;
	
	if(roltype=2) then
		select Verify_Status,Verify_expiry_date into vstatus,vExpiry from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
	
		if(vstatus=1) then
			set OUT_STATUS =-14;
			set OUT_Msg="Pending for Admin Approval";
		elseif(vstatus=2) then
			set OUT_STATUS =11;
			set OUT_Msg="verification done and Logined  successful";
			update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
			select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
			into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
			out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
		else 
			if(vExpiry<date(now()))
			then
				set OUT_STATUS =-16;
				set OUT_Msg="Verification Expired";
			else
				set OUT_STATUS =-12;
				select Verify_code into out_Verify_code from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
				set OUT_Msg="not verified and not Logined  successful";
			end if;	
		end if;
elseif(roltype=1)then
		select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
		into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
		out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
                set OUT_STATUS =11;
	set OUT_Msg="Admin Logined successful";
	elseif(roltype=3)then
		select A.Status ,A.RoleType,Name,Type,Description,date(Start_Date),
		date(End_Date),Msisdn,Operator,Service,
		Circle,Status_ad,CTA_Flag from mob_advertisement.tbl_Publisher tb
		left outer join 
		mob_advertisement.tbl_Login A on A.User_name=tb.User_name
		where A.User_name=IN_User_Name and tb.User_name=IN_User_Name;
		update mob_advertisement.tbl_Login set Status=2 where User_name=IN_User_Name;
                select pub_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_Publisher where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
               elseif(roltype=4)then   	
		select Admin_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_admin_view where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
	else
		set OUT_STATUS =11;
		set OUT_Msg="verification done and Logined  successful";
		update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
	end if;
      
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_create_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_create_view`(
IN IN_User_Name varchar(100),
IN IN_password varchar(50),
IN in_circle int,
IN in_operator int,
IN in_rtype varchar(50),
OUT OUT_MSG varchar(100),
OUT OUT_STATUS int
)
BEGIN
declare cnt integer(5);
declare ct integer(5);
declare Ouid int;


if( IN_User_name is null or IN_User_name=''or IN_password is null or IN_password ='')
then
	set OUT_STATUS=-2;
	SET OUT_MSG="Invalid Data";
	
else
if(in_rtype="operator")Then
	select count(*) into cnt from mob_advertisement.tbl_login_view where User_name=IN_User_Name;
	if(cnt=0) Then
      		insert into tbl_login_view(User_name,Password,LDate,Status,RoleType,Sub_Role,code)values(IN_User_Name,IN_password,now(),1,6,in_circle,in_operator);
		set OUT_STATUS =1;
		SET OUT_MSG="Registered successfully.";
	else
		set OUT_STATUS =-1;
		SET OUT_MSG="Registered Alreday.";
		
	end if;
elseif(in_rtype="circle")Then
	select count(*) into cnt from mob_advertisement.tbl_login_view where User_name=IN_User_Name;
	if(cnt=0) Then
      		insert into tbl_login_view(User_name,Password,LDate,Status,RoleType,Sub_Role,code)values(IN_User_Name,IN_password,now(),1,7,in_operator,in_circle);
		set OUT_STATUS =1;
		SET OUT_MSG="Registered successfully.";
	else
		set OUT_STATUS =-1;
		SET OUT_MSG="Registered Alreday.";
		
	end if;
	end if;
	
end if;
Commit;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_criteria`(in in_cid int,in in_Op int,in in_cir int,in in_ser int,in in_Fdate varchar(20), in in_Tdate varchar(20),in type varchar(20))
BEGIN
declare cnt int;
declare out_status int;
declare total_fail  int;
declare unique_fail int;
declare out_message varchar(40);
        set out_message='match success!';
	set out_status=1;
if(type='camp')then
select date(date) stdate,camp_id cid,Total_Hits total_hits,Total_unique_hits unique_hits,total_revenue total_revenue,effective_Hits totalEffective_hits,
	unique_effective_Hits uniqueEffective_hits,eff_revenue eff_revenue,failedHits total_fail,uniqueFailedHits unique_fail
	,out_message,out_status from SpiceAdvt_Reports.tbl_Camp_daily
	where (date between date(in_Fdate) and date(date(in_Tdate))) and camp_id=in_cid order by date(date) desc  ;
elseif(type='circle')then
select date(Date) stdate,circle,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Total_budget,Left_budget,Used_Budget,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue
from SpiceAdvt_Reports.tbl_Campaign_circle where (date between date(in_Fdate) and date(date(in_Tdate))) and circle=in_cir  order by date(Date) desc  ;
elseif(type='service')then
select date(Date) stdate,Service,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Total_budget,Left_budget,Used_Budget,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue
from SpiceAdvt_Reports.tbl_Campaign_Service where (date between date(in_Fdate) and date(date(in_Tdate))) and Service=in_ser  order by date(Date) desc  ;
elseif(type='operator')then
select date(Date) stdate,Operator,camp_id,camp_name,Total_Hits,effective_Hits,Total_unique_hits,unique_eff_Hits,Total_budget,Left_budget,Used_Budget,unique_Click_to_action,failedHits,uniqueFailedHits,total_revenue,eff_revenue
from SpiceAdvt_Reports.tbl_campaign_op_summary where (date between date(in_Fdate) and date(date(in_Tdate))) and Operator=in_Op  order by date(Date) desc  ;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_delete_sub_admin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_delete_sub_admin`(IN in_email  varchar(100),out out_status int,out out_msg varchar(100))
BEGIN
declare cnt int;
    select count(*) into cnt from mob_advertisement.tbl_Login where User_name=in_email and RoleType=4;
	if(cnt=0)then
		set out_status=-19;
		set out_msg="Sub Admin doesnot exist";
	else 
	insert into mob_advertisement.tbl_Login_log select * from mob_advertisement.tbl_Login where  User_name=in_email; 
	insert into mob_advertisement.tbl_admin_view_log select * from mob_advertisement.tbl_admin_view where  User_name=in_email;
	delete from mob_advertisement.tbl_Login where User_name=in_email;
	delete from mob_advertisement.tbl_admin_view where User_name=in_email;
		set out_status=19;
		set out_msg="Sub Admin successfully deleted";
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_delete_Sub_Advertiser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_delete_Sub_Advertiser`(IN in_email  varchar(100),out out_status int,out out_msg varchar(100))
BEGIN
declare cnt int;
    select count(*) into cnt from mob_advertisement.tbl_Login where User_name=in_email and RoleType=5;
	if(cnt=0)then
		set out_status=-19;
		set out_msg="Sub Advertiser doesnot exist";
	else 
	insert into mob_advertisement.tbl_Login_log select * from mob_advertisement.tbl_Login where  User_name=in_email; 
	insert into mob_advertisement.tbl_Advertiser_Details_log select * from mob_advertisement.tbl_Advertiser_Details where  email=in_email;
	delete from mob_advertisement.tbl_Login where User_name=in_email;
	delete from mob_advertisement.tbl_Advertiser_Details where email=in_email;
		set out_status=19;
		set out_msg="Sub Advertiser successfully deleted";
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_dumy_insert_hit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_dumy_insert_hit`(IN in_Ani bigint(15),
IN in_status int,
IN in_duration int,


IN in_pub_id int,
IN in_camp_id int,
IN in_usedBudget int,
out out_status int(5),
out OUT_MSG varchar(50))
BEGIN
declare INusedBudget int;
declare in_Adv_id int;
set INusedBudget=5; 
select advertiser_id into in_Adv_id from mob_advertisement.tbl_campaign where Camp_id=in_camp_id;
if( in_Ani is null or in_Ani='' or in_pub_id is null ) then
set out_status=-52;
SET OUT_MSG="Invalid Data";
else
if(in_duration>10) then
INSERT INTO mob_advertisement.tbl_Effective_Hits(Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue)VALUES
(in_Ani,in_status,in_duration,now(),in_Adv_id,in_pub_id,in_camp_id,INusedBudget);
set out_status=54;
SET OUT_MSG="effective duration";
else
INSERT INTO mob_advertisement.tbl_Effective_Hits(Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue)VALUES
(in_Ani,0,in_duration,now(),in_Adv_id,in_pub_id,in_camp_id,INusedBudget);
set out_status=53;
SET OUT_MSG="inserted with status 0";
end if;
INSERT INTO mob_advertisement.tbl_Total_Hits(Ani,Status,Date,Advertisement_id,Pub_id,camp_id,totalRevenue)VALUES
(in_Ani,in_status,now(),in_Adv_id,in_pub_id,in_camp_id,INusedBudget);
set out_status=52;
SET OUT_MSG="inserted";
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_fetch_camp_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_fetch_camp_details`(IN in_Camp_id mediumint(9))
BEGIN
Declare  out_Name varchar(50);
select Name into out_Name from tbl_campaign where  Camp_id=in_Camp_id;
if(out_Name is NOT NULL)then
select Name out_Name,Type out_Type,Description out_Description,date(Start_Date) out_Start_Date,date(End_Date) out_End_Date,
Total_Budget out_Total_Budget,Daily_Budget out_Daily_Budget,Bidding out_Bidding,Age out_Age,Gender out_Gender ,
Msisdn out_Msisdn,Operator out_Operator,Service out_Service,Circle out_Circle,AON out_AON,Slot out_Slot,
limitUser out_limitUser,N_Language out_N_Language,CategoryOfService out_CategoryOfService,
Arpu out_Arpu,Status_ad out_Status_ad,CTA_Flag out_CTA_Flag,advertiser_id  out_advertiser_id,MOU out_MOU,CTA_Value,Type_value
from  mob_advertisement.tbl_campaign where Camp_id=in_Camp_id;
end if;
			
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_hit_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_hit_data`(
IN in_Ani bigint(15),
IN in_status int,
IN in_duration int,
IN in_pub_id int,
IN in_camp_id int,
IN in_usedBudget int,
IN in_opCode int,
IN in_cirCode int,
IN in_eventType int,
out out_status int(5),
out OUT_MSG varchar(50)
)
BEGIN
declare INusedBudget int;
declare in_Adv_id int;
set INusedBudget=5; 
if(in_Ani is null or in_Ani='' or in_pub_id =0 or in_opCode=0 or in_cirCode=0) then
	set out_status=-52;
	SET OUT_MSG="Invalid Data";
	
else	
	if(in_duration>10) then
		INSERT INTO mob_advertisement.tbl_Effective_Hits(Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue,operator,circle,eventType)VALUES
		(in_Ani,in_status,in_duration,now(),1,in_pub_id,in_camp_id,INusedBudget,in_opCode,in_cirCode,in_eventType);
		set out_status=54;
		SET OUT_MSG="effective duration";
	end if;
		INSERT INTO mob_advertisement.tbl_Total_Hits(Ani,Status,Date,Advertisement_id,Pub_id,camp_id,totalRevenue,operator,circle,eventType)VALUES
		(in_Ani,in_status,now(),1,in_pub_id,in_camp_id,INusedBudget,in_opCode,in_cirCode,in_eventType);
		set out_status=52;
		SET OUT_MSG="inserted";
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_hit_temp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_hit_temp`(
IN in_Ani bigint(15),
IN in_status int,
IN in_duration int,
IN in_pub_id int,
IN in_camp_id int,
IN in_usedBudget int,
IN in_opCode int,
IN in_cirCode int,
IN in_eventType int,
out out_status int(5),
out OUT_MSG varchar(50)
)
BEGIN
declare INusedBudget int;
declare in_Adv_id int;
set INusedBudget=5; 
select in_Ani,in_pub_id,in_opCode,in_cirCode;
if(in_Ani is null or in_Ani='' or in_pub_id is null or in_opCode=0 or in_cirCode=0) then
	set out_status=-52;
	SET OUT_MSG="Invalid Data";
	
	
else
	if(in_duration>10) then
		INSERT INTO mob_advertisement.tbl_Effective_Hits(Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue,operator,circle,eventType)VALUES
		(in_Ani,in_status,in_duration,now(),1,in_pub_id,in_camp_id,INusedBudget,in_opCode,in_cirCode,in_eventType);
		set out_status=54;
		SET OUT_MSG="effective duration";
	end if;
		INSERT INTO mob_advertisement.tbl_Total_Hits(Ani,Status,Date,Advertisement_id,Pub_id,camp_id,totalRevenue,operator,circle,eventType)VALUES
		(in_Ani,in_status,now(),1,in_pub_id,in_camp_id,INusedBudget,in_opCode,in_cirCode,in_eventType);
		set out_status=52;
		SET OUT_MSG="inserted";
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_insert_hit_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_insert_hit_data`(
IN in_Ani bigint(15),
IN in_status int,
IN in_duration int,


IN in_pub_id int,
IN in_camp_id int,
IN in_usedBudget int,
out out_status int(5),
out OUT_MSG varchar(50))
BEGIN
declare INusedBudget int;
declare in_Adv_id int;
set INusedBudget=5; 
select advertiser_id into in_Adv_id from mob_advertisement.tbl_campaign where Camp_id=in_camp_id;
if( in_Ani is null or in_Ani='' or in_pub_id is null ) then
set out_status=-52;
SET OUT_MSG="Invalid Data";
else
if(in_duration>10) then
INSERT INTO mob_advertisement.tbl_Effective_Hits(Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue)VALUES
(in_Ani,in_status,in_duration,now(),in_Adv_id,in_pub_id,in_camp_id,INusedBudget);
set out_status=54;
SET OUT_MSG="effective duration";
else
INSERT INTO mob_advertisement.tbl_Effective_Hits(Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue)VALUES
(in_Ani,0,in_duration,now(),in_Adv_id,in_pub_id,in_camp_id,INusedBudget);
set out_status=53;
SET OUT_MSG="inserted with status 0";
end if;
INSERT INTO mob_advertisement.tbl_Total_Hits(Ani,Status,Date,Advertisement_id,Pub_id,camp_id,totalRevenue)VALUES
(in_Ani,in_status,now(),in_Adv_id,in_pub_id,in_camp_id,INusedBudget);
set out_status=52;
SET OUT_MSG="inserted";
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_insert_tbl_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_insert_tbl_campaign`(
        IN in_Advertiser_email varchar(50),
	IN in_Name varchar(50),
	IN in_Type int,
	IN in_Description varchar(200),
	IN in_Start_Date Date,
	IN in_End_Date Date,
	IN in_Total_Budget float,
	IN in_Daily_Budget float,
	IN in_Bidding float,
	IN in_Age int,
	IN in_Gender char,
	IN in_Msisdn bigint(15),
	IN in_Operator int, 
	IN in_Mou int,
	IN in_Circle int,
	IN in_AON int,
	IN in_Slot int,
	IN in_limitUser int, 
	IN in_N_Language int,
	IN in_CategoryOfService int,
	IN in_Arpu float,
	IN in_CTA int,
	IN in_CTA_value varchar(200),
        IN in_Type_value varchar(500),
	out out_status int,
	out OUT_MSG varchar(50))
BEGIN
	declare varGender integer(5);
	declare cnt integer(5); 
	declare var_Advertiser_id int;
	declare acnt int;
	
		set out_status=-99;
		SET OUT_MSG="Error";
	select count(*) into acnt from mob_advertisement.tbl_campaign where  Name=in_Name;
	select Aid into var_Advertiser_id from mob_advertisement.tbl_Advertiser_Details where email=in_Advertiser_email limit 1;
	if(in_Gender in ('F','f')) then
		set varGender=1;
	elseif(in_Gender in ('M','m')) then
		set varGender=2;
	elseif(in_Gender in ('A','a')) then
		set varGender=3;
	else
		set varGender=-1;
	end if;
        if(var_Advertiser_id>0)then
		if(acnt=0)then
			select count(*) into cnt from mob_advertisement.tbl_campaign where advertiser_id=var_Advertiser_id and Name=in_Name;
					      
			insert into mob_advertisement.tbl_campaign_log(Name,Type,Description,Start_Date,End_Date,Total_Budget,Daily_Budget,Bidding,Age,Gender,Msisdn,Operator,Circle,AON,Slot,limitUser,N_Language,CategoryOfService,Arpu,Status_ad,CTA_Flag,advertiser_id,MOU,log_date,CTA_Value,Type_value) 
			values(in_Name,in_Type,in_Description,date(in_Start_Date),date(in_End_Date),in_Total_Budget,in_Daily_Budget,in_Bidding,in_Age,varGender,in_Msisdn,
			in_Operator,in_Circle,in_AON,in_Slot,in_limitUser,in_N_Language,in_CategoryOfService,in_Arpu,func_getAdName(1),in_CTA,var_Advertiser_id,in_Mou,now(),in_CTA_value,in_Type_value);
			  
			if( in_Operator is null or in_Operator=''or in_Mou is null  or in_Circle is null or in_Circle='' or in_N_Language is null or in_N_Language ='') then
				set out_status=-62;
				SET OUT_MSG="Invalid Data";
			else 
			    
				if(cnt=0)then	
					insert into mob_advertisement.tbl_campaign(Name,Type,Description,Start_Date,End_Date,Total_Budget,Daily_Budget,Bidding,Age,
					Gender,Msisdn,Operator,Circle,AON,Slot,limitUser,N_Language,CategoryOfService,Arpu,Status_ad,CTA_Flag,advertiser_id,MOU,CTA_Value,Type_value) 
					values(in_Name,in_Type,in_Description,date(in_Start_Date),
					date(in_End_Date),in_Total_Budget,in_Daily_Budget,in_Bidding,in_Age,varGender,in_Msisdn,
					in_Operator,in_Circle,in_AON,in_Slot,in_limitUser,in_N_Language,in_CategoryOfService,in_Arpu,func_getAdName(0),in_CTA,var_Advertiser_id,in_Mou,in_CTA_value,in_Type_value);
				
					set out_status=62;               
					SET OUT_MSG='Successfully inserted';
				else 
					set out_status=-63;
					SET OUT_MSG='campaign name allready exist';
				
				end if;		
				
			end if;
		else 
			set out_status=-63;
			SET OUT_MSG='campaign name allready exist.';
		end if;		
	
	else 
		SET OUT_MSG='Advertiser not exist';
	end if;
Commit;
  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_move_hits` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_move_hits`()
BEGIN
	insert into tbl_Effective_Hits_log (Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue,operator,circle,eventType)
	select Ani,Status,Duration,Date,Advertisement_id,Pub_id,camp_id,effRevenue,operator,circle,eventType
	from tbl_Effective_Hits where date(Date)<=date(subdate(curdate(),5));
	
	delete from tbl_Effective_Hits where date(Date)<=date(subdate(curdate(),5));
	
	insert into tbl_Total_Hits_log(Ani,Status,Date,Advertisement_id,Pub_id,camp_id,totalRevenue,operator,circle,eventType)
	select Ani,Status,Date,Advertisement_id,Pub_id,camp_id,totalRevenue,operator,circle,eventType
	from tbl_Total_Hits where date(Date)<=date(subdate(curdate(),5));
	
	delete from tbl_Total_Hits where date(Date)<=date(subdate(curdate(),5));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_new_camp_criteria` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_new_camp_criteria`(
in in_cid int,
in in_Op int,
in in_Fdate varchar(20),
in in_Tdate varchar(20),
in in_Rev int,
in in_gen int,
in in_catOfSer int,
in in_aos int,
IN in_Age int,
IN in_Msisdn bigint(15),
IN in_Mou int,
IN in_Circle int,
IN in_AON int,
IN in_Slot int,
IN in_N_Language int,
IN in_CategoryOfService int,
IN in_Arpu float
 )
BEGIN
declare cnt int;
declare out_status int;
declare total_fail  int;
declare unique_fail int;
declare out_message varchar(40);
	

	
	
	set out_message='match success!';
	set out_status=1;
	select date(date) stdate,camp_id cid,Total_Hits total_hits,Total_unique_hits unique_hits,total_revenue total_revenue,effective_Hits totalEffective_hits,
	unique_effective_Hits uniqueEffective_hits,eff_revenue eff_revenue,failedHits total_fail,uniqueFailedHits unique_fail
	,out_message,out_status from SpiceAdvt_Reports.tbl_Camp_daily
	where (date between date(in_Fdate) and date(date(in_Tdate)-1)) and camp_id=in_cid order by date(date)  ;
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_new_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_new_register`(
IN IN_User_Name varchar(100),
IN IN_password varchar(50),
IN IN_DOB Date,
IN IN_Mbph bigint(12),
IN IN_Gender char(6),
IN IN_city varchar(50),
IN IN_country varchar(50),
IN IN_Company_name  varchar(50) ,
IN IN_Company_Desc varchar(200),
IN IN_Company_Address varchar(100),
IN IN_email varchar(100),
OUT OUT_MSG varchar(100),
OUT OUT_STATUS int,
out out_Verify_Status int(5),
out out_Verify_code varchar(100)
)
BEGIN
declare cnt integer(5);
declare ct integer(5);
declare Ouid int;
set OUT_STATUS=-9;
SET OUT_MSG="ERROR";
if( IN_User_name is null or IN_User_name=''or IN_password is null or IN_password ='')
then
	set OUT_STATUS=-2;
	SET OUT_MSG="Invalid Data";
	set out_Verify_Status  =0;
	set out_Verify_code  ='NA';
else
	select count(*) into cnt from mob_advertisement.tbl_Advertiser_Details where email=IN_email;
	select count(*) into ct from mob_advertisement.tbl_Login where User_name=IN_email;
	set out_Verify_code  =uuid();
	set out_Verify_Status  =0;
	if(ct=0) Then
	if(cnt=0) Then
		insert into mob_advertisement.tbl_Login(User_name,Password,LDate,Status,RoleType)VALUES (IN_email, IN_Password, date(now()),0,2);
		select Uid into Ouid from mob_advertisement.tbl_Login where User_name=IN_email;
		
		insert into mob_advertisement.tbl_Advertiser_Details(Aid,User_name,Password,DateofBirth,Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Verify_Status,Verify_code,Verify_expiry_date,country)
		VALUES(Ouid,IN_User_name, IN_Password, IN_DOB,IN_Mbph,IN_Gender,IN_city,IN_Company_name,IN_Company_Desc,IN_Company_Address,IN_email,0,out_Verify_code,date(now()+interval 3 day),IN_country);
		set OUT_MSG ="Successfully Registered ";
		SET OUT_STATUS=1;
		
	else
		set OUT_STATUS =-1;
		SET OUT_MSG="Registered Alreday.";
		set out_Verify_Status  =0;
		set out_Verify_code  ='NA';
	end if;
	else 
		set OUT_STATUS =-1;
		SET OUT_MSG="Registered Alreday";
		set out_Verify_Status  =0;
		set out_Verify_code  ='NA';
	end if;	
end if;
Commit;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_password`(
IN in_email varchar(100),
IN in_oldPass varchar(50),
IN in_newPass varchar(50),
IN Pass_type varchar(20),
out out_pass varchar(50),
out out_msg varchar(50),
out out_status int,
out out_email varchar(100))
BEGIN
Declare Pass varchar(50);	
Declare cnt int;
set out_pass='NA';
set out_msg='NA';

set  out_status=-99;
set out_email=in_email;
select count(*)into cnt from mob_advertisement.tbl_Login where  User_name=in_email ;
if(cnt>0)then		
	if(Pass_type='F')then
		select Password into Pass  from mob_advertisement.tbl_Login where User_name=in_email;                 
		set out_pass=Pass;
                 set  out_status=98;
                   set out_msg= "password get";
	elseif(Pass_type='c')then
		
		update mob_advertisement.tbl_Login set Password=in_newPass where  User_name=in_email;
		set out_msg="successfully changed";
                set  out_status=99;
		
	end if;
else 
	set out_msg="user doesnot exist";      
        set  out_status=-100;             
end if;
                        
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_register`(
IN IN_Aid mediumint(9),
IN IN_User_Name varchar(30),
IN IN_password varchar(10),
IN IN_DOB Date,
IN IN_Mbph bigint(12),
IN IN_Gender char(6),
IN IN_city varchar(10),
IN IN_Company_name  varchar(10) ,
IN IN_Company_Desc varchar(20),
IN IN_Company_Address varchar(20),
IN IN_email varchar(20),
IN IN_name varchar(20),
IN IN_country varchar(10),
OUT OUT_MSG varchar(30),
OUT OUT_STATUS int,
out out_User_name varchar(30),
out out_DateofBirth date,
out out_Mbphone char(10),
out out_Gender char(6),
out out_Location varchar(10),
out out_Company_name varchar(10),
out out_Company_Desc varchar(20),
out out_Company_Address varchar(20),
out out_email varchar(20),
out out_Name varchar(20),
out out_Verify_Status int(5),
out out_Verify_code varchar(10)
)
BEGIN
declare cnt integer(5);
set OUT_STATUS=-9;
SET OUT_MSG="ERROR";
insert into tbl_Advertiser_Details_log(Aid,User_name,Password,DateofBirth,Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,Verify_expiry_date,country)VALUES(IN_Aid,IN_User_name, IN_Password, IN_DOB,IN_Mbph,IN_Gender,IN_city,IN_Company_name,IN_Company_Desc,IN_Company_Address,IN_email,IN_name,1,uuid(),date(now()+interval 3 day),IN_country);
insert into tbl_Login_log(Uid,User_name,Password,LDate,Status)VALUES (IN_User_name, IN_Password, now(),0);
if( IN_User_name is null or IN_User_name=''or IN_password is null or IN_password is null)
then
set OUT_STATUS=-2;
SET OUT_MSG="Invalid Data";
set out_User_name='NA';
else
select count(*) into cnt from tbl_Advertiser_Details where User_name=IN_User_Name;
if(cnt=0) Then
insert into tbl_Advertiser_Details(Aid,User_name,Password,DateofBirth,Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,Verify_expiry_date,country)VALUES(IN_Aid,IN_User_name, IN_Password, IN_DOB,IN_Mbph,IN_Gender,IN_city,IN_Company_name,IN_Company_Desc,IN_Company_Address,IN_email,IN_name,1,uuid(),date(now()+interval 3 day),IN_country);
insert into tbl_Login(User_name,Password,LDate,Status)VALUES (IN_User_name, IN_Password, now(),0);
set OUT_MSG ="Successfully Registered ";
set out_Verify_code  =uuid();
SET OUT_STATUS=1;
select Verify_Status into  out_Verify_Status from tbl_Advertiser_Details where User_name=IN_User_Name;
else
set OUT_STATUS =-1;
SET OUT_MSG="Registered Alreday";
end if;
end if;
Commit;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_setdata_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_setdata_campaign`(
IN in_Advertiser_email varchar(50),
IN in_Name varchar(50),
IN in_Type int,
IN in_Description varchar(500),
IN in_Start_Date Date,
IN in_End_Date Date,
IN in_Total_Budget float,
IN in_Daily_Budget float,
IN in_Bidding float,
IN in_Age int,
IN in_Gender char,
IN in_Msisdn bigint(15),
IN in_Operator int, 
IN in_Mou int,
IN in_Circle int,
IN in_AON int,
IN in_Slot int,
IN in_limitUser int, 
IN in_N_Language int,
IN in_CategoryOfService int,
IN in_Arpu float,
IN in_CTA int,
IN in_CTA_value varchar(200),
out out_status int,
out OUT_MSG varchar(50)
)
BEGIN
declare varGender integer(5);
declare cnt integer(5); 
declare var_Advertiser_id int;
declare acnt int;
set out_status=-99;
SET OUT_MSG="Error";
select count(*) into acnt from tbl_campaign where  Name=in_Name;
select Aid into var_Advertiser_id from tbl_Advertiser_Details where email=in_Advertiser_email limit 1;
if(in_Gender in ('F','f')) then
set varGender=1;
elseif(in_Gender in ('M','m')) then
set varGender=2;
elseif(in_Gender in ('A','a')) then
set varGender=3;
else
set varGender=-1;
end if;
if(var_Advertiser_id>0)then
if(acnt=0)then
select count(*) into cnt from tbl_campaign where advertiser_id=var_Advertiser_id and Name=in_Name;
insert into tbl_campaign_log(Name,Type,Description,Start_Date,End_Date,Total_Budget,Daily_Budget,Bidding,Age,Gender,Msisdn,Operator,Circle,AON,Slot,limitUser,N_Language,CategoryOfService,Arpu,Status_ad,CTA_Flag,advertiser_id,MOU,log_date,CTA_Value) 
values(in_Name,in_Type,in_Description,date(in_Start_Date),date(in_End_Date),in_Total_Budget,in_Daily_Budget,in_Bidding,in_Age,varGender,in_Msisdn,
in_Operator,in_Circle,in_AON,in_Slot,in_limitUser,in_N_Language,in_CategoryOfService,in_Arpu,func_getAdName(1),in_CTA,var_Advertiser_id,in_Mou,now(),in_CTA_value);
if( in_Operator is null or in_Operator=''or in_Mou is null  or in_Circle is null or in_Circle='' or in_N_Language is null or in_N_Language ='') then
set out_status=-62;
SET OUT_MSG="Invalid Data";
else 
if(cnt=0)then	
insert into tbl_campaign(Name,Type,Description,Start_Date,End_Date,Total_Budget,Daily_Budget,Bidding,Age,
Gender,Msisdn,Operator,Circle,AON,Slot,limitUser,N_Language,CategoryOfService,Arpu,Status_ad,CTA_Flag,advertiser_id,MOU,CTA_Value) 
values(in_Name,in_Type,in_Description,date(in_Start_Date),
date(in_End_Date),in_Total_Budget,in_Daily_Budget,in_Bidding,in_Age,varGender,in_Msisdn,
in_Operator,in_Circle,in_AON,in_Slot,in_limitUser,in_N_Language,in_CategoryOfService,in_Arpu,func_getAdName(0),in_CTA,var_Advertiser_id,in_Mou,in_CTA_value);
set out_status=62;               
SET OUT_MSG='Successfully inserted';
else 
set out_status=-63;
SET OUT_MSG='campaign name allready exist';
end if;		
end if;
else 
set out_status=-63;
SET OUT_MSG='campaign name allready exist.';
end if;		
else 
SET OUT_MSG='Advertiser not exist';
end if;
Commit;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_sub_advertiser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_sub_advertiser`(
IN IN_User_Name varchar(100),
IN IN_password varchar(50),
IN IN_DOB Date,
IN IN_Mbph bigint(12),
IN IN_Gender char(6),
IN IN_city varchar(50),
IN IN_country varchar(50),
IN IN_Company_name  varchar(50) ,
IN IN_Company_Desc varchar(200),
IN IN_Company_Address varchar(50),
IN IN_email varchar(100),
IN super_email varchar(100),
OUT OUT_MSG varchar(100),
OUT OUT_STATUS int,
out out_Verify_Status int(5),
out out_Verify_code varchar(100))
BEGIN
declare cnt integer(5);
declare ct integer(5);
declare Ouid int;
declare SuperAid int;
set OUT_STATUS=-9;
SET OUT_MSG="ERROR";
if( IN_User_name is null or IN_User_name=''or IN_password is null or IN_password ='')
then
	set OUT_STATUS=-2;
	SET OUT_MSG="Invalid Data";
	set out_Verify_Status  =0;
	set out_Verify_code  ='NA';
else
	select count(*) into cnt from mob_advertisement.tbl_Advertiser_Details where email=IN_email;
	select count(*) into ct from mob_advertisement.tbl_Login where User_name=IN_email;
	set out_Verify_code  =uuid();
	set out_Verify_Status  =0;
	if(ct=0) Then
	if(cnt=0) Then
		insert into mob_advertisement.tbl_Login(User_name,Password,LDate,Status,RoleType)VALUES (IN_email, IN_Password, date(now()),1,5);
		select Uid into Ouid from mob_advertisement.tbl_Login where User_name=IN_email;
		
		select Aid into SuperAid from mob_advertisement.tbl_Advertiser_Details where email=super_email;
		insert into mob_advertisement.tbl_Advertiser_Details(Aid,User_name,Password,DateofBirth,Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Verify_Status,Verify_code,Verify_expiry_date,country,Super_Aid)
		VALUES(Ouid,IN_User_name, IN_Password, IN_DOB,IN_Mbph,IN_Gender,IN_city,IN_Company_name,IN_Company_Desc,IN_Company_Address,IN_email,2,out_Verify_code,date(now()+interval 3 day),IN_country,SuperAid);
		set OUT_MSG ="Successfully Registered ";
		SET OUT_STATUS=1;
		
	else
		set OUT_STATUS =-1;
		SET OUT_MSG="Registered Alreday.";
		set out_Verify_Status  =0;
		set out_Verify_code  ='NA';
	end if;
	else 
		set OUT_STATUS =-1;
		SET OUT_MSG="Registered Alreday";
		set out_Verify_Status  =0;
		set out_Verify_code  ='NA';
	end if;	
end if;
Commit;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_sub_checklogin1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_sub_checklogin1`(IN IN_User_Name varchar(50),
IN IN_password varchar(50),
OUT OUT_STATUS varchar(10),
OUT OUT_Msg varchar(100),
out out_User_name varchar(50),
out out_DateofBirth date,
out out_Mbphone bigint(15),
out out_Gender char(6),
out out_city varchar(50),
out out_Company_name varchar(100),
out out_Company_Desc varchar(100),
out out_Company_Address varchar(100),
out out_email varchar(50),
out out_Name varchar(50),
out out_Verify_Status int(11),
out out_Verify_code varchar(100),
out out_country varchar(50),
out out_RoleType int,
out out_Aid mediumint,
out out_SuperAid int)
BEGIN
Declare cnt integer(5);
declare vcnt integer(5);
declare vstatus varchar(10);
declare vExpiry date;
declare  roltype int;
Set OUT_STATUS=-19;
	set OUT_STATUS =-11;
	set OUT_Msg="Logined not successful";
	set out_User_name='NA';
	set out_DateofBirth='NULL';
	set out_Mbphone='NA';
	set out_Gender='NA';
	set out_city='NA';
	set out_Company_name='NA';
	set out_Company_Desc='NA';
	set out_Company_Address='NA';
	set out_email='NA';
	set out_Name='NA';
	set out_Verify_Status=0;
	set out_Verify_code='NA';
	set out_country='NA';
        set out_RoleType=0;
        set out_Aid=0;
select count(*) into cnt from mob_advertisement.tbl_Login where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
if(cnt = 0) Then
	select count(*) into vcnt from mob_advertisement.tbl_Login where binary User_Name=trim(IN_User_Name);
	if(vcnt=0)then
		set OUT_STATUS =-13;
		set OUT_Msg="username is incorrect";
	else
		
		
			set OUT_STATUS =-15;
			set OUT_Msg="password is incorrect";
		
	end if;
else
	select RoleType into roltype from mob_advertisement.tbl_Login where User_name=IN_User_Name;
	set out_RoleType=roltype;
	
	if(roltype=5) then
		select Verify_Status,Verify_expiry_date into vstatus,vExpiry from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
	
			set OUT_STATUS =11;
			set OUT_Msg="verification done and Logined  successful";
			update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
			
			select  ifnull( Super_Aid,0)into out_SuperAid from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
			if(out_SuperAid=0)then
				set OUT_STATUS =15;
				set OUT_Msg="IS a Advertiser only";
			else
			select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
			into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
			out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
			
			end if;
	elseif(roltype=2)then
		select Verify_Status,Verify_expiry_date into vstatus,vExpiry from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
	
		if(vstatus=1) then
			set OUT_STATUS =-14;
			set OUT_Msg="Pending for Admin Approval";
		elseif(vstatus=2) then
			set OUT_STATUS =11;
			set OUT_Msg="verification done and Logined  successful";
			update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
			select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
			into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
			out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
		else 
			if(vExpiry<date(now()))
			then
				set OUT_STATUS =-16;
				set OUT_Msg="Verification Expired";
			else
				set OUT_STATUS =-12;
				select Verify_code into out_Verify_code from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
				set OUT_Msg="not verified and not Logined  successful";
			end if;	
		end if;
elseif(roltype=1)then
		select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
		into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
		out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
                set OUT_STATUS =11;
	set OUT_Msg="Admin Logined successful";
	elseif(roltype=3)then
		select A.Status ,A.RoleType,Name,Type,Description,date(Start_Date),
		date(End_Date),Msisdn,Operator,Service,
		Circle,Status_ad,CTA_Flag from mob_advertisement.tbl_Publisher tb
		left outer join 
		mob_advertisement.tbl_Login A on A.User_name=tb.User_name
		where A.User_name=IN_User_Name and tb.User_name=IN_User_Name;
		update mob_advertisement.tbl_Login set Status=2 where User_name=IN_User_Name;
                select pub_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_Publisher where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
               elseif(roltype=4)then   	
		select Admin_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_admin_view where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
	else
		set OUT_STATUS =11;
		set OUT_Msg="verification done and Logined  successful";
		update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
	end if;
      
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_sub_checklogin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_sub_checklogin`(IN IN_User_Name varchar(50),
IN IN_password varchar(50),
OUT OUT_STATUS varchar(10),
OUT OUT_Msg varchar(100),
out out_User_name varchar(50),
out out_DateofBirth date,
out out_Mbphone bigint(15),
out out_Gender char(6),
out out_city varchar(50),
out out_Company_name varchar(100),
out out_Company_Desc varchar(100),
out out_Company_Address varchar(100),
out out_email varchar(50),
out out_Name varchar(50),
out out_Verify_Status int(11),
out out_Verify_code varchar(100),
out out_country varchar(50),
out out_RoleType int,
out out_Aid mediumint,
out out_SuperAid int)
BEGIN
Declare cnt integer(5);
Declare cnt2 integer(5);
declare vcnt integer(5);
declare vstatus varchar(10);
declare vExpiry date;
declare  roltype int;
Declare cnt1 integer(5);
declare subrole int;
Set OUT_STATUS=-19;
	set OUT_STATUS =-11;
	set OUT_Msg="Logined not successful";
	set out_User_name='NA';
	set out_DateofBirth='NULL';
	set out_Mbphone='NA';
	set out_Gender='NA';
	set out_city='NA';
	set out_Company_name='NA';
	set out_Company_Desc='NA';
	set out_Company_Address='NA';
	set out_email='NA';
	set out_Name='NA';
	set out_Verify_Status=0;
	set out_Verify_code='NA';
	set out_country='NA';
        set out_RoleType=0;
        set out_Aid=0;
select count(*) into cnt from mob_advertisement.tbl_Login where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
if(cnt = 0) Then
   select count(*) into cnt2 from mob_advertisement.tbl_login_view where User_name=IN_User_Name;
  if(cnt2>0)Then
	select RoleType into roltype from mob_advertisement.tbl_login_view where User_name=IN_User_Name;	
	 if(roltype=6) then
		select count(*) into cnt from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
		if(cnt = 1)then
		       select Uid,User_name,RoleType,Sub_Role,code into out_Aid,out_email,out_RoleType,subrole,out_SuperAid from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
		      set OUT_STATUS=11;
		         set OUT_Msg="Logined  successful";
	           else
		        set OUT_STATUS =-12;
		          set OUT_Msg="not verified and not Logined  successful";
	           end if;	
	elseif(roltype=7)then
		select count(*) into cnt1 from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
select cnt1;
		if(cnt1=1)then
			select Uid,User_name,RoleType,Sub_Role,code into out_Aid,out_email,out_RoleType,subrole,out_SuperAid from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
				set OUT_STATUS=11;
			set OUT_Msg="Logined  successful";
		else
			set OUT_STATUS =-12;
			set OUT_Msg="not verified and not Logined  successful";
		end if;
	end if;
	else
		select count(*) into vcnt from mob_advertisement.tbl_Login where binary User_Name=trim(IN_User_Name);
		if(vcnt=0)then
			set OUT_STATUS =-13;
			set OUT_Msg="username is incorrect";
		else
			
			
				set OUT_STATUS =-15;
				set OUT_Msg="password is incorrect";
			
		end if;
end if;
else
	select RoleType into roltype from mob_advertisement.tbl_Login where User_name=IN_User_Name;
	set out_RoleType=roltype;
	
	if(roltype=5) then
		select Verify_Status,Verify_expiry_date into vstatus,vExpiry from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
	
			set OUT_STATUS =11;
			set OUT_Msg="verification done and Logined  successful";
			update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
			
			select  ifnull( Super_Aid,0)into out_SuperAid from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
			if(out_SuperAid=0)then
				set OUT_STATUS =15;
				set OUT_Msg="IS a Advertiser only";
			else
			select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
			into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
			out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
			
			end if;
	elseif(roltype=2)then
		select Verify_Status,Verify_expiry_date into vstatus,vExpiry from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
	
		if(vstatus=1) then
			set OUT_STATUS =-14;
			set OUT_Msg="Pending for Admin Approval";
		elseif(vstatus=2) then
			set OUT_STATUS =11;
			set OUT_Msg="verification done and Logined  successful";
			update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
			select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
			into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
			out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
		else 
			if(vExpiry<date(now()))
			then
				set OUT_STATUS =-16;
				set OUT_Msg="Verification Expired";
			else
				set OUT_STATUS =-12;
				select Verify_code into out_Verify_code from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
				set OUT_Msg="not verified and not Logined  successful";
			end if;	
		end if;
elseif(roltype=1)then
		select Aid,User_name,date(DateofBirth),Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
		into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
		out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country	from mob_advertisement.tbl_Advertiser_Details where binary email=IN_User_Name and binary Password=IN_password ;
                set OUT_STATUS =11;
	set OUT_Msg="Admin Logined successful";
	elseif(roltype=3)then
		select A.Status ,A.RoleType,Name,Type,Description,date(Start_Date),
		date(End_Date),Msisdn,Operator,Service,
		Circle,Status_ad,CTA_Flag from mob_advertisement.tbl_Publisher tb
		left outer join 
		mob_advertisement.tbl_Login A on A.User_name=tb.User_name
		where A.User_name=IN_User_Name and tb.User_name=IN_User_Name;
		update mob_advertisement.tbl_Login set Status=2 where User_name=IN_User_Name;
                select pub_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_Publisher where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
               elseif(roltype=4)then   	
		select Admin_id,Name,Msisdn,User_name
		into out_Aid,out_User_name ,out_Mbphone  ,out_email
		from mob_advertisement.tbl_admin_view where binary User_name=IN_User_Name;
                
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
	else
		set OUT_STATUS =11;
		set OUT_Msg="verification done and Logined  successful";
		update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;
	end if;
      
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_toMem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_toMem`()
BEGIN
truncate  tbl_memcache_camp_data;
	truncate  tbl_memcache_camp_data_log;
	insert  into tbl_memcache_camp_data(mem_startDate,mem_uploadDate,mem_status,
	camp_id,name,type,
	description,start_date,end_date,total_budget,daily_budget 
	,bidding,age,gender ,msisdn ,operator ,service ,circle	
	,aon,slot,limituser,n_language,categoryofservice
	,arpu,status_ad,cta_flag,advertiser_id,
	mou,used_budget,cta_value,type_value)
	select now(),null,0,Camp_id,Name,Type,
	Description,Start_Date,End_Date,Total_Budget,Daily_Budget 
	,Bidding,Age,Gender ,Msisdn ,Operator ,Service ,Circle	
	,AON,Slot,limitUser,N_Language,CategoryOfService
	,Arpu,Status_ad,CTA_Flag,advertiser_id,
	MOU,Used_Budget,CTA_Value,Type_value from tbl_campaign;
	
	
	insert  into tbl_memcache_camp_data_log(mem_startDate,mem_uploadDate,mem_status,
	camp_id,name,type,
	description,start_date,end_date,total_budget,daily_budget 
	,bidding,age,gender ,msisdn ,operator ,service ,circle	
	,aon,slot,limituser,n_language,categoryofservice
	,arpu,status_ad,cta_flag,advertiser_id,
	mou,used_budget,cta_value,type_value)
	select now(),null,0,Camp_id,Name,Type,
	Description,Start_Date,End_Date,Total_Budget,Daily_Budget 
	,Bidding,Age,Gender ,Msisdn ,Operator ,Service ,Circle	
	,AON,Slot,limitUser,N_Language,CategoryOfService
	,Arpu,Status_ad,CTA_Flag,advertiser_id,
	MOU,Used_Budget,CTA_Value,Type_value from tbl_campaign;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_update_campaign`(
	IN in_Cid int,
	IN in_Advertiser_email varchar(50),
	IN in_Name varchar(50),
	IN in_Type int,
	IN in_Description varchar(500),
	IN in_Start_Date Date,
	IN in_End_Date Date,
	IN in_Total_Budget float,
	IN in_Daily_Budget float,
	IN in_Bidding float,
	IN in_Age int,
	IN in_Gender char,
	IN in_Msisdn bigint(15),
	IN in_Operator int, 
	IN in_Mou int,
	IN in_Circle int,
	IN in_AON int,
	IN in_Slot int,
	IN in_limitUser int, 
	IN in_N_Language int,
	IN in_CategoryOfService int,
	IN in_Arpu float,
	IN in_CTA int,
	IN in_CTA_value varchar(200),
	out out_status int,
	out OUT_MSG varchar(50)
)
BEGIN
	declare varGender integer(5);
	declare cnt integer(5); 
	declare var_Advertiser_id int;
	declare ctaflag int;
        declare ctavalue varchar(200);
	set out_status=-99;
	SET OUT_MSG="Error";
	select Aid into var_Advertiser_id from mob_advertisement.tbl_Advertiser_Details where email=in_Advertiser_email limit 1;
	if(in_Gender in ('F','f')) then
		set varGender=1;
	elseif(in_Gender in ('M','m')) then
		set varGender=2;
	elseif(in_Gender in ('A','a')) then
		set varGender=3;
	else
		set varGender=-1;
	end if;
	select count(*) into cnt from mob_advertisement.tbl_campaign where advertiser_id=var_Advertiser_id and Camp_id=in_Cid;
	                       
	insert into mob_advertisement.tbl_campaign_log(Name,Type,Description,Start_Date,End_Date,Total_Budget,Daily_Budget,Bidding,Age,Gender,Msisdn,Operator,Circle,AON,Slot,limitUser,N_Language,CategoryOfService,Arpu,Status_ad,CTA_Flag,advertiser_id,MOU,log_date,CTA_Value) 
	values(in_Name,in_Type,in_Description,date(in_Start_Date),date(in_End_Date),in_Total_Budget,in_Daily_Budget,in_Bidding,in_Age,varGender,in_Msisdn,
	in_Operator,in_Circle,in_AON,in_Slot,in_limitUser,in_N_Language,in_CategoryOfService,in_Arpu,func_getAdName(1),in_CTA,var_Advertiser_id,in_Mou,now(),in_CTA_value);
	if( in_Operator is null or in_Operator=''or in_Mou is null  or in_Circle is null or in_Circle='' or in_N_Language is null or in_N_Language ='') then
		set out_status=-62;
		SET OUT_MSG="Invalid Data";
	else 
		if(cnt>0)then	
			update mob_advertisement.tbl_campaign set Name=in_Name,Type=in_Type,Description=in_Description,Start_Date=date(in_Start_Date),
			End_Date=date(in_End_Date),Daily_Budget=in_Daily_Budget,Bidding=in_Bidding,Age=in_Age,
			Gender=varGender,Msisdn=in_Msisdn,Operator=in_Operator,Circle=in_Circle,AON=in_AON,Slot=in_Slot,limitUser=in_limitUser,
			N_Language=in_N_Language,CategoryOfService=in_CategoryOfService,Arpu=in_Arpu,Status_ad=func_getAdName(5),CTA_Flag=in_CTA,MOU=in_Mou ,CTA_Value=in_CTA_value
			where advertiser_id=var_Advertiser_id and Camp_id=in_Cid;
			set out_status=63;               
			SET OUT_MSG='Successful Update';
			
			Set ctaflag=in_CTA;
			set ctavalue=in_CTA_value;
			select ctaflag,ctavalue;
			
		else 
			set out_status=-64;
			SET OUT_MSG='Invalid Campain ID';
		end if;		
	end if;
	Commit;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_updte_camp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_updte_camp`(
IN in_Cid int,
	IN in_Advertiser_email varchar(50),
	IN in_Name varchar(50),
	IN in_Type int,
	IN in_Description varchar(500),
	IN in_Start_Date Date,
	IN in_End_Date Date,
	IN in_Total_Budget float,
	IN in_Daily_Budget float,
	IN in_Bidding float,
	IN in_Age int,
	IN in_Gender char,
	IN in_Msisdn bigint(15),
	IN in_Operator int, 
	IN in_Mou int,
	IN in_Circle int,
	IN in_AON int,
	IN in_Slot int,
	IN in_limitUser int, 
	IN in_N_Language int,
	IN in_CategoryOfService int,
	IN in_Arpu float,
	IN in_CTA int,
	IN in_CTA_value varchar(200),
        IN in_Type_value varchar(500),
	out out_status int,
	out OUT_MSG varchar(50)
)
BEGIN
declare varGender integer(5);
	declare cnt integer(5); 
	declare var_Advertiser_id int;
	declare ctaflag int;
        declare ctavalue varchar(200);
	set out_status=-99;
	SET OUT_MSG="Error";
	select Aid into var_Advertiser_id from mob_advertisement.tbl_Advertiser_Details where email=in_Advertiser_email limit 1;
	if(in_Gender in ('F','f')) then
		set varGender=1;
	elseif(in_Gender in ('M','m')) then
		set varGender=2;
	elseif(in_Gender in ('A','a')) then
		set varGender=3;
	else
		set varGender=-1;
	end if;
	select count(*) into cnt from mob_advertisement.tbl_campaign where advertiser_id=var_Advertiser_id and Camp_id=in_Cid;
	                       
	insert into mob_advertisement.tbl_campaign_log(Name,Type,Description,Start_Date,End_Date,Total_Budget,Daily_Budget,Bidding,Age,Gender,Msisdn,Operator,Circle,AON,Slot,limitUser,N_Language,CategoryOfService,Arpu,Status_ad,CTA_Flag,advertiser_id,MOU,log_date,CTA_Value,Type_value) 
	values(in_Name,in_Type,in_Description,date(in_Start_Date),date(in_End_Date),in_Total_Budget,in_Daily_Budget,in_Bidding,in_Age,varGender,in_Msisdn,
	in_Operator,in_Circle,in_AON,in_Slot,in_limitUser,in_N_Language,in_CategoryOfService,in_Arpu,func_getAdName(1),in_CTA,var_Advertiser_id,in_Mou,now(),in_CTA_value,in_Type_value);
	if( in_Operator is null or in_Operator=''or in_Mou is null  or in_Circle is null or in_Circle='' or in_N_Language is null or in_N_Language ='') then
		set out_status=-62;
		SET OUT_MSG="Invalid Data";
	else 
		if(cnt>0)then	
			update mob_advertisement.tbl_campaign set Name=in_Name,Type=in_Type,Description=in_Description,Start_Date=date(in_Start_Date),
			End_Date=date(in_End_Date),Daily_Budget=in_Daily_Budget,Bidding=in_Bidding,Age=in_Age,
			Gender=varGender,Msisdn=in_Msisdn,Operator=in_Operator,Circle=in_Circle,AON=in_AON,Slot=in_Slot,limitUser=in_limitUser,
			N_Language=in_N_Language,CategoryOfService=in_CategoryOfService,Arpu=in_Arpu,Status_ad=func_getAdName(5),CTA_Flag=in_CTA,MOU=in_Mou ,CTA_Value=in_CTA_value,Type_value=in_Type_value
			where advertiser_id=var_Advertiser_id and Camp_id=in_Cid;
			set out_status=63;               
			SET OUT_MSG='Successful Update';
			
			Set ctaflag=in_CTA;
			set ctavalue=in_CTA_value;
			select ctaflag,ctavalue;
			
		else 
			set out_status=-64;
			SET OUT_MSG='Invalid Campain ID';
		end if;		
	end if;
	Commit;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_upload_toMem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_upload_toMem`()
BEGIN
		
	truncate  tbl_memcache_camp_data;
	truncate  tbl_memcache_camp_data_log;
	insert  into tbl_memcache_camp_data(start_date,upload_date,cstatus,
	mem_status,cdata)
	
	select now(),null,status_ad,0,concat(Camp_id ,'#',Name ,'#',Type,'#',Description ,'#',
	Total_Budget ,'#',Daily_Budget ,'#',Bidding ,'#',Age ,'#',
	Gender ,'#',Msisdn ,'#',Operator ,'#',Service ,'#',Circle ,'#',AON ,'#',Slot ,'#',limitUser ,'#',N_Language ,'#',CategoryOfService ,'#',Arpu ,'#',Status_ad ,'#',CTA_Flag ,'#',advertiser_id ,'#',MOU ,'#')
	from tbl_campaign ;
	
	
	
	
	insert  into tbl_memcache_camp_data_log(start_date,upload_date,cstatus,
	mem_status,cdata)
	select now(),null,cStatus,0,
	concat(cid,'#',cname,'#',ctype,'#',cdesc,'#',tBudget,'#',dBudget,'#',cBidding,'#',cAge,'#',cGen,'#',cANI,'#',cOp,'#',cSr,'#',cCir,'#',
	cAon,'#',cSlot,'#',cLimitUser,'#',cLang,'#',cCOS,'#',cArpu,'#',cStatus,'#',cCTA,'#',cAID,'#',cMou 
	) Advtdata from
	(select Camp_id cid,Name cname,Type ctype,Description cdesc,
	Total_Budget tBudget,Daily_Budget dBudget,Bidding cBidding,Age cAge,
	Gender cGen,Msisdn cANI,Operator cOp,Service cSr,Circle cCir,AON cAon,Slot cSlot,limitUser cLimitUser,N_Language cLang,CategoryOfService cCOS,Arpu cArpu,Status_ad cStatus,CTA_Flag cCTA,advertiser_id cAID,MOU cMou 
	from tbl_campaign order by status_ad=4,status_ad=0,status_ad=3,status_ad=2,status_ad=1) as A;
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Proc_verification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `Proc_verification`(
   IN IN_Verify_code varchar(50),
out OUT_STATUs int,
OUT OUT_Msg varchar(200),
 out out_User_name varchar(100),
out out_DateofBirth date,
out out_Mbphone char(20),
out out_Gender char(6),
out out_city varchar(50),
out out_Company_name varchar(100),
out out_Company_Desc varchar(50),
out out_Company_Address varchar(50),
out out_email varchar(100),
out out_Name varchar(30),
out out_Verify_Status int(10),
out out_Verify_code varchar(50),
out out_country varchar(40),
out out_Aid mediumint,
out out_RoleType int
)
BEGIN
Declare expdate date;
Declare vercode varchar(50);
Declare e_mail varchar(100);
declare new_vercode varchar(50);
declare  roltype int;
declare out_username varchar(50);
declare out_eemail varchar(100);
declare ct int;
SELECT Verify_expiry_date, Verify_code into expdate, vercode from mob_advertisement.tbl_Advertiser_Details Where  binary Verify_code=IN_Verify_code ;
        set out_User_name='NA';
	set out_DateofBirth='NA';
	set out_Mbphone='NA';
	set out_Gender='NA';
	set out_city='NA';
	set out_Company_name='NA';
	set out_Company_Desc='NA';
	set out_Company_Address='NA';
	set out_email='NA';
	set out_Name='NA';
	set out_Verify_Status=0;
	set out_Verify_code='NA';
	set out_country='NA';
set out_Aid=0;
   set out_RoleType=0;
if(expdate is NULL && vercode is NULL)Then
	SET OUT_STATUs=-21;
	set OUT_MSG ="Code is not valid";
	
elseif(vercode != IN_Verify_code)Then
	SET OUT_STATUs=-27;
	set OUT_MSG ="Code is not valid";
	
elseif(expdate < date(now()))Then
	SET OUT_STATUs=-29;
	set OUT_MSG ="Fail due to Code Expired";
	select email into e_mail from mob_advertisement.tbl_Advertiser_Details where binary Verify_code=IN_Verify_code ;
        set new_vercode=UUID();
	update mob_advertisement.tbl_Advertiser_Details set Verify_code=new_vercode,Verify_expiry_date= (CURDATE()+1) where binary  email=e_mail ;
        select e_mail,new_vercode into out_email, out_Verify_code;
	elseif(vercode =IN_Verify_code && expdate>=date(now())) Then
	
	select email into out_username from mob_advertisement.tbl_Advertiser_Details where binary Verify_code=IN_Verify_code ;
	set out_eemail=out_username;	
	
	
		SET OUT_STATUs=21;
		set OUT_MSG ="Success";
		update mob_advertisement.tbl_Advertiser_Details set Verify_Status=1  where binary Verify_code=IN_Verify_code ;
		
		update tbl_Login set Status=1 where User_name=out_eemail;
		select Aid,User_name,DateofBirth,Mbphone,Gender,city,Company_name,Company_Desc,Company_Address,email,Name,Verify_Status,Verify_code,country
		into out_Aid,out_User_name,out_DateofBirth ,out_Mbphone ,out_Gender,out_city ,out_Company_name ,out_Company_Desc,
		out_Company_Address,out_email,out_Name,out_Verify_Status,out_Verify_code,out_country
		from mob_advertisement.tbl_Advertiser_Details where binary Verify_code=IN_Verify_code ;
			
		select RoleType into roltype  from mob_advertisement.tbl_Login where User_name=out_email;
		set out_RoleType=roltype;
	
else
	set OUT_MSG="ERROR";
	SET OUT_STATUs=-22;
	
end if;
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Proc_Verifydone` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `Proc_Verifydone`(
 
  IN IN_Verify_code varchar(50),
out out_Aid mediumint,
  OUT OUT_STATUS int,
  out out_verify varchar(30),
  OUT OUT_MSG varchar(50),
out out_RoleType int
)
BEGIN
declare
verify integer;
declare  roltype int;
declare  OAid int;
SELECT COUNT(*) into verify from mob_advertisement.tbl_Advertiser_Details Where  Verify_code=IN_Verify_code ;
if(verify=0)Then
	set OUT_STATUS=-31;
	Set OUT_MSG="Not Verfied";
	  set out_verify='NA';
set out_Aid=0;
set out_RoleType=0;
else
	set OUT_STATUS=31;
	Set OUT_MSG="Verification done";
	update mob_advertisement.tbl_Advertiser_Details set Verify_Status=1 where Verify_code=IN_Verify_code ;
	
update mob_advertisement.tbl_Login set Status=1 where User_name=IN_User_Name;set out_verify=IN_Verify_code;
 select RoleType into roltype from mob_advertisement.tbl_Login where User_name=IN_User_Name;
select Aid into OAid from mob_advertisement.tbl_Advertiser_Details where email=IN_User_Name;
                        set out_RoleType=roltype;
set out_Aid=OAid;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `proc_view`(IN IN_User_Name varchar(50),
IN IN_password varchar(50),OUT OUT_STATUS varchar(10),
OUT OUT_Msg varchar(100))
BEGIN
Declare cnt integer(5);
Declare cnt1 integer(5);
declare  roltype int;
declare subrole int;
select RoleType into roltype from mob_advertisement.tbl_login_view where User_name=IN_User_Name;
if(roltype=6) then
	select count(*) into cnt from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
select cnt;	
if(cnt = 1)then
		select Sub_Role into subrole from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
		set OUT_STATUS=11;
		set OUT_Msg="Logined  successful";
	else
		set OUT_STATUS =-12;
		set OUT_Msg="not verified and not Logined  successful";
	end if;	
		elseif(roltype=7)then
		select count(*) into cnt1 from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
		if(cnt1 = 1)then
			select Sub_Role into subrole from mob_advertisement.tbl_login_view where binary trim(User_Name)=trim(IN_User_Name) and binary trim(Password)=trim(IN_password);
				set OUT_STATUS=11;
			set OUT_Msg="Logined  successful";
		else
			set OUT_STATUS =-12;
			set OUT_Msg="not verified and not Logined  successful";
		end if;
end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pro_insert_User_ActualData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`%`*/ /*!50003 PROCEDURE `pro_insert_User_ActualData`(
	IN in_Misdin bigint(15),
	IN in_Operator varchar(50),
	IN in_Service varchar(50),
	IN in_Circle varchar(50),
	IN In_Aon Date,
	IN In_Sub_Date  Date,
	IN IN_Net_rev int,
	IN IN_Avg_rev int,
	IN in_mou int,
	IN in_N_Language  varchar(50) ,
	IN IN_Type int,
	IN IN_Ani_Status varchar(20),
	out out_status int,
	out OUT_MSG varchar(50))
BEGIN
Declare operator integer(5);
Declare Service integer(5);
Declare Circle integer(5);
Declare lang integer(5);
Declare Ani_status integer;
select Operator_Code into operator   from tbl_Operator_Details where Operator_Name=in_Operator;
select Service_Code into Service  from tbl_Services_Details where Service_Type=in_Service;
select Circle_Code into Circle from tbl_Circle_Details where Circle_Name=in_Circle;
select Language_Code into lang from tbl_Language_Details where Language_Name=in_N_Language;
select Ani_code into Ani_status from tbl_Ani_status_Details where Ani_Status=in_N_Language;
	                       
if( in_Operator is null or in_Operator=''or in_Service is null or in_Service ='' or in_Circle is null or in_Circle='' or in_N_Language is null or in_N_Language ='') then
set out_status=-42;
SET OUT_MSG="Invalid Data";
else 
 insert into tbl_User_ActualData(msisdn,Operator,Service,Circle,AON,Sub_Date,net_rev,avg_rev,MOU,N_language,Type_of_Service,Ani_Status,id,gender)
 values(in_Misdin,operator,Service,Circle,In_Aon ,In_Sub_Date,IN_Net_rev,IN_Avg_rev,in_mou,lang ,IN_Type,Ani_status);
set out_status=42;
SET OUT_MSG="Successfully inserted";
         end if;
Commit;  
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pro_insert_User_RawlData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`172.17.15.231`*/ /*!50003 PROCEDURE `pro_insert_User_RawlData`(
	IN in_Misdin bigint(15),
	IN in_Operator varchar(50),
	IN in_Service varchar(50),
	IN in_Circle varchar(50),
	IN In_Aon Date,
	IN In_Sub_Date  Date,
	IN IN_Net_rev float,
	IN IN_Avg_rev float,
	IN in_mou int,
	IN in_N_Language  varchar(50) ,
	IN IN_Type int,
	IN IN_Ani_Status varchar(50),
	out out_status int,
	out OUT_MSG varchar(50))
BEGIN










	                       
if( in_Operator is null or in_Operator=''or in_Service is null or in_Service ='' or in_Circle is null or in_Circle='' or in_N_Language is null or in_N_Language ='') then
set out_status=-42;
SET OUT_MSG="Invalid Data";
else 
 insert into mob_advertisement.tbl_User_RawData(msisdn,operator,Service,Circle,AON,Sub_Date,net_revenue,avg_revenue,Mou,Native_Language,Type_of_service,Ani_Status)
 values(in_Misdin,in_Operator,in_Service,in_Circle,In_Aon ,In_Sub_Date,IN_Net_rev,IN_Avg_rev,in_mou,in_N_Language ,IN_Type,IN_Ani_Status);
set out_status=42;
SET OUT_MSG="Successfully inserted";
         end if;
Commit;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-31 15:45:18
