-- MySQL dump 10.14  Distrib 5.5.34-MariaDB, for Linux (i686)
--
-- Host: localhost    Database: obd_platform
-- ------------------------------------------------------
-- Server version	5.5.34-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_camp_id`
--

DROP TABLE IF EXISTS `tbl_camp_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_camp_id` (
  `camp_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_chaisse_server`
--

DROP TABLE IF EXISTS `tbl_chaisse_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_chaisse_server` (
  `chaisse_server` varchar(30) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `binary_limit` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_obd_campaign`
--

DROP TABLE IF EXISTS `tbl_obd_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_obd_campaign` (
  `camp_id` int(11) DEFAULT NULL,
  `camp_name` varchar(30) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_obd_queue`
--

DROP TABLE IF EXISTS `tbl_obd_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_obd_queue` (
  `chaisse_server` varchar(30) DEFAULT NULL,
  `current_chaisse_queue` int(11) DEFAULT NULL,
  `pre_running_binary` int(11) DEFAULT NULL,
  `queue_status` int(11) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_obd_system`
--

DROP TABLE IF EXISTS `tbl_obd_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_obd_system` (
  `start_date` datetime DEFAULT NULL,
  `chaisse_server` varchar(30) DEFAULT NULL,
  `running_scripts` varchar(30) DEFAULT NULL,
  `campID` int(11) DEFAULT NULL,
  `used_chnnl_capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_res_unicode_details`
--

DROP TABLE IF EXISTS `tbl_res_unicode_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_res_unicode_details` (
  `res_code` varchar(50) DEFAULT NULL,
  `upload_fileName` varchar(50) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_running_binary`
--

DROP TABLE IF EXISTS `tbl_running_binary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_running_binary` (
  `chaisse_server` varchar(30) DEFAULT NULL,
  `used_capacity` int(11) DEFAULT NULL,
  `running_binary` varchar(30) DEFAULT NULL,
  `available_binary_status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_unicode`
--

DROP TABLE IF EXISTS `tbl_unicode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_unicode` (
  `code` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'obd_platform'
--
/*!50003 DROP PROCEDURE IF EXISTS `proc_check_unique_campName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_check_unique_campName`(in in_camp_name varchar(50),out out_str int)
BEGIN
declare cnt int;
set out_str=-1;
select count(*) into cnt from  tbl_obd_campaign where camp_name=in_camp_name;
if(cnt=0)then
set out_str=0;
else
set out_str=cnt;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_getCamp_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_getCamp_id`(in campName varchar(50),out out_str int)
BEGIN
declare cid int;
declare ccid int;
declare cnt int;
set out_str=-1;
select camp_id into cid from tbl_camp_id;
if(cid>0)then
	select camp_id into ccid from tbl_obd_campaign where camp_name=campName;
	if(ccid >0)then
		set out_str=ccid;
	else
		insert into tbl_obd_campaign(camp_id,camp_name,start_date)values(cid,campName,now());
		set out_str=cid;
		update tbl_camp_id set camp_id=camp_id+1;
	end if;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_getUnicode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_getUnicode`(out out_unicode int)
BEGIN
declare unicode int;
set out_unicode=-1;
select code into unicode from tbl_unicode; 
if(unicode>0)then
set out_unicode=unicode;
update tbl_unicode set code=code+1; 
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_cdrCamp_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_get_cdrCamp_id`(in campName varchar(50),out out_str int)
BEGIN
declare cid int;
set out_str=-1;
select camp_id into cid from  tbl_obd_campaign where  camp_name=campName limit 1;
if(cid>0)then
set out_str=cid;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_queue_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_queue_status`(in serverID int,out in_out int)
BEGIN
select current_chaisse_queue into in_out from tbl_obd_queue  where server_id=serverID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_uploadFile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_get_uploadFile`(in_res_code varchar(50),out out_str varchar(50))
BEGIN
declare fileName varchar(50);
set out_str='-1';
select upload_fileName into fileName from tbl_res_unicode_details where res_code=in_res_code;
set out_str=fileName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_obd_system` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_obd_system`(in in_campID int,in in_total_chnnl int,
in in_running_scripts varchar(30),in in_chaisse_server varchar(30))
BEGIN
declare cnt int;	
select capacity into cnt from tbl_chaisse_server where chaisse_server=in_chaisse_server;
if(cnt>0)then
update tbl_chaisse_server set capacity=capacity-in_total_chnnl
where chaisse_server=in_chaisse_server;
update tbl_running_binary set used_capacity=used_capacity+in_total_chnnl
where chaisse_server=in_chaisse_server and running_binary=in_running_scripts and available_binary_status=1;
insert tbl_obd_system(start_date,campID,used_chnnl_capacity,running_scripts,chaisse_server)
values(now(),in_campID,in_total_chnnl,in_running_scripts,in_chaisse_server);
else
update tbl_obd_queue set queue_status=0 where chaisse_server=in_chaisse_server;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_reset_binary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_reset_binary`(in in_binary varchar(30),in in_server varchar(30))
BEGIN
update tbl_running_binary set available_binary_status=1 where running_binary=in_binary and chaisse_server=in_server
and available_binary_status=0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_res_unicode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_res_unicode`(in in_res_code varchar(50),in upload_file varchar(50))
BEGIN
insert into tbl_res_unicode_details(res_code,upload_fileName,start_date)values(in_res_code,upload_file,now()); 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_return_filename` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_return_filename`()
BEGIN
select camp_id camp_id,camp_name camp_name,date(start_date ) as date from tbl_obd_campaign where  date(start_date)=date(curdate()-1);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_ret_filename` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_ret_filename`()
BEGIN
set @tb=CONCAT('select concat(camp_id ,"_",camp_name,"_",(substring(replace(date(start_date),"-",""),3,8))) as file from tbl_obd_campaign where date(start_date)=date(now())');
PREPARE stmt FROM @tb;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_queue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_queue`(in INcampID int,in in_used_chnnl int ,in serverID int,in noOfchaseQueue int,out out_str int)
BEGIN
declare cnt int;
declare cnt1 int;
declare st int;
declare in_server varchar(20);
declare script_cnt int;
declare sid int;
declare serID int;
declare record varchar(70);
declare v_done int default 0;
declare cur cursor 
for select server_id serID from tbl_obd_queue where queue_status=1 order by server_id asc;
declare continue handler for not found set v_done = 1;
select count(server_id) into cnt from tbl_obd_queue where queue_status=1;
if (cnt > 0) then
set out_str =0;
open cur;
repeat
fetch cur into serID;
set sid =serID;
if(cnt=1)then
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=1  where server_id=serverID and queue_status=1;
select pre_running_binary,chaisse_server into script_cnt,in_server from tbl_obd_queue where current_chaisse_queue=1 and queue_status=1; 
select count(running_binary) into st from tbl_running_binary where available_binary_status=1 and chaisse_server=in_server and
running_binary=concat('B',script_cnt);
if(st=1)then
call proc_obd_system(INcampID,in_used_chnnl,concat('B',script_cnt),in_server);	
update	tbl_running_binary set 	available_binary_status=0 where chaisse_server=in_server and running_binary=concat('B',script_cnt);
set out_str =1;
else
select 'Error :available_binary_status=1#proc_update_queue';
set out_str =-1;
end if;
else if(cnt>1 && serverID=noOfchaseQueue)then							
select count(*) into cnt1 from tbl_obd_queue where current_chaisse_queue=1 and pre_running_binary=1;
if(cnt1=0)then
if(serverID>sid)then
select '#=#',sid;
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=sid and queue_status=1;
set out_str =0;
end if;
end if;	
else if(cnt>1 && serverID!=noOfchaseQueue)then
if(noOfchaseQueue>=(serverID))then
select count(*) into cnt1 from tbl_obd_queue where current_chaisse_queue=1 and pre_running_binary=1;
if(cnt1=0)then
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=1  where server_id=serverID+1 and queue_status=1;
select pre_running_binary,chaisse_server into script_cnt,in_server from tbl_obd_queue where current_chaisse_queue=1 and queue_status=1; 
select count(running_binary) into st from tbl_running_binary where available_binary_status=1 and chaisse_server=in_server and
running_binary=concat('B',script_cnt);
if(st=1)then
call proc_obd_system(INcampID,in_used_chnnl,concat('B',script_cnt),in_server);
update	tbl_running_binary set 	available_binary_status=0 where chaisse_server=in_server and running_binary=concat('B',script_cnt);
set out_str =1;
else
select 'Error :available_binary_status=1#proc_update_queue';
set out_str =-2;
end if;
else
set out_str =0;
end if;
end if;
end if;
end if;
end if;
until v_done=1 end repeat;
close cur;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_obd_queue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_obd_queue`(in INcampID int,in in_used_chnnl int,in in_server varchar(30),out out_cnt int)
BEGIN
declare noOfqueue int;
declare cntLimit int;
declare cntScript int;
declare in_chaisse_server varchar(20);
declare str varchar(20);
declare in_queue_status int;
declare sid int;
declare script_cnt int;
declare chaisse_id int;
declare cnt1 int;
declare st  int;
select count(chaisse_server) into noOfqueue from tbl_chaisse_server;
select count(running_binary) into cntScript from tbl_running_binary  where chaisse_server=in_server and available_binary_status=0;
select binary_limit into cntLimit from tbl_chaisse_server where chaisse_server=in_server;
select chaisse_server,queue_status,server_id
into in_chaisse_server,in_queue_status,sid
from tbl_obd_queue where  chaisse_server=in_server and current_chaisse_queue=1;
if(in_queue_status=0)then
update tbl_obd_queue set current_chaisse_queue=0  where current_chaisse_queue=1 and queue_status=0;
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=sid+1 and queue_status=1;
set out_cnt=0;
else
if(cntLimit>cntScript)then
select running_binary into str from tbl_running_binary where chaisse_server=in_server   and available_binary_status!=0
order by available_binary_status asc limit 1;
set cntScript=substr(str,2,3);
if(cntScript!=0)then
select available_binary_status into st from tbl_running_binary where chaisse_server=in_server and
running_binary=concat('B',cntScript);
select '**',st,cntScript;
if(st=0)then
select running_binary into str from tbl_running_binary where chaisse_server=in_server   and available_binary_status!=0
order by available_binary_status asc limit 1;
set cntScript=substr(str,2,3);
select available_binary_status into st from tbl_running_binary where chaisse_server=in_server and
running_binary=concat('B',cntScript);
select '=',st,cntScript;
end if;
else
set st=0;
end if;
select 	'cntScript',cntScript,st,in_chaisse_server,in_server;
if(st=0)then
update  tbl_obd_queue set pre_running_binary=pre_running_binary+1
where chaisse_server=in_chaisse_server and current_chaisse_queue=1 and queue_status=1 ;
select 'update+1 ',pre_running_binary from tbl_obd_queue
where chaisse_server=in_chaisse_server and current_chaisse_queue=1 and queue_status=1;
else
update  tbl_obd_queue set pre_running_binary=cntScript
where chaisse_server=in_chaisse_server and current_chaisse_queue=1 and queue_status=1;
end if;
select pre_running_binary into script_cnt from tbl_obd_queue where current_chaisse_queue=1 and queue_status=1 ;
if(cntLimit>=script_cnt>0)then
select count(running_binary) into st from tbl_running_binary where available_binary_status=1 and chaisse_server=in_server and
running_binary=concat('B',script_cnt);
select 'bfr Er',st,concat('B',script_cnt),in_server;
if(st=1)then
call proc_obd_system(INcampID,in_used_chnnl,concat('B',script_cnt),in_server);
update	tbl_running_binary set 	available_binary_status=0 where chaisse_server=in_server and running_binary=concat('B',script_cnt);
set out_cnt=script_cnt;
else
select 'Error :available_binary_status=1#proc_obd_queue';
set out_cnt=-1;
end if;
end if;
else
select server_id into chaisse_id from tbl_obd_queue where current_chaisse_queue=1 and queue_status=1;
update tbl_obd_queue set pre_running_binary=0  where server_id=chaisse_id and queue_status=1;
update tbl_obd_queue set current_chaisse_queue=0  where current_chaisse_queue=1 and queue_status=1;
if(noOfqueue>chaisse_id)then
select '2>',chaisse_id;
if(cntScript=cntLimit)then
select count(*) into cnt1 from tbl_obd_queue where  queue_status=1;
select 'cntScript=cntLimit',cnt1;
if(cnt1=1)then
update tbl_obd_queue set current_chaisse_queue=1,running_script=0  where server_id=chaisse_id and queue_status=1;
else
select  queue_status into st from tbl_obd_queue where server_id=chaisse_id+1;
if(st=0)then
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=chaisse_id-1 and queue_status=1;
else
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=chaisse_id+1 and queue_status=1;
end if;
end if;
set out_cnt=0;
end if;
else if(chaisse_id=noOfqueue)then
select '=',chaisse_id;
if(cntScript=cntLimit)then
select '--',chaisse_id,cntScript;
select count(*)into st from tbl_obd_queue where server_id=1 and queue_status=1;
if(st=1)then
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=1 and queue_status=1;
set out_cnt=0;
else
select 'call proc';
call proc_update_queue(INcampID,in_used_chnnl,sid,noOfqueue,@a);
set out_cnt=@a;
end if;
end if;
end if;
end if;
end if;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_obd_queue-bck` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `proc_obd_queue-bck`(in INcampID int,in in_used_chnnl int,in in_server varchar(30),out out_cnt int)
BEGIN
declare noOfqueue int;
declare cntLimit int;
declare cntScript int;
declare in_chaisse_server varchar(20);
declare str varchar(20);
declare in_queue_status int;
declare sid int;
declare script_cnt int;
declare chaisse_id int;
declare cnt1 int;
declare st  int;
select count(chaisse_server) into noOfqueue from tbl_chaisse_server;
select count(running_binary) into cntScript from tbl_running_binary  where chaisse_server=in_server and available_binary_status=0;	
select binary_limit into cntLimit from tbl_chaisse_server where chaisse_server=in_server;
select chaisse_server,queue_status,server_id
into in_chaisse_server,in_queue_status,sid
from tbl_obd_queue where  chaisse_server=in_server and current_chaisse_queue=1;	
if(in_queue_status=0)then
update tbl_obd_queue set current_chaisse_queue=0  where current_chaisse_queue=1 and queue_status=0;
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=sid+1 and queue_status=1;				
set out_cnt=0;
else
if(cntLimit>cntScript)then
if(cntScript!=0)then
select available_binary_status into st from tbl_running_binary where chaisse_server=in_server and
running_binary=concat('B',cntScript);
select '**',st,cntScript;
if(st=0)then
select running_binary into str from tbl_running_binary where chaisse_server=in_server   and available_binary_status!=0 
order by available_binary_status asc limit 1;
set cntScript=substr(str,2,3);
select available_binary_status into st from tbl_running_binary where chaisse_server=in_server and
running_binary=concat('B',cntScript);
select '=',st,cntScript;
end if;
else
set st=0;
end if;
select 	'cntScript',cntScript,st,in_chaisse_server,in_server;
if(st=0)then
update  tbl_obd_queue set pre_running_binary=pre_running_binary+1
where chaisse_server=in_chaisse_server and current_chaisse_queue=1 and queue_status=1;
select 'update+1 ',pre_running_binary from tbl_obd_queue 
where chaisse_server=in_chaisse_server and current_chaisse_queue=1 and queue_status=1;
else
update  tbl_obd_queue set pre_running_binary=cntScript 
where chaisse_server=in_chaisse_server and current_chaisse_queue=1 and queue_status=1;
end if;
select pre_running_binary into script_cnt from tbl_obd_queue where current_chaisse_queue=1 and queue_status=1; 
if(cntLimit>=script_cnt>0)then
select count(running_binary) into st from tbl_running_binary where available_binary_status=1 and chaisse_server=in_server and
running_binary=concat('B',script_cnt);
select 'bfr Er',st,concat('B',script_cnt),in_server;
if(st=1)then
call proc_obd_system(INcampID,in_used_chnnl,concat('B',script_cnt),in_server);
update	tbl_running_binary set 	available_binary_status=0 where chaisse_server=in_server and running_binary=concat('B',script_cnt);
set out_cnt=script_cnt;
else 
select 'Error :available_binary_status=1#proc_obd_queue';
set out_cnt=-1;
end if;
end if;
else
select server_id into chaisse_id from tbl_obd_queue where current_chaisse_queue=1 and queue_status=1;
update tbl_obd_queue set pre_running_binary=0  where server_id=chaisse_id and queue_status=1;
update tbl_obd_queue set current_chaisse_queue=0  where current_chaisse_queue=1 and queue_status=1;
if(noOfqueue>chaisse_id)then
select '2>',chaisse_id;
if(cntScript=cntLimit)then
select count(*) into cnt1 from tbl_obd_queue where  queue_status=1;
select 'cntScript=cntLimit',cnt1;
if(cnt1=1)then
update tbl_obd_queue set current_chaisse_queue=1,running_script=0  where server_id=chaisse_id and queue_status=1;
else
select  queue_status into st from tbl_obd_queue where server_id=chaisse_id+1;
if(st=0)then
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=chaisse_id-1 and queue_status=1;
else
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=chaisse_id+1 and queue_status=1;					
end if;
end if;
set out_cnt=0;
end if;
else if(chaisse_id=noOfqueue)then
select '=',chaisse_id;
if(cntScript=cntLimit)then
select '--',chaisse_id,cntScript;
select count(*)into st from tbl_obd_queue where server_id=1 and queue_status=1;
if(st=1)then	
update tbl_obd_queue set current_chaisse_queue=1,pre_running_binary=0  where server_id=1 and queue_status=1;				
set out_cnt=0;
else
select 'call proc';
call proc_update_queue(INcampID,in_used_chnnl,sid,noOfqueue,@a);
set out_cnt=@a;
end if;	
end if;	
end if;	
end if;	
end if;	
end if;		
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-05 17:12:31
