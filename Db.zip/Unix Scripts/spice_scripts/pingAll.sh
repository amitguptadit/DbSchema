ps -ef|grep MGC |grep -v grep 
ps -ef|grep SdpMedia|grep -v grep
ps -ef|grep Make|grep -v grep
