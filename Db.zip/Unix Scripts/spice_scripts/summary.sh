if [ $# -gt 0 ];
then
	CDR_NAME=$1
cat $CDR_NAME | awk -F~ '{A[$15]++}END{for (i in A) print i"#"A[i]}'|sort -n
else
	echo "pass cdr file as argument.. eg sh summary.sh CDR.txt"
fi
