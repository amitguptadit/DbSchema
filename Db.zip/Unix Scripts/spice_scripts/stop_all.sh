#! /bin/bash

PATH_DIR=/home/
echo "################`date`################" >> $PATH_DIR/scriptlog.txt


echo $PATH_DIR
echo "Stopping  APP + MG + MGC" >> $PATH_DIR/scriptlog.txt

cd $PATH_DIR/liveObd/bin

echo "Stopping MakeCall" >> $PATH_DIR/scriptlog.txt
./stopOBD.sh 1>/dev/null 2>/dev/null &

sleep 2

cd $PATH_DIR/SDP_ISDN/ISDN_bin/MGv3.1/bin
echo "Stopping MG" >> $PATH_DIR/scriptlog.txt
./stop_mg.sh 1>/dev/null 2>/dev/null &

sleep 1

cd $PATH_DIR/SDP_ISDN/ISDN_bin/MGCv3.1/bin
echo "Stopping MGC" >> $PATH_DIR/scriptlog.txt
./stop_mgc.sh 1>/dev/null 2>/dev/null &

echo "System has stopped..." >> $PATH_DIR/scriptlog.txt
exit
