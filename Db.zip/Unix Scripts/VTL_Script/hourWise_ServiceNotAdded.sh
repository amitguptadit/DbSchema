#!/bin/bash
# Fetching MSISDN , Face Value from 204 server 
#-----------------------------------------------
dtOneDayAgo=$(date +%Y-%m-%d -d "1 day ago")
dtTwoDayAgo=$(date +%Y-%m-%d -d "2 day ago")
dt=$(date "+%d%m%Y")

dt1=$(date +%d%m%Y -d "1 day ago")
#--dt=$dt1

echo "$dtOneDayAgo#$dtTwoDayAgo#$dt"
#---------Hourly PCRF File------
#hourly_PCRF_File=PCRF-"$dt".csv


hourly_PCRF_File=$(/bin/ls -lt1   "/home/ppsuser/PPS/DumpFiles/FileLocal/PCRF-"`date "+%d%m%Y"`*.csv| head -n 1|/bin/awk -F" " '{print $9}'|/bin/awk -F "DumpFiles/FileLocal/" '{print $2}')

#/home/ppsuser/PPS/DumpFiles/FileLocal/

echo "Dump File is->$hourly_PCRF_File"
#-----------------------------
##File1="ppsService.log.$dtTwoDayAgo"
File2="ppsService.log.$dtOneDayAgo"
File3="ppsService.log"

cd /home/ppsuser/ServiceNotAdded/hourWise/ 
#-----------------FTP----------------------------
cd 205/
##/usr/bin/lftp sftp://ppsuser:ppsuser@123@10.64.10.205:/home/ppsuser/PPS/logs/  -e "get $File1; bye"
/usr/bin/lftp sftp://ppsuser:ppsuser@123@10.64.10.205:/home/ppsuser/PPS/logs/  -e "get $File2; bye"
/usr/bin/lftp sftp://ppsuser:ppsuser@123@10.64.10.205:/home/ppsuser/PPS/logs/  -e "get $File3; bye"
cd ..
#---------------END FTP---------------------------
#---------------COPY------------------------------

##/bin/cp /home/ppsuser/PPS/logs/$File1 /home/ppsuser/ServiceNotAdded/hourWise/204/
/bin/cp /home/ppsuser/PPS/logs/$File2 /home/ppsuser/ServiceNotAdded/hourWise/204/
/bin/cp /home/ppsuser/PPS/logs/$File3 /home/ppsuser/ServiceNotAdded/hourWise/204/

/bin/cp /home/ppsuser/PPS/DumpFiles/FileLocal/$hourly_PCRF_File  /home/ppsuser/ServiceNotAdded/hourWise/DumpFile/FileLocal/


#---------------End COPY--------------------------
Fil_NotAdded="ServiceNotAdded.log"
if [ -e $Fil_NotAdded ]
then
	/bin/rm $Fil_NotAdded
	echo "remove previous Fil_NotAdded"
fi
#-----------------


##/bin/cat 204/"$File1"|/bin/grep "Service Added" |/bin/awk -F "Service Added Successfully on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >204_TwoDayAgo.log

##/bin/cat 204/"$File1"|/bin/grep "Service Already added on MSISDN" |/bin/awk -F "Service Already added on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >204_TwoDayAgo_Allready.log



/bin/cat 204/"$File2"|/bin/grep "Service Added"|/bin/awk -F "Service Added Successfully on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >204_OneDayAgo.log

/bin/cat 204/"$File2"|/bin/grep "Service Already added on MSISDN"|/bin/awk -F "Service Already added on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >204_OneDayAgo_Allready.log




/bin/cat 204/"$File3"|/bin/grep "Service Added"|/bin/awk -F "Service Added Successfully on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >204_current.log

/bin/cat 204/"$File3"|/bin/grep "Service Already added on MSISDN"|/bin/awk -F "Service Already added on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >204_current_Allready.log


#--------------- Process current ,1 day ago,2 day ago
##/bin/cat 204_TwoDayAgo.log 204_TwoDayAgo_Allready.log  204_OneDayAgo.log 204_OneDayAgo_Allready.log  204_current.log 204_current_Allready.log >204.log

#--------------- Process only current ,1 day ago
/bin/cat    204_OneDayAgo.log 204_OneDayAgo_Allready.log  204_current.log 204_current_Allready.log >204.log

#------------------Process only  1 day ago ,2 day ago -------------------------------
#/bin/cat 204_TwoDayAgo.log 204_TwoDayAgo_Allready.log  204_OneDayAgo.log 204_OneDayAgo_Allready.log >204.log

# Fetching MSISDN , Face Value from 205 server
#-----------------------------------------------

##/bin/cat 205/"$File1"|/bin/grep "Service Added"|/bin/awk -F "Service Added Successfully on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >205_TwoDayAgo.log

##/bin/cat 205/"$File1"|/bin/grep "Service Already added on MSISDN"|/bin/awk -F "Service Already added on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >205_TwoDayAgo_Allready.log


/bin/cat 205/"$File2"|/bin/grep "Service Added"|/bin/awk -F "Service Added Successfully on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >205_OneDayAgo.log

/bin/cat 205/"$File2"|/bin/grep "Service Already added on MSISDN"|/bin/awk -F "Service Already added on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >205_OneDayAgo_Allready.log



/bin/cat  205/"$File3"|/bin/grep "Service Added"|/bin/awk -F "Service Added Successfully on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >205_current.log


/bin/cat  205/"$File3"|/bin/grep "Service Already added on MSISDN"|/bin/awk -F "Service Already added on MSISDN" {'print $2'} |/bin/awk -F ":" {'print $2","$4 '}|/bin/awk -F "Circle" {'print $1'}|/bin/awk -F " IMSI" {' print $1$2'} >205_current_Allready.log


#--------------- Process current ,1 day ago,2 day ago
##/bin/cat 205_TwoDayAgo.log   205_TwoDayAgo_Allready.log  205_OneDayAgo.log 205_OneDayAgo_Allready.log  205_current.log 205_current_Allready.log >205.log

#--------------- Process Only current ,1 day ago
/bin/cat  205_OneDayAgo.log 205_OneDayAgo_Allready.log  205_current.log 205_current_Allready.log >205.log

#------------------Process only  1 day ago ,2 day ago ------
#/bin/cat 205_TwoDayAgo.log  205_TwoDayAgo_Allready.log 205_OneDayAgo.log 205_OneDayAgo_Allready.log  >205.log

#Merge 204 and 205 server Records and genrate common file
/bin/cat 204.log 205.log  |/bin/awk -F " , " {'print $1","$2'} >common204_205.log

#Removing space from starting of the records from common file
/usr/bin/tr -d " \t" < common204_205.log >common_204_205.log

#Fetching the MSISDN,Face Value from Dump File

/bin/cat DumpFile/FileLocal/$hourly_PCRF_File|/bin/awk -F"xMSISDN=" '{print $2}'|/bin/awk -F "xMarket" '{print $1}' |/bin/awk -F "xACT_CODE=" '{print $1","$2}'>DumpFile.log
#Genaration ServiceNotAdded.log File in which those number are presents who does not have service.
/bin/grep -Fxvf common_204_205.log  DumpFile.log >ServiceNotAdded.log
#Removing the First line from the File
/bin/sed -i 1d ServiceNotAdded.log




#----------[	Giving the Service	]-----------
file2_205=205/"$File2"
file3_205=205/"$File3"

file2_204=204/"$File2"
file3_204=204/"$File3"

hrPCRF_File=DumpFile/FileLocal/"$hourly_PCRF_File"

if [ -e $hrPCRF_File ]
then
if [ -e $file2_205 ]
then
if [ -e $file3_205 ]
then
		if [ -e $file2_204 ]
		then
		if [ -e $file3_204 ]
		then
			uupDT=$(date "+%d%m%Y_%H%M%S")
			
			if [ ! -d "log/" ]; then
			  /bin/mkdir log/
			fi
						
			LogDir="log/"`date +%Y%m`
			if [ ! -d "$LogDir" ]; then
			        /bin/mkdir $LogDir
			fi
			
			if [ -s "$Fil_NotAdded" ]
			then
				uupNumberFile="/home/ppsuser/PPS/temp/uup-number.txt"
				
				uupFileTime=$(/bin/ls -lart  --time-style=+"%d%Y_%H%M%S" $uupNumberFile |awk -F " " '{print $6 }')
				if [ -e $uupNumberFile ]
				then
				 /bin/mv /home/ppsuser/PPS/temp/uup-number.txt  "/home/ppsuser/PPS/temp/uup-number_$uupFileTime.txt"
				 echo "[ Time::$uupDT,change the uupNumber file :uup-number_$uupFileTime.txt ]" >>$LogDir"/serviceNotAdded_$dt"
				fi
				/bin/cat ServiceNotAdded.log >/home/ppsuser/PPS/temp/uup-number.txt
				/bin/sh /home/ppsuser/PPS/temp/uupNumber.sh
				echo "[	Done,Successfuly Giving the service ,Time::$uupDT ]" >>$LogDir"/serviceNotAdded_$dt"
			else
				echo "[	ServiceNotAdded File is Empty	,Time::$uupDT ]" >>$LogDir"/serviceNotAdded_$dt"
			fi
		fi
		fi
fi
fi
fi
#----[ After reports generation Removing the File from the script path ]------
/bin/rm   205/$File2 205/$File3
/bin/rm   204/$File2 204/$File3
/bin/rm  DumpFile/FileLocal/$hourly_PCRF_File
#-------Removing others reports files----
/bin/rm   204_OneDayAgo.log 204_current.log 204.log  205_OneDayAgo.log 205_current.log 205.log common204_205.log 

/bin/rm   204_OneDayAgo_Allready.log 204_current_Allready.log   205_OneDayAgo_Allready.log 205_current_Allready.log

/bin/rm   common_204_205.log DumpFile.log 

