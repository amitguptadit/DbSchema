#!/bin/bash
# This is the Script for restarting the IN Server on Daily basis. 
HOST_IP=172.17.4.136
dat=$(date "+%Y%m%d")

# getting JBOSS and Listener Id
rsJb=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "org.jboss.Main" |grep -v "grep"|awk -F " " {'print $2'}`
rsLs=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "com.qtl.listener.AdapterListener" |grep -v "grep"|awk -F " " {'print $2'}`

MAIL_XML_START="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><outboundSMSMessageRequest><address>tel:+919653018120,tel:+919653018163</address><senderAddress>HP-INSERVERALERT</senderAddress><outboundSMSTextMessage>Server ReStart ${HOST_IP} as on ${dat}\n"
MAIL_XML_END="</outboundSMSTextMessage><clientCorrelator>Optional clientCorrelator</clientCorrelator><receiptRequest>Optional notify url</receiptRequest><callBackData>Optional some-data-useful-to-the-requester</callBackData><senderName>Optional Sender Name</senderName></outboundSMSMessageRequest>"

# Killing JBOSS Process
kill -9 $rsJb

#Stopping Listener
`/bin/stopListener &`

#Removing Log Files
rm /home/inuser/chn/listener_out
rm /home/inuser/jboss-4.2.2.GA/nohup.out


rsLs=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "com.qtl.listener.AdapterListener" |grep -v "grep"|awk -F " " {'print $2'}`
#Starting Listener
if [ "$rsLs" == "" ]
	then
	`/bin/startListener &`	
else 
	kill -9 $rsLs
	`/bin/startListener &`				
fi
sleep 15

cd /home/inuser/scripts/
`/home/inuser/scripts/jboss start &`


rsJb=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "org.jboss.Main" |grep -v "grep"|awk -F " " {'print $2'}`
if [ "$rsJb" == "" ]
then
	cd /home/inuser/scripts/
	`/home/inuser/scripts/jboss start &`
	res=`/usr/bin/tail -n100 "/logging/application/qtl_root_$dt.log" |grep "<resultdescription>Transaction Successful</resultdescription>" |head -1`
	MAIL_BODY=${MAIL_XML_START}" Server ReStarted "${MAIL_XML_END}
     	curl -X POST -H "userName:HP-VTLALERT" -H "password:QUxFUlRAU0VDUkVU" -H "Content-Type:application/xml" -d "$MAIL_BODY" http://10.64.10.202:8080/messaging/sms/1.0/outbound/HP-ALERT/requests
             
else
	res=`/usr/bin/tail -n100 "/logging/application/qtl_root_$dt.log" |grep "<resultdescription>Transaction Successful</resultdescription>" |head -1`
	MAIL_BODY=${MAIL_XML_START}" Server ReStarted "${MAIL_XML_END}
     	curl -X POST -H "userName:HP-VTLALERT" -H "password:QUxFUlRAU0VDUkVU" -H "Content-Type:application/xml" -d "$MAIL_BODY" http://10.64.10.202:8080/messaging/sms/1.0/outbound/HP-ALERT/requests

fi
