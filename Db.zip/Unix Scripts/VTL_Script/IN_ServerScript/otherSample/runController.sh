#!/bin/bash
log_file="snmp_HB71_"`date +%Y%m%d.log`
start_file="/usr/SNMP/SNMP/Logs/"$log_file

log_file1="Controller71_"`date +%Y%m%d.log`
start_file1="/usr/SNMP/SNMP/Logs/"$log_file1



date
cd  /usr/SNMP/SNMP_code/SNMPController/src/Controller/
#echo welcome in CONTROLLER......


res1=`ps -ef | grep java|grep snmp_HB`
if [ "$res1" == "" ]
        then
                javac -cp "/usr/SNMP/lib/AdventNetLogging.jar:/usr/SNMP/lib/AdventNetSnmp.jar:/usr/SNMP/lib/crimson.jar:/usr/SNMP/lib/jaxp.jar:/usr/SNMP/lib/log4j-1.2.15.jar:/usr/SNMP/lib/mysql-connector-java-5.1.6-bin.jar:/usr/SNMP/lib/sqljdbc.jar:.:" snmp_HB.java

                java -cp "/usr/SNMP/lib/AdventNetLogging.jar:/usr/SNMP/lib/AdventNetSnmp.jar:/usr/SNMP/lib/crimson.jar:/usr/SNMP/lib/jaxp.jar:/usr/SNMP/lib/log4j-1.2.15.jar:/usr/SNMP/lib/mysql-connector-java-5.1.6-bin.jar:/usr/SNMP/lib/sqljdbc.jar:.:" snmp_HB >snmpHB.log  &

else
                echo "snmp_HB =10.165.186.71 is allready running `date`"$res1 >$start_file
fi

res2=`ps -ef | grep java|grep MainC`

if [ "$res2" == "" ]
	then
	echo welcome in CONTROLLER......
javac -cp "/usr/SNMP/lib/AdventNetLogging.jar:/usr/SNMP/lib/AdventNetSnmp.jar:/usr/SNMP/lib/crimson.jar:/usr/SNMP/lib/jaxp.jar:/usr/SNMP/lib/log4j-1.2.15.jar:/usr/SNMP/lib/mysql-connector-java-5.1.6-bin.jar:/usr/SNMP/lib/sqljdbc.jar:.:" *.java

java -cp "/usr/SNMP/lib/AdventNetLogging.jar:/usr/SNMP/lib/AdventNetSnmp.jar:/usr/SNMP/lib/crimson.jar:/usr/SNMP/lib/jaxp.jar:/usr/SNMP/lib/log4j-1.2.15.jar:/usr/SNMP/lib/mysql-connector-java-5.1.6-bin.jar:/usr/SNMP/lib/sqljdbc.jar:.:" MainC  &

#sshpass -p 'sdredhat'  scp -r snmpTrapStatus.txt root@10.165.186.70:/usr/SNMP/SNMP_code/SNMPController/src/Controller/


else
		echo "snmp Controller =10.165.186.71 is allready running"
                echo "snmp Controller =10.165.186.71 is allready running `date`"$res2 >$start_file1
fi


