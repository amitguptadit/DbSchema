date
sshpass -p 'sdredhat' scp /usr/SNMP/SNMP_code/SNMPController/src/Controller/snmpTrapStatus.txt root@10.165.186.100:/home/apps/cmdCmp/alarms/

sshpass -p 'sdredhat' scp /usr/SNMP/SNMP_code/SNMPController/src/Controller/snmpTrapStatus.txt root@10.165.186.101:/home/apps/cmdCmp/alarms/

sshpass -p 'sdredhat'  scp  snmpTrapStatus.txt root@10.165.186.70:/usr/SNMP/SNMP_code/SNMPController/src/Controller/
