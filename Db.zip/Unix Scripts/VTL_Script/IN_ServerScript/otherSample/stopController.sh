#!/bin/bash
log_file="Controller71_"`date +%Y%m%d.log`
start_file="/usr/SNMP/SNMP/Logs/"$log_file

res1=`ps -ef | grep java|grep MainC|awk -F" " '{print $2}'`
if [ "$res1" == "" ]
        then
		echo "Controller=10.165.186.71 allready running"
                echo "Controller=10.165.186.71 allready running:"$res1
        else
                rs=`kill -9 $res1 `
                echo "stop the Controller=10.165.186.71" 
		echo $rs",stop the Controller=10.165.186.71" >$start_file
fi








