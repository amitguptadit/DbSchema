#!/bin/bash
# This is the Script for restarting the IN Server on Daily basis. 
dt=$(date "+%Y%m%d")
res=`/usr/bin/tail -n100 "/logging/application/qtl_root_$dt.log" |grep "<resultdescription>Transaction Successful</resultdescription>" |head -1`
if [ "$res" == "" ]
        then
                
                /bin/stopListener &
		jboss stop &
		
		rm /home/inuser/chn/listener_out
		rm /home/inuser/jboss-4.2.2.GA/nohup.out
		
		rsJb=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "org.jboss.Main" |grep -v "grep"|awk -F " " {'print $2'}`
		rsLs=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "com.qtl.listener.AdapterListener" |grep -v "grep"|awk -F " " {'print $2'}`
		
		if [ "$rsJb" == "" ]
			then
			rs=`jboss start &`			
		fi	
		
		
		if [ "$rsLs" == "" ]
			then
			rs=`/bin/startListener &`					
		fi
		
		rsJb=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "org.jboss.Main" |grep -v "grep"|awk -F " " {'print $2'}`
		rsLs=`ps -ef |grep java|grep -v "grep"|grep "inuser" |grep "com.qtl.listener.AdapterListener" |grep -v "grep"|awk -F " " {'print $2'}`
		
		
		if [ "$rsJb" == "" ]
		        then
		                
		else
			if [ "$rsLs" == "" ]
					        
			then
					                
			else
			
				res=`/usr/bin/tail -n100 "/logging/application/qtl_root_$dt.log" |grep "<resultdescription>Transaction Successful</resultdescription>" |head -1`
				echo "$res" >restartIN_140_$dt
				
				echo "IN_140 SERVER has been restarted";
			fi
		                
		fi


        else
                 echo "IN_140 SERVER is running fine";
fi
