#!/bin/bash
var=server.log.
dte=$(date +%Y-%m-%d -d "1 day ago")
var1=$dte
#var1="2015-09-24"
var2="$var$var1"
#var2="server.log.2015-10-15"

#-------creating the log directory------
if [ ! -d "136/" ]; then
	/bin/mkdir 136/
fi
if [ ! -d "138/" ]; then
	/bin/mkdir 138/
fi
if [ ! -d "140/" ]; then
	/bin/mkdir 140/
fi
if [ ! -d "141/" ]; then
	/bin/mkdir 141/
fi
if [ ! -d "log/" ]; then
	/bin/mkdir log/
fi
LogDir="log/"`date +%Y%m`
if [ ! -d "$LogDir" ]; then
	/bin/mkdir $LogDir
fi
#----------copy the logs file from IN SERVER 172.17.4.136,138,140,141----

cd 136/
	/usr/bin/sshpass -p 'inuser@123'  scp  inuser@172.17.4.136:/logging/server/$var2   /home/inuser/inReports/136/	
cd ..	
cd 138/
	/bin/cp /logging/server/$var2 .	
cd ..
cd 140/
	/usr/bin/sshpass -p 'inuser@123'  scp  inuser@172.17.4.140:/logging/server/$var2   /home/inuser/inReports/140/
cd ..
cd 141/
	/usr/bin/sshpass -p 'inuser@123'  scp  inuser@172.17.4.141:/logging/server/$var2   /home/inuser/inReports/141/
cd ..
#------------------------------------------------
inServer=(136 138 140 141)
if [ -e "136/$var2" ]
then
	if [ -e "138/$var2" ]
	then
	if [ -e "140/$var2" ]
	then
	if [ -e "141/$var2" ]
	then
	for i in 0 1 2 3
	do 
	  echo "Run the SCRIPT: ${inServer[i]}"
	  sh IN.sh ${inServer[i]} $var1
	done 
	fi
	fi
	fi
fi	
exit 0
